# service-tunnels CLI — 参考

全局参数：`--config-dir <dir>` / `--cache-dir <dir>` 覆盖默认目录
（默认 `~/.config/service-tunnels` / `~/.cache/service-tunnels`，
环境变量 `SERVICE_TUNNELS_CONFIG` / `SERVICE_TUNNELS_CACHE` 亦可覆盖）。

## daemon — 常驻守护（CLI 模式的进程模型）

nginx/authelia/redis/隧道都是常驻进程，CLI 每次执行是短命进程——用 daemon 持有：

```bash
service-tunnels daemon start                 # 后台常驻（detached）
service-tunnels daemon start --foreground    # 前台（调试/容器）
service-tunnels daemon stop                  # 优雅退出并清理全部子进程
service-tunnels daemon status
service-tunnels daemon logs [--tail 100]
```

- daemon PID 与 IPC 地址写入 `~/.cache/service-tunnels/state.json`；
- 除 `discover`/`status`/`config` 外，操作类命令自动经 daemon IPC 转发；
  daemon 未运行：提示 `daemon start` 或加 `--auto-daemon` 自动拉起；
- 库模式（宿主应用等）不需要 daemon——manager 在调用方进程内常驻。

## discover — 查询端口（接受端口或进程 id）

```bash
service-tunnels discover                 # 当前进程树内的监听端口
service-tunnels discover --pid 1234      # 以 pid 1234 为根的后代端口
service-tunnels discover --port 5173     # 只查某个端口是否被“自己的进程树”持有
service-tunnels discover --json          # 机器可读
service-tunnels discover --refresh       # 绕过 5s 缓存
```

输出：`port, pid, process, cmdline, addresses[]`（通配绑定已展开为
127.0.0.1/::1/本机 IP）。**已排除框架辅助进程端口**（nginx/authelia/redis）——
它们通过 `service-tunnels internal list` 单独查看。

## proxy — 泛域名代理（本机/局域网，零依赖）

```bash
service-tunnels proxy start [--port <p>] [--suffix .st.localhost] \
    [--base-path <bp>] [--password <pw>] [--no-ws]
service-tunnels proxy stop
service-tunnels proxy status
```

- 默认监听 `127.0.0.1:<p>`（p 默认 4180）；`<port><suffix>` 虚拟主机 → 对应
  测试端口；可加多个 `--suffix`。
- `--base-path` 部署时剥离（`/dev/foo → /foo`）。

## expose — 一键公网暴露（可带认证）

```bash
service-tunnels expose 5173                                # 默认隧道 ngrok，无认证
service-tunnels expose 5173 --tunnel frpc --auth           # frpc + 默认 provider（authelia）
service-tunnels expose 5173 --auth basic                   # 最简 Basic 认证
service-tunnels expose 5173 --auth oauth2-proxy            # 指定其他 provider
service-tunnels expose 5173 --auth oauth2-github           # oauth2 变体（配置档携带凭据→零输入）
service-tunnels expose 5173 --tunnel ssh --auth --name web
service-tunnels expose stop 5173
service-tunnels expose status
```

`--auth [<provider>]`：**默认 `auto`**——按平台选认证 provider：Windows 用
`portal`（Node 内置 forward-auth 登录页，零外部二进制），Linux/macOS 用
`authelia`（完整 2FA + Redis）。`--auth none` 显式关闭认证（纯透传隧道）。
所有隧道都只是透传到本地 nginx 端口的通道，认证统一在 nginx 侧完成。
可用 `--auth basic` / `--auth oauth2-proxy` / 插件名显式指定。provider
未就绪自动绿色拉起（缺二进制/缺 OIDC 注册等会在 validate 阶段给出修复提示）。
流程见 `docs/design.md §4.7`。

**oauth2 变体**（`--auth oauth2-<name>`，详见 [docs/oauth2-variants.md](oauth2-variants.md)）：
基于 oauth2-proxy 的声明式 provider 变体——固定端点/scope 由变体定义携带，
凭据由配置档 `auth.oauth2` 携带（页面表单默认填入、可直接暴露，也可现场修改）：

```bash
service-tunnels expose 5173 --auth oauth2-github   # 端点/scope 固定；凭据来自配置档 → 零输入
service-tunnels expose 5173 --auth oauth2-keycloak --provider-set issuerUrl=https://auth.example.com/realms/r \
                          --provider-set clientId=myapp --provider-set clientSecret=***
```

自定义变体也可**环境变量注册**（零代码，类似 `SERVICE_TUNNELS_TUNNEL_COMMAND_*`）：

```bash
export SERVICE_TUNNELS_OAUTH2_VARIANT_MYIDP=\
  "provider=oidc;issuerUrl=https://auth.example.com/realms/r;clientId={{clientId}};clientSecret={{clientSecret}}"
service-tunnels expose 5173 --auth oauth2-myidp    # 新类型 oauth2-myidp；{{token}} 为表单参数
```

**认证放行白名单**（`--bypass-path <path>`，可重复）：命中前缀的 URL **跳过
认证**直接转发应用（/health、/metrics 等公开端点），Node proxy 与 nginx 网关
双路径生效：

```bash
service-tunnels expose 5173 --auth authelia --bypass-path /health --bypass-path /metrics
service-tunnels expose 5173 --auth oauth2-proxy --bypass-path /.well-known/status
```

- 前缀匹配：`/health` 命中 `/health` 与 `/health/...`；
- 路径白名单校验（`[a-zA-Z0-9._~/-]`，禁 `;{}'\"` 空白换行与 `..`）防
  nginx 配置注入；
- **禁止白名单 `/`（根路径）**——会匹配全部路径导致认证整体逃逸；想完全
  免认证请用 `--auth none`；
- ⚠️ 白名单路径是**公开可达**的——只放行确实无需认证的端点。

## tunnel — 隧道清单管理

```bash
service-tunnels tunnel list [--json]
service-tunnels tunnel add web --type ngrok --target 4180 [--domain x.ngrok-free.app]   # target=nginx 端口，认证在网关
service-tunnels tunnel add api --type frpc --target 8080 [--auth authelia]
service-tunnels tunnel add ssh1 --type ssh --target 3000            # serveo：ssh -R 80:127.0.0.1:3000 serveo.net
service-tunnels tunnel add lt1  --type localtunnel --target 5173    # lt --port 5173；随机域名走动态登记即可，--subdomain 可选
service-tunnels tunnel add b1   --type bore --target 5173 [--server localhost] [--remote-port 8080] [--token s3cret]  # 自建 bore server，URL 自动 http://host:port
service-tunnels tunnel add nat1 --type natapp --target 5173 --token <authtoken>   # 中国国内内网穿透（natapp.cn），免费版随机 natappfree.cc；客户端需先安装：
#   注册 https://natapp.cn → 下载页执行 curl -fsSL 'https://natapp.cn/get.sh?authtoken=<token>' | bash（Linux/macOS）/ get.ps1（Windows）
service-tunnels tunnel add nat2 --type natapp --target 5173 --token <token> --server server.natapp.cc  # VIP 绑定自定义域名
service-tunnels tunnel add ssh2 --type ssh --target 5173 --host localhost --user wind --remote-port 8080   # ssh -R 8080:127.0.0.1:5173 wind@localhost（本机快速测）
service-tunnels tunnel add cf1 --type cloudflared --target 4180
service-tunnels tunnel start web
service-tunnels tunnel stop web
service-tunnels tunnel remove web
```

> **输入校验**（`src/validation.ts`，详见 [input-validation-security.md](input-validation-security.md)）：
> - 所有隧道参数在 `start()` 与 daemon RPC 双入口 fail-closed 校验——ssh `host/user`
>   以 `-` 开头（如 `-oProxyCommand=...`）会触发**本机任意命令执行**，一律拒绝；
>   token/server/domain 含换行/控制字符（frpc INI 注入）拒绝；隧道名禁止路径分隔符
>   （路径穿越）；端口 1–65535。
> - `--type command` 是唯一经 shell 执行的类型：CLI 提交时自动携带显式 opt-in
>   （`dangerous: true`），daemon 校验缺失即拒绝；UI 需确认对话框。
> - **自定义命令隧道**：`SERVICE_TUNNELS_TUNNEL_COMMAND_<NAME>` 注册自己的隧道方法
>   （如 `sshbox`），模板 `{{token}}` 占位符即 `--set` 参数、`{{localport}}` 自动填
>   被暴露的本地端口——`tunnel add box --type sshbox --target 4180 --set port=8080`
>   等价于 `ssh -R 8080:127.0.0.1:4180 ...`。
> - **URL 声明标记**：命令输出 `ST_TUNNEL_URL:<url>`（`=`/空格分隔、引号/CRLF 容忍）即
>   显式声明隧道 URL（优先于输出解析；无 scheme 的 `host:port` 补 `http://`；`tcp://` 原样）。
>   典型写法 `echo ST_TUNNEL_URL:https://myapp.example.com && <真实隧道命令>`；
>   Windows cmd 同样适用（URL 避免 `& | < > ^ ( )`）。进程非零退出撤销该 URL（不报假成功）。
> - **自定义值注入防护**：占位符值（表单/`--set`/默认值）一律单引号转义后注入 shell
>   （`'`→`'\''`，值只作字面量，`;`/`|`/`$`/反引号/空格全部惰性）；控制字符
>   （含换行/NUL）在 `validateTunnelConfig` 与命令组装双入口 fail-closed 拒绝。
> - `tunnel add --type ngrok --token <authtoken>` 的 token 自动注入 `NGROK_AUTHTOKEN`
>   env（不经 argv、不经 shell），未认证的 ngrok 不会 ERR_NGROK_4018。
> - `--arg <a>` 透传与直接运行该隧道工具等价，属显式特性，不作内容过滤。

认证与隧道解耦：`--auth` 在 nginx 网关侧统一生效（provider：authelia 默认 /
oauth2-proxy / basic / 插件），隧道进程本身不参与认证；`none`（默认，无认证）。

## internal — 框架辅助端口

```bash
service-tunnels internal list [--json]   # [{role:"nginx",port:4180},{role:"authelia",port:9091},...]

## tools — 工具解析与下载

```bash
service-tunnels tools list                 # 所有工具 + 解析结果（path/缓存/PATH/-）
service-tunnels tools resolve frpc         # 不下载，仅查当前解析（PATH/缓存/显式指定）
service-tunnels tools download ngrok       # 需要时手动下载（官方→镜像回退，缓存到 ~/.cache/bin）
service-tunnels tools path authelia
```

解析优先级：`toolPaths` 配置 > 系统 PATH > 缓存 > 自动下载。下载源官方优先，
失败自动切中国镜像（ghproxy / npmmirror）；`--config-dir` 下配置 `toolMirrors`
可覆盖。
```

- 框架自己拉起的 nginx/authelia/redis 监听端口，**不进入 `discover` 结果**；
- 供调用方展示"框架服务"或健康检查（如宿主应用的 UI）。

## gateway — 认证基础设施（nginx + Authelia + Redis）

```bash
service-tunnels gateway start [--nginx-port 4180] [--authelia-port 9091]
service-tunnels gateway stop
service-tunnels gateway status [--json]
service-tunnels gateway reload            # nginx -s reload（新 server 块后）
```

## auth — provider 管理与登记

```bash
service-tunnels auth provider list                     # 已加载的认证 provider
service-tunnels auth provider install <pkg|path>       # 安装插件（npm 包或本地 providers/*.js）
service-tunnels auth register alice.ngrok-free.app     # 写入 provider 的登记（authelia: session.cookies + 重启）
service-tunnels auth unregister alice.ngrok-free.app
service-tunnels auth list
```

## auth user — 用户与密码/2FA 管理

```bash
service-tunnels auth user list [--provider portal|authelia|basic|all]     # 列出各 provider 用户
service-tunnels auth user add alice [--password pw] [--display-name 昵称]  # 未给密码则随机生成并打印
service-tunnels auth user set-password alice [--password pw]               # 改密（未给则随机）
service-tunnels auth user remove alice
service-tunnels auth totp enroll alice            # 生成 TOTP 密钥/otpauth URL（2FA 激活需一次验证码）
service-tunnels auth totp disable alice           # 禁用 2FA
service-tunnels auth totp status alice            # 查询 2FA 启用状态
```

## auth token — Bearer token 管理（tunnel API 请求）

```bash
service-tunnels auth token list [--provider token|all] [--site <s>]               # 列出各站点 token（不含秘密）
service-tunnels auth token create [--description "ci api"] [--expires +7d] [--site <s>]
#   --expires 支持 ISO 日期（2030-01-01）、相对时长（+2h/+30d/+1y）、epoch ms；
#   缺省/never = 永不过期。返回的 token（st_ 开头）只在创建时显示一次。
service-tunnels auth token revoke <id> [--site <s>]                               # 立即失效
```

- 客户端请求：`curl -H "Authorization: Bearer <token>" https://<tunnel>/...`——
  无登录页、无 Cookie，401 直返（`WWW-Authenticate: Bearer`）。
- token 与 user 一样按 site 隔离：`--site services` 的 token 只对
  `services` 站点的虚拟主机有效。
- 库内只存 SHA-256 哈希，`list` 永不返回秘密；过期 token 自动失效并惰性清除。

## ui — 网页管理界面

```bash
service-tunnels ui [--port 4181] [--no-browser]    # 零依赖网页管理（node:http），127.0.0.1，自动弹浏览器
```

- 概览：daemon/隧道/用户状态；隧道启停删增；用户增删改密/2FA 启用禁用；
  配置查看；快速暴露表单（端口 + auth auto/none/provider + 隧道类型）
- 只监听 127.0.0.1，无外部依赖，适合本机管理

## authonly / authsetup — 仅认证模式（替换 nginx 里的 authelia）

**仅认证模式**：在外部系统 nginx 里用 `auth_request` 接入 service-tunnels 认证
（不建隧道网关、不起管理界面，更安全）。管理界面是独立前台进程，用完即关。

```bash
# 一次性设置：定 admin 端口 / auth 端口 / basePath / site（存储位置）
service-tunnels authsetup \
  [--admin-port <p>] [--auth-port <p>] [--base-path <p>] [--site <s>] \
  [--listen <ip>] [--policy one_factor|two_factor|deny] \
  [--bin-dir <dir>] [--out <dir>] [--with-systemd] [--force]

# 生成的可执行脚本（bin 目录，缺省 ~/.local/bin；多配置按 basePath 隔离）
auth-admin-<base>.sh      # Web 管理界面（sts ui）——调 user/site
auth-server-<base>.sh     # 仅认证服务（sts authonly start）——前台 = systemd ExecStart
install-service-<base>.bat   # Windows 服务安装（管理员运行；优先 nssm，回退 sc.exe）
uninstall-service-<base>.bat # Windows 服务卸载
# 产物（out 目录，缺省 configDir/auth）：
nginx-auth-<base>.conf     # nginx auth_request 接入碎片（端口/basePath 已填好）
auth-server-<base>.service # systemd unit（默认生成）
fail2ban-auth-<base>.conf  # fail2ban filter（nginx access.log 401/429）
fail2ban-jail-<base>.conf  # fail2ban jail（5 次/10min → 封 1h）
```

```bash
# 仅认证服务生命周期
service-tunnels authonly start  [--port <p>] [--base-path <p>] [--site <s>] [--listen <ip>] [--policy <p>]
service-tunnels authonly stop   [--site <s>]
service-tunnels authonly status [--site <s>]
```

- **工作流**：`authsetup` → 跑 `auth-admin-<base>` 调好用户/site → 跑
  `auth-server-<base>` 生产运行 → 要调整就停认证、开 admin 调完再启。
- 用户库与管理界面**天然共享**（同 site 存储：`cacheDir/tmp/sites/<site>/portal`）
  ——admin 建的用户认证服务直接用。
- 会话密钥默认持久化（site 存储 `session.secret`，0600）→ systemd 重启不掉会话。
- 认证服务只暴露 forward-auth 端点 + 登录页，无任何管理入口；默认绑 127.0.0.1。

### 暴力破解防护（portal 自身 + fail2ban）

- **portal 自身（已内建，无需配置）**：
  - per-account + per-IP 滑动窗口封禁（5 次失败/5 分钟 → 15 分钟封禁，重复
    打击指数升级 2x/4x/8x/16x，状态持久化 brute.json 重启不丢）；
  - 登录失败统一返回 `401 Invalid username or password.`（不泄露用户存在与否）
    + **恒时 scrypt 校验**（用户不存在也执行同成本哈希，消除时序侧信道）；
  - 密码经 RSA-OAEP 一次性公钥加密（隧道边缘看不到明文）；TOTP/人脸/语音
    2FA；生物识别比密码更严（3 次封禁）。
- **authonly 模式的真实客户端 IP**：认证服务默认信任回环代理的
  `X-Forwarded-For`（`trustProxy` 默认开，仅当连接来自本机 nginx 才采信、取
  nginx 追加的最后一个 IP）→ per-IP 封禁作用于真实攻击者，不会因转发把
  所有人当成 127.0.0.1。
- **fail2ban（可选，nginx 层更早拦截）**：authsetup 生成的
  `fail2ban-auth-<base>.conf`（filter，匹配 access.log 401/429）+
  `fail2ban-jail-<base>.conf`（5 次/10min → 封 1h）安装到
  `/etc/fail2ban/filter.d/` 与 `/etc/fail2ban/jail.d/`（改 logpath 为你的
  access_log）后 `systemctl restart fail2ban`。与 portal 自带封禁互补——
  在 nginx 层直接 drop 攻击 IP，请求不落地认证服务。

## status / 配置

```bash
service-tunnels status [--json]      # 总览：进程、隧道、URL、认证
service-tunnels stop-all             # 退出清理（等价进程退出时的清理）
service-tunnels config path          # 打印解析后的 config/cache 目录
service-tunnels config show          # 显示生效配置（脱敏）
```
