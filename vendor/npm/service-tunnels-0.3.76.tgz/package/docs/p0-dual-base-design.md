# P0 三件套设计：`sts mcp`（MCP server）+ `st-expose`（pi 扩展）+ `sts-expose`（skill）

> **执行摘要见 [expose-research-summary.md](expose-research-summary.md)**；
> 横向调研与 PR×插件评估见 [expose-landscape-plan.md](expose-landscape-plan.md)。

> 目标：让"任何 agent 环境都能暴露端口"——三个相互独立的最小可行面：
> ① MCP server（覆盖 Claude/Cursor/Cline/Roo/Codex/opencode/Gemini/cc-connect
> 等一切 MCP 客户端）；② pi 扩展（一次开发覆盖 pi CLI + 全部 pi-web fork）；
> ③ **skill**（Agent Skills 标准文档化工作流，CLI 的天然形态，覆盖所有无
> MCP/非 pi 的 harness）。
> 前提：公共 npm 最终公开（本设计在"将来公开"前提下展开，当前内部宿主直接可用）。
> 依据：expose-landscape-plan.md §11.1（P0 定位）与
> docs/api.md / src/cli.ts / pi docs extensions.md|skills.md / agentskills.io（机制实测）。

---

## 1. 范围与非目标

**做**：
- `sts mcp`：核心包内新增子命令，手写最小 MCP stdio 协议，暴露端口生命周期
  工具 + schema 查询 + 认证管理工具（子集）。
- `st-expose`：pi 扩展（`~/.pi/agent/extensions/st-expose.ts`），注册
  `expose` / `expose_stop` / `expose_list` / `ports` 四个工具 + `/expose` 命令。
- `sts-expose`：**skill**（Agent Skills 标准，`SKILL.md`），教任何 harness 的
  agent 何时/怎么用 `sts` CLI——三者的关系：**MCP/pi 扩展是程序化工具，skill
  是文档化工作流**（skill 不调 daemon API，只包装 CLI，天然适合 CLI）。
- 三处共用的**后端**：daemon JSON-RPC（`sts daemon`）优先、CLI 兜底、库模式为
  公共 npm 后增强。接口面先于实现冻结（S5 的落地场景）。

**不做（v1）**：
- MCP resources / prompts（仅 tools）。
- MCP 的 UI 组件（无浏览器面板）——浏览器 UI 归各宿主（pi-web ServicesDialog /
  PiClaw web pane / VS Code 扩展）。
- 不把 `sts mcp` 做成独立 npm 包（见 D2）。

---

## 2. 设计决策

| # | 决策 | 理由 |
|---|---|---|
| D1 | **统一接口面 = daemon JSON-RPC**：`sts mcp` 与 `st-expose` 都调 `sts daemon` 的 RPC（经 CLI 的 `--json` 或未来 HTTP）；CLI 是兜底，库模式是增强 | 隧道/网关进程必须在 daemon 持有（跨调用可见、state.json 恢复）；CLI 已实现"自动拉起 daemon + 90s 超时"（`src/cli.ts` expose 分支），零新机制 |
| D2 | **`sts mcp` 做进核心包**（`sts mcp` 子命令），手写最小 MCP 协议（~250 行），**零新增运行时依赖**；@modelcontextprotocol/sdk 仅作 devDependency 一致性测试 | 保住"零运行时依赖"卖点（promotion-plan §1.1）；MCP stdio 是稳定小协议（newline 分隔 JSON-RPC 2.0，无 LSP Content-Length 帧）；单包分发、`sts mcp` 一条命令。备选：若协议测试暴露细节风险，退化为独立包 `service-tunnels-mcp`（依赖官方 SDK） |
| D3 | **安全默认与库一致**：`auth` 默认 `auto`（win32=portal，其余=authelia）；`auth=none` 显式传参且受 `allow-auth-none` 全局开关约束（fail-closed，与 daemon 边界一致）；代理目标仅 127.0.0.1（库内写死）；端口归属校验 `verifyPortOwner`；`--tunnel command` 等危险参数默认拒绝 | 不因"新接入面"弱化任何既有安全语义（AGENTS.md：认证统一在决策 API） |
| D4 | **工具参数 schema 动态生成**：`expose_port` 的 tunnel/provider 参数从 `st.schemas.tunnels()/authProviders()` 拉取（客户端先 `list_tunnel_providers` 再填参） | 复用 schema 驱动架构：新增 provider 时 MCP/pi 扩展零改动（与 pi-web 表单同一契约） |
| D5 | **输出一律 JSON**：`sts expose --json` / `sts status --json` / `sts discover --json` 已存在；MCP 工具返回结构化为 `{content:[{type:"text"}], structuredContent?}` | 机器可解析；pi 扩展解析 JSON 而非 grep 终端输出 |
| D6 | **工具执行前确认**：pi 侧用 `tool_call` 事件钩子 `ctx.ui.confirm`（文档化模式）；MCP 侧无权限提示机制 → 工具 description 明示"会向公网暴露该端口"，客户端权限由各客户端管理（opencode `permission.ask` / Claude 工具确认） | 暴露是有副作用的动作，确认是底线（对齐 opencode `permission.ask` 语义） |

---

## 3. `sts mcp` — MCP server 详细设计

### 3.1 入口与协议子集

```
sts mcp [--stdio]            # 唯一入口：stdin/stdout newline 分隔 JSON-RPC 2.0
                             # stderr 只写日志（MCP 客户端不解析 stderr）
sts mcp --version            # 打印版本
```

**协议子集**（MCP SDK 客户端兼容所需的最小集合）：
- 请求：`initialize`（返回 protocolVersion、capabilities.tools、serverInfo）、
  `ping`、`tools/list`、`tools/call`。
- 通知：`notifications/initialized`（忽略但校验）、`notifications/cancelled`
  （对长任务尝试中断——可选）。
- 错误：`-32601`（未知工具）、`-32602`（参数校验失败，附 `ts-errors` 详情）、
  `-32000`（工具执行失败，message 含可读原因）。
- 协议版本：`2025-03-26`（tools 只读 + call，无需 resources/prompts 协商）。

**帧格式**：每行一个完整 JSON-RPC 消息（`\n` 分隔），无 Content-Length 头
（MCP stdio 规范）。实现要点：按 `\n` 分帧、逐行 parse、超时/背压（慢客户端
时暂停 spawn 输出）、进程退出时清理（`st.shutdown()` 回收子进程）。

### 3.2 后端接线

```
sts mcp (stdio) ── 工具 handler ──▶ ensureDaemon() ──▶ daemon.request(method, params)
                                        │
                                        └─ 兜底：daemon 不可用 → 进程内 createServiceTunnels()
```

- **ensureDaemon()**：复用 `src/cli.ts` expose 分支的既有逻辑（`st.daemon.status()`
  未运行则 `start()` + 轮询 5s）。
- **超时**：`expose_port` 对齐 CLI 90s（隧道建立 + URL 解析）；其余工具 30s。
- **并发**：MCP 客户端可能并行调多个工具——handler 内串行化 daemon 请求（
  daemon RPC 本身串行），避免 gateway/nginx 状态竞争；`tools/call` 顺序处理即可。
- **生命周期**：进程退出（stdin EOF）→ `st.shutdown()`（守护回收子进程，
  guardian 兜底）；`sts mcp` 是短生命周期 stdio 进程，不常驻。

### 3.3 工具清单

| 工具 | 参数（TypeBox→JSON Schema 手写） | 返回 | 安全语义 |
|---|---|---|---|
| `list_ports` | `excludeCmdline?`（默认排除宿主自身） | 发现端口候选 `[{port, pid, cmdline, addrs}]` | 只读；候选≠授权（对齐 D4 零转发：仍须 expose） |
| `list_tunnel_providers` | — | `st.schemas.tunnels()`（name/type/params schema/metas） | 只读；客户端渲染表单用 |
| `list_auth_providers` | — | `st.schemas.authProviders()`（含 authNoneAllowed） | 只读 |
| `expose_port` | `port`（必填 1-65535）、`mode`（tunnel/proxy/both）、`auth`（none/auto/\<provider>）、`tunnel`（类型，schema 动态校验）、`tunnelParams`（对象）、`providerParams`（对象）、`site`、`label`、`protocol`（http/https/tcp）、`baseDomain` | `{name, url, localUrl, loginUrl, status}` | 见 D3/D6；`auth="none"` 需 `allowAuthNone` 放行；tcp 无认证；危险命令（`--tunnel command`）拒绝 |
| `stop_expose` | `name` | `{stopped: true, name}` | 幂等 |
| `list_exposes` | — | 运行中 exposes（name/port/mode/auth/url/status/running） | 只读 |
| `auth_create_token` | `description`、`expires?`（ISO/\<+2h>/never） | `{id, token}`（token 唯一一次返回） | 机器访问凭据；site 默认 default |
| `auth_list_tokens` / `auth_revoke_token` | `site?` / `id`+`site?` | 列表 / 撤销确认 | 管理面 |
| `auth_list_users` | `site?` | 各 provider 用户列表 | 管理面，只读 |

> v1 不含 `auth_add_user`/`set_password`（敏感管理动作交给 CLI/UI）；MCP 先覆盖
> 机器场景（token）与只读查询。

### 3.4 实现结构（src/mcp.ts，~250 行）

```
parseLine(buf): JSON-RPC 消息
handleInitialize / handlePing / handleToolsList / handleToolsCall
tools 表：{ name, schema (JSON Schema), handler(params, meta) }
handler 内部：ensureDaemon() → daemon.request(method, params)（复用 cli.ts 的
  expose/status/discover/auth.token 请求参数形状）→ 错误归一化
```

- `src/cli.ts` 加 `case "mcp"`（`args.mcp`），其余复用。
- 工具 schema 从现有 `TUNNEL_PARAM_SCHEMAS`/`authProviderSchemas` **转换**
  （ParamSpec → JSON Schema：`type/key/required/enum/default` 映射），避免
  双份定义——转换函数单测覆盖。

### 3.5 测试与验收

| 层 | 内容 |
|---|---|
| 协议一致性 | devDependency `@modelcontextprotocol/sdk`（client）+ `node --test`：spawn `sts mcp`，跑 `initialize → tools/list → tools/call` 全链路断言（含错误码/参数校验/超长行/半行分帧） |
| 纯函数 | ParamSpec→JSON Schema 转换、`\n` 分帧、错误归一化（无 daemon 依赖） |
| e2e | `pickFreePort`（AGENTS.md 约定）起本地 http server → `expose_port`（bore 自建 server / cloudflared）→ 拿到 URL → `stop_expose` → 断言进程清理 |
| 安全 | `allow-auth-none=false` 时 `auth:"none"` 被拒；端口越界/非数字被拒；未知工具 -32601 |

### 3.6 客户端接入示例（文档）

```jsonc
// opencode.json
{ "mcp": { "sts": { "type": "stdio", "command": "sts", "args": ["mcp"] } } }
// Claude Desktop / Cursor / Cline：同名 stdio server 配置
// cc-connect：Go 侧 spawn "sts mcp" 或经 MCP client（见 expose-landscape-plan §11.7）
```

---

## 4. `st-expose` — pi 扩展详细设计

### 4.1 形态与分发

- 单文件 `st-expose.ts`，放 `~/.pi/agent/extensions/`（全局）或 `.pi/extensions/`
  （项目级）即自动发现；`/reload` 热重载（pi docs extensions.md 实测）。
- 零 npm 依赖：只 import `@earendil-works/pi-coding-agent` 类型 + `node:child_process`。
  内部宿主**预装**；公共 npm 后做成 pi package（`pi install st-expose`）或文档
  复制粘贴单文件。
- 与 jmfederico/pi-web 复用：同一扩展在其 sessiond 直接生效（§11.1.2）。

### 4.2 工具设计

```ts
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

export default function (pi: ExtensionAPI) {
  // ---- 内部：sts() 调 CLI（自动拉起 daemon），超时 90s，解析 JSON ----
  // sts(["expose", String(port), "--json", ...]) → res（失败抛错带 stderr）

  // ---- 确认门（D6）：工具调用前强制确认 ----
  pi.on("tool_call", async (event, ctx) => {
    if (event.toolName !== "expose") return;
    const ok = await ctx.ui.confirm("公网暴露", `把端口 ${(event.input as any)?.port} 暴露到公网？`);
    if (!ok) return { block: true, reason: "用户拒绝暴露" };
  });

  pi.registerTool({
    name: "expose",
    label: "Expose port",
    description: "把本地服务端口暴露到公网（隧道）或本地虚拟主机（proxy），返回 URL。默认带认证（auto）。",
    parameters: Type.Object({
      port: Type.Integer({ minimum: 1, maximum: 65535, description: "要暴露的本地端口" }),
      mode: Type.Optional(Type.Union([Type.Literal("tunnel"), Type.Literal("proxy"), Type.Literal("both")])),
      auth: Type.Optional(Type.String({ description: "认证：auto/none/portal/basic/authelia/token" })),
      tunnel: Type.Optional(Type.String({ description: "隧道类型：cloudflared/ngrok/bore/localtunnel/...（默认 cloudflared）" })),
      site: Type.Optional(Type.String()),
      label: Type.Optional(Type.String()),
      protocol: Type.Optional(Type.Union([Type.Literal("http"), Type.Literal("https"), Type.Literal("tcp")])),
    }),
    async execute(_id, params, _signal, _onUpdate) {
      const args = ["expose", String(params.port), "--json",
        ...(params.mode ? ["--mode", params.mode] : []),
        ...(params.auth ? ["--auth", params.auth] : ["--auth", "auto"]),
        ...(params.tunnel ? ["--tunnel", params.tunnel] : []),
        ...(params.site ? ["--site", params.site] : []),
        ...(params.label ? ["--name", params.label] : []),
        ...(params.protocol && params.protocol !== "http" ? ["--ssh-gateway", ...] : []), // tcp 走 ssh-gateway 语义，见 cli.ts
      ];
      const res = await sts(args);            // {url, localUrl, loginUrl, name, ...}
      return { content: [{ type: "text", text: JSON.stringify(res, null, 2) }], details: res };
    },
  });

  pi.registerTool({
    name: "expose_stop", ...   // sts(["expose", "stop", name]) → {stopped}
  });
  pi.registerTool({
    name: "expose_list", ...   // sts(["status", "--json"]) 过滤 exposes
  });
  pi.registerTool({
    name: "ports", ...         // sts(["discover", "--json"]) 候选端口（只读）
  });
}
```

> 注意：`tcp` 协议在 CLI 走 `--ssh-gateway` 语义（`src/cli.ts`：`protocol: "tcp"` 需
> ssh 网关），扩展 v1 **不暴露 tcp**（避免误用），文档说明"tcp 请用 CLI/UI"。

### 4.3 `/expose` 命令（交互流程）

```
/expose
  → sts discover --json → ctx.ui.select(端口列表)
  → ctx.ui.select(模式: tunnel/proxy/both, 默认 tunnel)
  → ctx.ui.select(认证: auto/none/portal/basic, 默认 auto)
  → ctx.ui.confirm 最终确认（含"将暴露公网"警告）
  → 执行 → ctx.ui.notify(URL) + ctx.ui.setWidget(状态: URL/停止)
  → 返回文本含 localUrl/loginUrl 与停止方式
```

### 4.4 安全

- 确认门用 `tool_call` 事件（文档化模式，见 extensions.md Quick Start 的
  rm -rf 示例）——即使 agent 主动调用也需用户点头。
- `auth` 默认 `auto`；`auth="none"` 显式传参 + 库的 `allow-auth-none` 仍生效
  （daemon 边界 fail-closed，扩展无法绕过）。
- 扩展内**不缓存**任何 secret/token 到日志；错误信息只回传 daemon 的通用原因。

### 4.5 测试与验收

- 单测（node --test）：参数→CLI args 映射纯函数、输出 JSON 解析、确认门逻辑
  （mock ctx）。
- 冒烟（真实 pi 会话）：`pi -e ./st-expose.ts`（extensions.md 提供的测试方式）
  → 手动 `/expose` 走完整流程 → 浏览器开 URL → 停止 → 确认进程清理。
- 安全：`allow-auth-none=false` 下 agent 请求 auth=none 被拒并提示。

### 4.6 `st-expose` 分发与 skill 的关系

`st-expose` 扩展（§4.1）只在 pi 生态生效；非 pi harness（Claude Code / Codex /
opencode 原生 / Cursor）的接入面是 **skill**（§5）——扩展与 skill 互补而非重复：
扩展=程序化工具（`pi.registerTool`），skill=文档化工作流（教 agent 用 `sts` CLI）。

---

## 5. `sts-expose` — skill（第三个底座，CLI 的天然形态）

### 5.1 定位与格式

- **格式**：Agent Skills 标准（agentskills.io）——目录含 `SKILL.md`
  （frontmatter 至少 `name`/`description`）+ 可选 `scripts/`、`references/`。
  agent 按 progressive disclosure 加载：启动只见 description，任务匹配才读全文。
- **为什么 CLI 适合 skill**：`sts` 是命令行工具，skill 就是把命令包装成
  "何时用 + 怎么组合 + 常见错误" 的工作流文档——不调 daemon API，不依赖 MCP
  SDK，任何支持 Agent Skills 标准的 harness 都能读。
- **内容设计**（对齐 `~/.claude/skills/gitnexus-cli/` 的 CLI 技能样板）：
  - frontmatter：`name: sts-expose`；`description:` 覆盖触发场景（webhook 回调
    调试、客户/同事验收、临时公网分享、本地固定域名、机器访问 token）与
    反例（不要用于内网服务扫描）。
  - 正文：命令矩阵（`sts expose` 的 mode×auth×tunnel×protocol 组合、
    `sts tunnel start/stop`、`sts status --json`、`sts discover --json`、
    `sts auth token create`）、URL 语义（url/localUrl/loginUrl）、停止与清理、
    常见错误（auth-none 禁令、端口未发现、隧道 90s 超时、token 唯一一次返回）。
  - 可选 `scripts/`：`expose.sh` / `stop.sh` / `token.sh` 薄包装（隐藏 --json
    解析细节），skill 正文用相对路径调用（Agent Skills 规范支持）。

### 5.2 注册位置（skill 要放哪）

| Harness | 注册位置 | 加载 |
|---|---|---|
| **pi** | `~/.pi/agent/skills/sts-expose/`（全局）/ `.pi/skills/`（项目）/ pi package `skills/` | 自动发现；`/skill:sts-expose` 强制加载 |
| **Claude Code** | `~/.claude/skills/sts-expose/`（或项目 `.claude/skills/`） | 自动发现 |
| **opencode** | `.opencode/skill/sts-expose/`（项目）/ `~/.config/opencode/skill/` | 自动发现（源码 `{skill,skills}/**/SKILL.md`） |
| **Codex** | `~/.codex/skills/` | 自动发现 |
| **跨 harness 共享** | 一份技能放公共目录（如 `~/.agents/skills/sts-expose/`——pi 默认扫这里），其余 harness 用 settings/链接引用（pi 已支持 `skills: ["~/.claude/skills"]`） | settings/plugin 声明 |

### 5.3 集中发布平台（关键问题：有没有 registry）

**结论：官方无集中 registry；社区集中目录正在涌现；各 harness 的包管理器是
现实主路。** 发布矩阵：

| 渠道 | 性质 | 发布方式 | 对我们的适配成本 |
|---|---|---|---|
| **npm 包（并入 service-tunnels）** | 主分发渠道：pi packages 直接消费 | package.json 声明 `pi.skills` + 仓库含 `skills/` 目录 → `pi install service-tunnels`（公共 npm 后）自动获得 skill | 低（随包发布） |
| **GitHub 仓库（anthropics/skills 模式）** | 官方推荐的版本控制分发 | 把 skill 目录放 service-tunnels 公开仓库 `skills/sts-expose/`，文档给 clone/symlink/settings 引用 | 低 |
| **Claude Code plugin marketplace** | Claude 侧的集中机制 | skill 目录加 `.claude-plugin/plugin.json`，`claude plugin marketplace add <repo>` 分发 | 中（额外清单文件） |
| **opencode 插件（并开 opencode-expose）** | opencode 侧分发 | 插件包携带 `skills/`，`opencode plugin add` 安装 | 中（随 P1 插件） |
| **tech-leads-club/agent-skills**（~5k★） | 社区集中 registry（安全验证+ npm 分发） | 提交 skill 进其库，经安全审核后发布（`@tech-leads-club/agent-skills`） | 中（需过安全审查——正好展示我们的安全默认） |
| **iflytek/skillhub**（~4.9k★） | 企业自托管/集中 registry（中文生态友好） | 推送 skill 包到 namespace，CLI/搜索安装 | 中（Java 生态，需按其包格式） |
| **agentregistry / Observal 等** | 新兴目录 | PR/推送 | 低-中 |
| **官方 agentskills.io** | **无 registry**（只有规范 + anthropics/skills 示例 + Client Showcase） | — | — |

**策略**：P0 阶段 skill 随 service-tunnels 仓库/npm 包分发（低摩擦）；公共 npm
公开后按 "GitHub + npm（pi）→ opencode 插件 → tech-leads-club/agent-skills +
skillhub" 顺序扩渠道；Claude marketplace 视维护成本决定。**不押注单一集中
平台**——Agent Skills 标准保证了技能内容可移植，注册位置随时可加。

### 5.4 测试与验收

- 单测：frontmatter 解析（name/description 合法）、命令矩阵与实际 `sts` CLI
  help 一致性（防文档漂移）。
- 冒烟：在 pi 会话与 Claude Code 各跑一次 "暴露端口 → 拿到 URL → 停止" 全流程
  （skill 驱动的 agent 行为）。
- 安全：skill 正文与 scripts 不含内部域名/端口/路径（AGENTS.md 清洗约定），
  无 auth=none 默认推荐（只作为显式选项列出）。

---

## 6. 实施顺序与里程碑

| 里程碑 | 内容 | 预计 |
|---|---|---|
| M1 | `sts mcp` 骨架：分帧/initialize/ping/tools-list + `list_ports`/`list_tunnel_providers`/`list_auth_providers` + SDK client 一致性测试 | 1 天 |
| M2 | `expose_port`/`stop_expose`/`list_exposes` + 安全校验（allow-auth-none/端口越界/危险参数拒绝）+ bore e2e | 1-1.5 天 |
| M3 | `auth_create_token`/`auth_list_tokens`/`auth_revoke_token` + `auth_list_users` + 客户端接入文档（opencode/Claude/Cursor/cc-connect） | 0.5-1 天 |
| M4 | `st-expose` pi 扩展：四工具 + `/expose` 命令 + 确认门 + 冒烟 | 1-1.5 天 |
| M5 | `sts-expose` skill：SKILL.md + scripts + 注册到 pi/Claude/opencode + 冒烟 | 0.5-1 天 |
| M6 | 三件套在内部宿主预装（pi-web 环境已有 daemon）+ README/文档 + 发布准备（公共 npm 后插件包切换为库模式） | 0.5 天 |

总预计：**5-6 个工作日**（M1-M3、M4、M5 可并行三人）。

---

## 7. 验收标准

1. `sts mcp`：`node --test` 全绿（协议一致性含 SDK client 断言 + 安全拒绝用例）；
   `pickFreePort` e2e 真实隧道通、停止后无孤儿进程（guardian 断言）。
2. `st-expose`：单测 + 真实 pi 会话冒烟通过；`tool_call` 确认门生效
   （拒绝时 agent 收到 block reason）；`auth=none` 受全局开关约束。
3. `sts-expose` skill：frontmatter 合法、命令矩阵与 `sts` CLI help 一致；
   pi 会话与 Claude Code 各跑通一次全流程；无内部信息残留（AGENTS.md 清洗）。
4. 三件套共用 daemon JSON-RPC：**新增 tunnel/provider/认证无需改任何一行
   MCP/扩展/skill 代码**（schema 驱动，M4/D4 验证：加一个 provider 后
   `list_tunnel_providers` 与 `expose_port` 自动识别）。
5. 零新增运行时依赖（`package.json` dependencies 不变；SDK 仅 devDependencies）。
6. 文档：本设计与接入示例进 docs/；AGENTS.md 发布清洗约定（内部域名/端口不入
   公共 npm 包）在打包前核对。

---

## 8. 风险与回退

| 风险 | 影响 | 回退 |
|---|---|---|
| 手写 MCP 协议与客户端实现有细微偏差 | 客户端连接失败 | 用官方 SDK client 的一致性测试锁定；仍有问题 → 退独立包 `service-tunnels-mcp`（依赖官方 SDK，D2 备选） |
| pi 扩展 jiti 加载环境（bun/各 fork sessiond）差异 | 扩展加载失败 | 单文件零依赖最稳；冒烟矩阵覆盖 pi CLI + agegr + jmfederico sessiond |
| daemon 未启动/版本漂移 | 工具超时 | CLI 自动拉起已有；工具错误信息带"运行 `sts daemon start`"提示 |
| MCP 客户端并行调用 | 状态竞争 | handler 串行化 daemon 请求（3.2） |

---

## 附录：证据与出处

- `sts` CLI：`src/cli.ts`（`expose` 分支自动拉起 daemon + `jsonOut`；`--json`
  discover/status；`protocol tcp → --ssh-gateway` 语义）。
- pi 扩展：`@earendil-works/pi-coding-agent/docs/extensions.md`（jiti 加载 TS、
  `registerTool` 签名、`tool_call` 事件确认门示例、`pi -e` 测试、扩展目录自动
  发现 + `/reload`）。
- MCP：`@modelcontextprotocol/sdk` v1.30.0（client 用于 devDep 测试）；MCP
  stdio 规范（newline 分隔 JSON-RPC 2.0）。
- 前置决策：`docs/expose-landscape-plan.md` §11.1（P0 定位）、§11.2-11.8
  （各生态插件路线）、§10.0（公共 npm 门槛）；pi skills 位置/格式与跨
  harness 引用见 `@earendil-works/pi-coding-agent/docs/skills.md`。
