# VS Code 扩展 — 实施蓝图（细化）

> 计划层（做什么/为什么）见 [vscode-extension-plan.md](vscode-extension-plan.md)；
> 技术调研与已落地补丁见 [vscode-extension-research.md](vscode-extension-research.md)。
> 本文是实施层：仓库布局、骨架、激活流程、Manager 封装、端口发现器、
> schema 驱动表单契约、MVP 命令流、Phase 0 真机验收清单。

---

## 1. 仓库布局（同仓随库版本发布）

```
service-tunnels/
├─ src/  dist/  docs/  test/          # 库本体（现状）
└─ extensions/
   └─ vscode/
      ├─ package.json                  # 扩展清单（CJS，main=dist/extension.js）
      ├─ tsconfig.json                 # 编译到 CJS，declaration 关，sourcemap 开
      ├─ .vscodeignore                 # 排除 test/docs/src，减小 vsix
      ├─ media/icon.svg                # Marketplace 图标
      ├─ src/
      │  ├─ extension.ts               # activate/deactivate + 命令注册
      │  ├─ manager.ts                 # 库单例封装（最小接口集 + 事件桥）
      │  ├─ discovery.ts               # 四层端口发现器（宿主树/task/终端/探测）
      │  ├─ forms.ts                   # schema 驱动表单（ParamSpec → QuickPick/InputBox）
      │  ├─ commands/
      │  │  ├─ expose.ts               # st: Expose Port… 主流程
      │  │  ├─ stop.ts                 # st: Stop Exposure
      │  │  └─ auth.ts                 # st: Manage Users / Tokens / 2FA
      │  ├─ views/exposures.ts         # TreeDataProvider（暴露列表）
      │  └─ status.ts                  # 状态栏（URL 展示/复制/停止菜单）
      └─ test/runTest.ts               # @vscode/test-electron 冒烟
```

- **同仓理由**：随库版本发布（库破坏性变更时扩展同步适配）；Phase 4 切公共
  npm 后仅换依赖来源，结构不变。
- **依赖**：`service-tunnels`（file: 内部 → ^0.4 公共）+ `@types/vscode` +
  `@vscode/test-electron`（dev）。无其他运行时依赖。

---

## 2. 扩展骨架（package.json 关键字段）

```jsonc
{
  "name": "service-tunnels",
  "displayName": "Service Tunnels — 一键公网暴露",
  "publisher": "<待定>",
  "main": "./dist/extension.js",          // CJS（VS Code 尚不支持 ESM 扩展）
  "engines": { "vscode": "^1.93.0" },     // 1.93 = 终端 shell integration API；精确下限 Phase 0 核对
  "activationEvents": ["onStartupFinished"],
  "extensionKind": ["workspace"],          // 桌面 only（web host 无本机能力）
  "categories": ["Other"],
  "contributes": {
    "commands": [
      { "command": "st.exposePort",        "title": "Service Tunnels: Expose Port…" },
      { "command": "st.stopExposure",      "title": "Service Tunnels: Stop Exposure" },
      { "command": "st.openInBrowser",     "title": "Service Tunnels: Open in Browser", "icon": "$(globe)" },
      { "command": "st.copyUrl",           "title": "Service Tunnels: Copy URL",        "icon": "$(copy)" },
      { "command": "st.exposures.refresh", "title": "Refresh",                          "icon": "$(refresh)" },
      { "command": "st.auth.manage",       "title": "Service Tunnels: Users / Tokens" }
    ],
    "viewsContainers": { "activitybar": [{ "id": "stExplorer", "title": "Service Tunnels", "icon": "media/icon.svg" }] },
    "views": { "stExplorer": [{ "id": "st.exposures", "name": "Exposures" }] },
    "menus": {
      "view/title": [{ "command": "st.exposePort", "when": "view == st.exposures", "group": "navigation" },
                     { "command": "st.exposures.refresh", "when": "view == st.exposures" }],
      "view/item/context": [{ "command": "st.copyUrl", "when": "viewItem == exposure" },
                            { "command": "st.openInBrowser", "when": "viewItem == exposure" },
                            { "command": "st.stopExposure", "when": "viewItem == exposure" }]
    },
    "configuration": {
      "title": "Service Tunnels",
      "properties": {
        "serviceTunnels.defaultTunnelType":  { "type": "string", "default": "cloudflared", "enum": ["cloudflared","ngrok","natapp","bore","serveo","localtunnel","ssh","frpc"] },
        "serviceTunnels.defaultAuth":        { "type": "string", "default": "auto", "enum": ["auto","none","portal","basic","authelia","token"] },
        "serviceTunnels.preferMirrors":      { "type": "boolean", "default": false, "markdownDescription": "中国网络：下载走 ghproxy/npmmirror 镜像优先" },
        "serviceTunnels.allowToolDownload":  { "type": "boolean", "default": true },
        "serviceTunnels.probePorts":         { "type": "array", "items": { "type": "number" }, "default": [5173,4173,3000,8000,8080,4200,5000] },
        "serviceTunnels.configDir":          { "type": "string", "default": "", "markdownDescription": "留空=扩展私有目录（推荐，F5）；填绝对路径可复用 CLI 配置（需接受单写入者约定）" }
      }
    }
  }
}
```

**构建**：`tsc -p extensions/vscode`（CJS）+ `@vscode/vsce package`。
vsix 内容：`dist/` + `node_modules/service-tunnels` + `node_modules/justget`
+ README/LICENSE/icon。库不打包（动态 import 桥接，research F1）。

---

## 3. 激活流程（代码级）

```ts
// src/extension.ts
export async function activate(ctx: vscode.ExtensionContext): Promise<void> {
  const nodeVer = process.versions.node;
  if (semverLt(nodeVer, "20.19.0")) {
    // dist 实际下限 Node 18（research F8），此处仅提示不阻断
    void vscode.window.showWarningMessage(`Service Tunnels 建议 VS Code ≥1.98（内置 Node 20.19+），当前 ${nodeVer}；将尝试兼容模式。`);
  }

  // 1) 库单例（CJS → 动态 import ESM；Electron 宿主 spawn 适配已由库侧 P1 解决）
  manager = await ServiceTunnelsManager.create({
    storageDir: ctx.globalStorageUri.fsPath,   // configDir/cacheDir 落在扩展私有目录（F5）
    nodePath: process.execPath,                 // F2：VS Code 二进制 + ELECTRON_RUN_AS_NODE
  });

  // 2) 命令 / 视图 / 状态栏 / 发现器
  registerCommands(ctx);
  registerExposuresView(ctx);
  registerStatusBar(ctx);
  registerDiscovery(ctx);                       // task + 终端 shell integration 监听

  // 3) 恢复上次暴露（state.json 里有存活隧道 → st.tunnels.hydrate 已在库内完成）
  await manager.init();                          // 订阅 tunnel:url / tunnel:stop 事件刷新 UI
}

export async function deactivate(): Promise<void> {
  await manager?.shutdown();                     // 清理全部子进程（guardian:false 时的主清理路径）
}
```

---

## 4. Manager：库封装（最小接口集，A/C 双形态同签名）

```ts
// src/manager.ts
export interface ExposeRequest {
  port: number;
  mode?: "tunnel" | "proxy" | "both";
  tunnelType?: string;
  auth?: boolean | "auto" | string;
  site?: string;
  tunnelParams?: Record<string, unknown>;   // --set 语义（schema 表单产物）
  providerParams?: Record<string, unknown>; // --provider-set 语义
}

export class ServiceTunnelsManager {
  #st!: ServiceTunnels;                      // 动态 import 注入（见 create）
  static async create(opts: { storageDir: string; nodePath: string }): Promise<ServiceTunnelsManager> {
    const { createServiceTunnels } = await import("service-tunnels");
    const st = createServiceTunnels({
      configDir: join(opts.storageDir, "config"),
      cacheDir: join(opts.storageDir, "cache"),
      marker: "vscode-st",
      guardian: false,                        // F3：扩展生命周期受控；崩漏下次启动按 state.json 清理
      nodePath: opts.nodePath,                // F2
    });
    return new ServiceTunnelsManager(st);
  }

  get st() { return this.#st; }

  // —— 最小接口集（内嵌/daemon 兜底同签名，UI 不感知）——
  async expose(req: ExposeRequest) { return this.#st.auth.expose(req.port, req); }
  async stop(port: number | string) { await this.#st.auth.stopExpose(port); }
  list() { return this.#st.auth.listExposes(); }
  discoverPorts(opts?: { rootPid?: number }) { return this.#st.discovery.getPorts(opts); }
  tunnelSchemas(lang?: string) { return this.#st.schemas.tunnels(lang); }
  authProviders() { return { list: this.#st.auth.providers(), noneAllowed: this.#st.auth.noneAllowed() }; }
  on<E extends string>(event: E, cb: (e: unknown) => void) { return this.#st.on(event, cb); }
  async shutdown() { await this.#st.shutdown(); }
}
```

**事件桥**（UI 刷新）：`tunnel:url`（拿到 URL → 状态栏+树更新）、`tunnel:stop`
（移除）、`nginx:reload`（认证域变更后可忽略）。daemon 兜底形态（F1/F8 触发）
同样订阅：轮询 `list()` 每 5s 兜底（daemon RPC 无推送事件）。

---

## 5. 四层端口发现器（src/discovery.ts）

```ts
const roots = new Set<number>([process.pid]);          // L1：扩展宿主树（debug 会话）

// L2：Task 进程（Ctrl+Shift+B / tasks.json 启动的 dev server）
ctx.subscriptions.push(vscode.tasks.onDidStartTaskProcess(e => {
  if (e.processId) { roots.add(e.processId); refreshPicker(); }
}));

// L3：终端 shell integration（1.93+；手动 `npm run dev`）
ctx.subscriptions.push(vscode.window.onDidChangeTerminalShellIntegration(t => {
  if (!t.shellIntegration) return;
  void t.processId.then(pid => { if (pid) { roots.add(pid); refreshPicker(); } });
}));

async function candidatePorts(): Promise<ServicePortInfo[]> {
  const seen = new Map<number, ServicePortInfo>();
  for (const root of roots) {
    for (const p of manager.discoverPorts({ rootPid: root })) seen.set(p.port, p);
  }
  // L4a：常见端口探测兜底（127.0.0.1 监听即候选，框架端口已由库排除）
  for (const port of probePorts) {
    if (!seen.has(port) && await isLocalPortOpen(port)) seen.set(port, { port, pid: 0, process: "?", cmdline: "", addresses: ["127.0.0.1"] });
  }
  return [...seen.values()].sort((a, b) => a.port - b.port);
}
// L4b：手动输入（picker 末尾"其他端口…"）
```

> 暴露动作本身不依赖发现器：`st.auth.expose` 的端口门禁是
> `verifyPortOwner`（同 OS 用户，research F4）——发现器只为 UX 提供候选。

---

## 6. schema 驱动表单契约（src/forms.ts）

**数据源**：`st.schemas.tunnels(lang)` / `st.schemas.tunnel(type, lang)` /
`st.schemas.authProviders(lang)` / `st.schemas.metas()`。**新隧道类型 / 新
provider / 用户 env 注册的自定义隧道自动出现在表单**，扩展零改动（F6）。

**ParamSpec → 控件映射**：

| ParamSpec 字段 | 控件 | 产出 |
|---|---|---|
| `type: "string"` | InputBox（`placeholder`/`default` 预填；`required` 必填校验） | `string` |
| `type: "number"` | InputBox + 整数校验 | `number` |
| `type: "boolean"` | QuickPick 是/否（`default` 预选） | `boolean` |
| `type: "password"` | InputBox `password: true`（token 类） | `string` |
| `options[]` | QuickPick 单选（`label`/`labelKey` 国际化） | `option.value` |
| `fixed: true` | 只读展示（`value`），不可编辑 | `spec.value` |
| `default` | 预填；用户跳过则用默认 | — |
| `link`/`linkTitle` | 表单尾部"获取方式"链接（如 ngrok token 页） | — |

**渲染流程（expose 向导）**：

```
1. QuickPick 端口           ← 发现器候选 + "其他端口…"
2. QuickPick 模式           ← tunnel / proxy / both（默认 tunnel）
3. QuickPick 隧道类型       ← schemas.tunnels() 的 key + metas 描述
4. 逐项表单（当前 type）     ← 遍历 schemas.tunnel(type) 渲染（v1 起多字段表单；MVP 先 required+default 轮询）
5. QuickPick 认证           ← auto / none(若 noneAllowed) / provider 列表
6. provider 参数表单（可选） ← 遍历 schemas.authProviders(provider)
7. 提交 → manager.expose({ port, mode, tunnelType, tunnelParams, providerParams })
```

**提交参数**：tunnelParams = 步骤 4 产出的扁平 `{key: value}`（库内
`applyParamSets` 解构嵌套 + 校验，与 CLI `--set` 同语义，含 ssh 选项注入 /
INI 控制字符 fail-closed 校验）。providerParams 同理（`--provider-set`）。

**i18n**：`labelKey`/`descriptionKey` → `vscode.l10n`（未命中回退内置中文，
与库 `localizeSchemas` 一致）；扩展 UI 文案用库的 `t()`。

---

## 7. MVP 命令流（序列）

```
st: Expose Port…
  picker(端口) → 向导(模式/隧道/认证) → manager.expose()
    ├─ 成功 → statusBar「🌐 <url>」+ tree 新增 + output「URL / loginUrl」
    └─ 失败 → output 展示库错误（端口归属 / auth-none 禁止 / 工具下载失败…）+ toast 摘要

st: Stop Exposure
  tree 选中项 / 列表 → manager.stop(port) → 树移除 + 状态栏还原

生命周期
  activate → create + init（恢复）→ 监听
  deactivate → shutdown（清理 nginx/portal/隧道子进程；guardian:false 由本次兜底）
  窗口崩溃 → 子进程带 SERVICE_TUNNELS_ROLE 标记；下次启动按 state.json 清理
```

---

## 8. Phase 0 真机 spike 清单（验收标准）

| # | 验证项 | 通过标准 | 平台 |
|---|---|---|---|
| 1 | CJS 扩展宿主里 `await import("service-tunnels")` | 解析 node_modules 成功，`createServiceTunnels` 可用 | Win + macOS/Linux |
| 2 | **portal expose 冒烟**（验证 P1/ELECTRON_RUN_AS_NODE） | `st.auth.expose(port, { auth: "portal" })` 拉到公网 URL，登录页可达 | Win（portal 默认） |
| 3 | guardian（可选开关） | 启用后 kill -9 扩展宿主 → portal/隧道进程被回收 | 三平台 |
| 4 | 终端 shell integration 发现 | 终端 `npm run dev` → 端口出现在 picker | 三平台 |
| 5 | Task 发现 | Ctrl+Shift+B 起服务 → 端口出现在 picker | 三平台 |
| 6 | Windows discovery 延迟 | picker 打开 < 2s（PowerShell 进程表 + netstat） | Win |
| 7 | VS Code → Node 版本映射 | 核对该版本 product.json → `process.versions.node`，定 engines.vscode 精确值 | 全 |
| 8 | 崩溃恢复 | 杀扩展宿主后重开 → 上次隧道状态正确恢复/清理 | 全 |

**通过后进入 Phase 1 MVP 开发（3-5 天）。**

---

## 9. v1 认证管理 UX（细化）

> 目标：暴露即受保护（默认 auth auto），用户/2FA/token 管理闭环，
> 密码永不落明文，机器访问走 Bearer token。

### 9.1 首次暴露的用户引导（bootstrap）

库行为：`expose --auth` 首次初始化时若 site 无用户，自动创建初始用户
（admin + 随机密码，密码只在创建时返回一次）。扩展侧 UX：

```
expose 成功 → 检查该 site 用户数（authUserList）
  ├─ 0 用户 → 自动 authUserAdd(随机密码)
  │     → 密码存 VS Code SecretStorage（系统钥匙串）
  │     → toast「初始用户 admin 已创建，密码已保存到钥匙串；
  │        可用 st: Users… 查看/修改」
  └─ 有用户 → 直接展示 loginUrl（状态栏 + 树）
```

- **SecretStorage**（`context.secrets`）：初始密码可恢复；用户主动改密后更新；
  删除用户时清除。这是 VS Code 安全存储（钥匙串），比文件更稳。
- 安全兜底：即使密码只展示一次，也**永不写入日志/输出通道/telemetry**。

### 9.2 认证 TreeView（按 site 分组）

```
Service Tunnels（activity bar）
├─ Exposures             # 现有暴露（§7）
└─ Auth（每 site 一组）
   ├─ 👤 users            # 名 / provider / 2FA 状态
   ├─ 🔑 tokens           # 描述 / 创建时间 / 有效期 / 撤销
   └─ ⚙ 2FA              # 每用户启用状态
```

### 9.3 命令与流程

| 命令 | 流程 | 安全要点 |
|---|---|---|
| `st: Add User…` | QuickPick site → 输入用户名 → 密码（输入或自动生成） | 生成密码仅展示一次，可一键存钥匙串 |
| `st: Set Password…` | 选用户 → 新密码 | 校验与库 `validateUserName` 一致 |
| `st: Remove User…` | 选用户 → 确认 | 二次确认弹窗 |
| `st: Enable 2FA…` | 选用户 → `authTotpEnroll` → 展示 otpauth URL（可复制；v2 webview 渲染二维码）→ 输验证码激活 | 激活码输入（库要求验证后才生效，防 API 静默替换） |
| `st: Disable 2FA…` | 选用户 → 确认 | — |
| `st: Create Token…` | 描述 → 有效期 QuickPick（1h/24h/7d/30d/never）→ 展示 token 一次 → 复制 | token 只在创建时返回（库只存哈希）；过期自动失效 |
| `st: Revoke Token…` | 选 token → 确认 | 立即失效 |
| `st: Open Login Page` | 状态栏/树 → `openExternal(loginUrl)` | — |

### 9.4 Manager 接口扩展（v1 追加，保持可 mock）

```ts
// 追加到 IManager（§10.2 同名契约）
authUserList(site?): Promise<AuthUser[]>;
authUserAdd(name, { password?, displayName?, site? }): Promise<{ password?: string; providers: string[] }>;
authUserSetPassword(name, password, site?): Promise<void>;
authUserRemove(name, site?): Promise<void>;
authTotpEnroll(name, site?): Promise<{ secret: string; otpauthUrl: string }>;
authTotpDisable(name, site?): Promise<void>;
authTokenCreate({ description?, expiresAt?, site? }): Promise<{ token: string; id: string }>;
authTokenList(site?): Promise<Array<{ id: string; description?: string; createdAt: number; expiresAt?: number }>>;
authTokenRevoke(id, site?): Promise<void>;
```

- 内嵌实现直接调 `st.auth.*`；daemon 兜底调同名 RPC（`auth.user.*` / `auth.totp.*` / `auth.token.*`）；
- 机器访问指引：TreeView token 面板内嵌「curl 示例」复制按钮
  （`curl -H "Authorization: Bearer <token>" <url>/...`）。

### 9.5 安全自检（认证 UX 专项）

- 密码/secret 只经 SecretStorage 与一次性 toast；输出通道、错误捕获、
  日志文件一律脱敏（库 API 已剥离 secret，扩展不得自行落盘）；
- token 不持久化在扩展设置/workspace 文件；
- 2FA 激活必须二次输入验证码（库语义）；
- 无遥测：不采集任何用户/URL/访问数据。

---

## 10. 测试策略（扩展侧）

### 10.1 分层（与库 `npm test` 分离，扩展自有 npm scripts）

| 层 | 运行方式 | 依赖 | 覆盖 |
|---|---|---|---|
| **L0 纯 Node 单测** | `node --test extensions/vscode/test/unit/` | 无 VS Code | 表单映射、发现器合并、参数序列化、版本检查（可进 CI 主流程） |
| **L1 集成** | `@vscode/test-electron` 起扩展宿主 | VS Code 二进制 | activate/deactivate、动态 import、命令注册、进程清理 |
| **L2 e2e** | `@vscode/test-electron` + `ST_E2E=1` 门禁 | 网络/工具下载 | 真实 expose（bore 自建最稳）→ URL 可达 + 认证拦截 |

### 10.2 依赖注入（让 UI 逻辑可单测）

命令层只依赖 `Manager` 接口（§4），不依赖 `createServiceTunnels` 实现：

```ts
// src/manager.ts —— 可 mock 的接口 + 真实实现
interface IManager {
  expose(req: ExposeRequest): Promise<ExposeResult>;
  stop(port: number | string): Promise<void>;
  list(): ExposeInfo[];
  discoverPorts(opts?: { rootPid?: number }): ServicePortInfo[];
  tunnelSchemas(lang?: string): Record<string, ParamSpec[]>;
  authProviders(): { list: string[]; noneAllowed: boolean };
  on(event: string, cb: (e: unknown) => void): () => void;
  shutdown(): Promise<void>;
}
```

- 单测注入假实现（内存状态 + 固定 schema）→ 命令向导/表单/树视图逻辑全可测；
- 集成测试注入真实现但**不真暴露**（只 verify 调用参数）。

### 10.3 各层用例清单

**L0 单测**（`test/unit/`，纯 node --test）：
- forms：ParamSpec → 控件映射决策（type/options/fixed/required/default 分支）；
  值强制（number/boolean 解析，与库 `coerceParam` 同语义）；未知字段容忍；
  只读 fixed 不可编辑；
- discovery：四层 root 合并去重、probePorts 过滤（框架端口剔除）、手动输入分支；
- manager：tunnelParams/providerParams 扁平对象透传（与 CLI `--set` 同形状）；
  `versions()` 断言兼容（与库冻结测试联动）；
- util：semver 检查（`process.versions.node` ≥20.19 判定）。

**L1 集成**（`test/integration/`，@vscode/test-electron）：
- 扩展宿主里 `await import("service-tunnels")` 解析成功（**F1 真机验证项**）；
- activate 创建实例 + 订阅事件 + 命令注册；deactivate `shutdown()` 后
  **进程残留断言**（`pgrep -f daemon-server|portal` 为空，guardian:false 主清理路径）；
- 设置项读取（configDir/cacheDir 落到扩展私有目录）。

**L2 e2e**（`test/e2e/`，`ST_E2E=1` 才跑，避免 CI 网络抖动）：
- 本地起 echo 服务 → `manager.expose({ port, auth: "auto", tunnelType: "bore" })`
  （bore server 自建，零账号零公网依赖）→ 断言 `url` 非空 → 请求 URL：
  未带凭证 → 认证拦截（401/302 登录页）；带有效凭证 → 回显成功 → 清理；
- Windows 上 e2e 默认 skip（PowerShell 发现延迟已知，标记 `ST_E2E_WIN`）。

### 10.4 CI 矩阵（GitHub Actions）

```yaml
matrix: { os: [ubuntu-latest, windows-latest, macos-latest] }
steps:
  - 库构建 + L0 单测（node --test extensions/vscode/test/unit）
  - vsce package（验证打包不遗漏 node_modules/ESM 依赖）
  - L1 集成（@vscode/test-electron，三 OS）
  - e2e job（ubuntu only，ST_E2E=1，main/PR 手动触发）
```

### 10.5 风险回归清单（真机人工冒烟，进 Phase 0b 清单）

- `ELECTRON_RUN_AS_NODE` 在官方 VS Code 二进制（L1 集成覆盖，标注 known-true）；
- Windows discovery 延迟（L2 可选，人工计时）；
- 崩溃恢复（杀扩展宿主 → 重开 → 状态清理，人工）；
- 与 CLI daemon 并存时目录隔离无写冲突（人工双开验证）。

---

## 11. 里程碑对齐（含已落地项）

| Phase | 内容 | 状态 |
|---|---|---|
| 0a | 库侧适配补丁（P1 spawnNode + P2 guardian isMain）+ 单元测试 | ✅ 已落地（research §11） |
| 0b | 真机 spike 清单（§8） | ⏳ Phase 0 剩余 |
| 1 | MVP：骨架/命令/状态栏/发现器/生命周期/设置项 | 未开始 |
| 2 | v1：TreeView、认证与用户/2FA/token、schema 动态表单、多隧道、site | 未开始 |
| 3 | 生态：adaptation-kit + 参考实现 + CLI --json audit + schema 冻结 | 未开始 |
| 4 | 发布：公共 npm 迁移（前置阻塞）→ Marketplace | 未开始 |
