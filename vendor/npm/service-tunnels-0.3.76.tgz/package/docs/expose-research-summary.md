# expose 研究与应用路线摘要（总览）

> 本文是 service-tunnels 对外扩展研究的**执行摘要 + 文档地图**。
> 详细论证见各分册（§6 地图）。状态：调研完成，方案已定，待实施。

---

## 1. 一句话结论

**service-tunnels 的"隧道 × 认证 × 发现 × 嵌入"组合已是本赛道最完整的 expose
实现**；对外扩展的结论是——**核心 PR 基本不现实，插件/MCP 是主路**；一切对外
动作的唯一硬门槛（且为最终目标）是**公共 npm 发布**；当前内部阶段即可先落地
两个/三个通用底座：**`sts mcp`（MCP server）+ `st-expose`（pi 扩展）+ `sts-expose`（skill）**。

---

## 2. 调研对象与关键发现（一句话版）

| 对象 | 关键发现 | 对我们的意义 |
|---|---|---|
| pi-web（agegr / windli fork） | 已深度集成 service-tunnels；agegr 实际**积极合并 PR**（#352 先例） | 参考嵌入样板；PR 上提是唯一接入面（无插件系统） |
| OpenCode | `/share` 是会话分享（云端），**无端口隧道**；核心 feature PR 需设计评审 | **插件**（`@opencode-ai/plugin`：tool + BunShell）是主路 |
| PiClaw | VNC 查看器 + web 终端 + trust-proxy；无隧道；add-on 是官方扩展面 | **add-on**（runtime entry + web pane + catalog） |
| VS Code / Cursor | devtunnel CLI（免费无卡）；Ports 可见性 Private/Public | 新 provider `devtunnel` + 可见性语义（已有 VS Code 扩展蓝图） |
| Codespaces | 端口可见性三态 Private/Org/Public | 映射到现有 auth（none/token/site），语义层零新机制 |
| Claude Code | Desktop Preview 仅本地 | 内嵌预览 iframe（pi-web 层） |
| jmfederico/pi-web | 三层机制：Pi packages / Pi 扩展（服务器侧）/ PI WEB 插件（浏览器侧） | **Pi 扩展复用 + PI WEB 插件 UI**；PR 有品牌风险 |
| OpenChamber | 已有 `openchamber tunnel`（cloudflare/ngrok + QR） | 无插件系统 → MCP；PR 只做低侵入可选后端 |
| cc-connect（自家） | Go + ACP/MCP 层 + bridge；已有 pi/opencode 适配器 | **MCP client** 接入，验证 daemon API |
| 隧道工具生态 | pinggy/localhost.run/hop.to（ssh 免装）、zrok（开源双模）、devtunnel、tailscale serve/funnel | S/A 级新 provider（见 §3） |

---

## 3. 快速适配清单（S/A/B/C，详见 expose-landscape-plan.md §5-6）

| 档 | 项 | 预计 |
|---|---|---|
| **S**（纯配置/命令级） | pinggy / localhost.run / hop.to 三个 ssh 预设 provider；URL 已知域扩展；daemon 远程监听+用户认证；QR/复制分享（pi-web 层） | 0.5-1 天/项 |
| **A**（新 provider/语义层） | zrok（开源+可自建+公/私双模）；devtunnel（免费无卡）；tailscale serve/funnel（身份即认证）；端口可见性语义层 | 1-2 天/项 |
| **B**（新功能） | cloudflared named tunnel；auto-expose 提醒（守 D4）；内嵌预览；会话快照分享（opencode /share 自托管版）；trust-proxy 开关 | 2-5 天/项 |
| **C**（观望） | web 终端（node-pty）；VNC 查看器（noVNC）；移动端 PWA | 5 天+ |

---

## 4. PR × 插件决策矩阵（前提：公共 npm 最终公开）

| 生态 | PR 路线 | 插件路线 | 推荐 |
|---|---|---|---|
| **通用（MCP）** | — | `sts mcp` 薄适配层，覆盖所有 MCP 客户端 | **P0 三件套之一** |
| **pi 全家桶** | agegr PR（集成子集，有先例） | **pi 扩展** `st-expose`（一次开发全 fork 生效） | **扩展先、PR 后** |
| **OpenCode** | 核心 PR 高摩擦（设计评审） | **插件** `opencode-expose`（tool + permission 确认） | **插件** |
| **jmfederico** | PR 有品牌风险 | **Pi 扩展（复用）+ PI WEB 插件** | **插件** |
| **PiClaw** | 核心 PR（严格流程） | **add-on**（runtime entry + web pane + catalog） | **add-on** |
| **OpenChamber** | 低侵入可选后端（挂起） | 无插件系统 → MCP | **MCP 先行** |
| **cc-connect** | —（自家） | **MCP client** / bridge 动作 | **MCP** |
| **VS Code** | — | **扩展**（在研蓝图，宿主内嵌库 + daemon 兜底） | **扩展** |

**统一接口面**：插件/MCP 都走 **daemon JSON-RPC/HTTP**（S5 落地场景）；
CLI 是兜底、库模式是公共 npm 后增强；接口先于实现冻结。
**统一安全默认**：暴露前确认（opencode `permission.ask` / MCP `confirm` 参数 /
pi `ctx.ui.confirm`）；默认 `--auth auto`；`allow-auth-none` 全局开关不可绕过；
危险参数（`--tunnel command`）默认拒绝。

---

## 5. P0 三件套（5-6 个工作日，详见 p0-dual-base-design.md）

### 5.1 `sts mcp`（MCP server，M1-M3）
- 核心包内新增 `sts mcp` 子命令：手写最小 MCP stdio 协议（newline 分隔
  JSON-RPC 2.0），**零新增运行时依赖**；@modelcontextprotocol/sdk 仅 devDep
  做一致性测试（与 `docs/mcp-server-plan.md` 的设计张力见 §6 注记）。
- 工具：`list_ports` / `list_tunnel_providers` / `list_auth_providers` /
  `expose_port` / `stop_expose` / `list_exposes` / `auth_create_token` /
  `auth_list_tokens` / `auth_revoke_token` / `auth_list_users`。
- 后端：ensureDaemon()（CLI 自动拉起既有逻辑）→ daemon RPC；超时 90s/30s。
- 安全：auth 默认 auto、auth=none 受全局开关、端口越界拒绝、危险命令拒绝、
  工具 description 明示"向公网暴露"。

### 5.2 `st-expose`（pi 扩展，M4）
- 单文件 `st-expose.ts`（`~/.pi/agent/extensions/`，零依赖，jiti 热加载）。
- 工具：`expose` / `expose_stop` / `expose_list` / `ports` + `/expose` 交互命令。
- 安全：`tool_call` 事件钩子强制 `ctx.ui.confirm`（文档化模式）；v1 不暴露
  tcp 协议（走 ssh-gateway 语义，避免误用）。

### 5.3 `sts-expose`（skill，M5）—— CLI 的天然形态
- **skill = 文档化工作流**（Agent Skills 标准 `SKILL.md` + scripts），与
  MCP/pi 扩展（程序化工具）互补，覆盖 Claude Code / Codex / opencode 原生 /
  Cursor 等无 MCP/非 pi harness。
- **注册位置**：pi `~/.pi/agent/skills/` / Claude `~/.claude/skills/` / opencode
  `.opencode/skill/` / Codex `~/.codex/skills/`；一份技能多处引用（pi 已支持
  `skills: ["~/.claude/skills"]`）。
- **集中发布平台现状**：**官方无 registry**（agentskills.io 只有规范+示例仓库
  +Client Showcase）；社区集中目录正在涌现——tech-leads-club/agent-skills
  （~5k★，安全验证+npm 分发）、iflytek/skillhub（~4.9k★，企业自托管/中文友好）、
  Observal / agentregistry 等；各 harness 自己的包管理器是现实主路
  （pi packages / Claude plugin marketplace / opencode 插件）。
- **策略**：skill 随 service-tunnels 仓库/npm 包分发（低摩擦）→ 公共 npm 后
  按 "GitHub + npm（pi）→ opencode 插件 → tech-leads-club/agent-skills +
  skillhub" 扩渠道；不押注单一平台（标准保证内容可移植）。

### 5.4 里程碑
M1 协议骨架+只读工具+SDK 一致性测试 → M2 expose 生命周期+bore e2e →
M3 auth 工具+客户端接入文档 → M4 pi 扩展+冒烟 → M5 skill+注册+冒烟 →
M6 内部预装+文档。M1-M3、M4、M5 可并行。

---

## 6. 文档地图（按阅读顺序）

| 文档 | 内容 |
|---|---|
| **本文** | 执行摘要 + 决策矩阵 + 路线 |
| `docs/expose-landscape-plan.md`（840 行） | ① 横评与快速适配分级（§1-8）② 可学习项逐个深挖（§9）③ PR×插件双路线评估（§10-11） |
| `docs/p0-dual-base-design.md` | P0 三件套（`sts mcp` + `st-expose` + `sts-expose` skill）详细设计（D1-D6、工具清单、skill 注册/发布矩阵、测试、里程碑） |
| `docs/mcp-server-plan.md`（在研，333 行） | MCP Server 独立方案：薄协议适配器、LLM 即操作员安全门（`confirm: true`）、Smithery/mcp.so 注册 |
| `docs/vscode-extension-plan.md` / `-research.md` / `-implementation.md`（在研） | VS Code 扩展：宿主内嵌库 + daemon IPC 兜底、四层端口发现、schema 表单、Phase 0 验收 |
| `docs/idea-plugin-plan.md`（在研） | Java/IntelliJ 移植内嵌（共享同一套架构原则） |
| `docs/promotion-plan.md` | 公共 npm 发布阻塞项与清洗清单（一切对外动作的前提） |

> **注记（设计调和）**：`p0-dual-base-design.md`（D2：核心内 `sts mcp` 手写协议，
> 零依赖）与 `mcp-server-plan.md`（独立包 `service-tunnels-mcp` + 官方 SDK）存在
> 两案分歧。统一处理：**协议面与分发面分离**——`sts mcp` 是核心内的协议实现
> （零依赖卖点），`service-tunnels-mcp` 可作为可选分发包装（引用 `sts mcp` 或
> SDK 客户端均可）；实施时以 SDK 一致性测试锁定协议细节，若有偏差再退独立包。
> 两份文档的 daemon RPC 契约、schema 驱动、LLM 安全门（`confirm`/确认）结论一致。

---

## 7. 下一步建议

1. **P0 实施**（M1-M6，5-6 天）：`sts mcp` + `st-expose` + `sts-expose` skill
   先落地，内部宿主立即可用。
2. **S 级适配**（与 P0 并行）：三个 ssh 预设 provider + URL 域扩展（半天级
   收益，扩 provider 矩阵）。
3. **公共 npm 准备**（promotion-plan 阻塞项）：清洗清单核对，为将来公开
   铺路——所有插件/MCP/skill 在公共化后切换为库模式增强。
4. **对外节奏**：公共 npm 公开后 → opencode 插件 + cc-connect MCP（验证两条
   路径）→ agegr PR / jmfederico 插件 / PiClaw add-on / skill 集中 registry
   视反馈推进。
