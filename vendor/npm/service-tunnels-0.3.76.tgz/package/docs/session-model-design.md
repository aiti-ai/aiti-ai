# daemon IPC 必要性分析 + 会话模型（免 daemon）方案

> 评审对象：`src/daemon.ts` / `src/daemon-server.ts` / `src/cli.ts` / `src/index.ts` /
> `src/guardian.ts` / `src/state.ts`，`docs/design.md §4.9`。
> 问题：daemon IPC 是否必需？是否有更简单的设计（例如长生命周期命令不返回、类似
> ssh 连接）？是否应支持不用 daemon 的模式？参考 Gradle 的静默 daemon 做法？

> **审核**：本方案已按源码与 Gradle 官方文档逐条核对，修订见
> `docs/session-model-design-review.md`（3 处事实性错误、2 处 Gradle 参照偏差、
> 1 个现状 bug、1 处空闲判定遗漏）。

---

## 0. TL;DR

- **daemon IPC 对核心能力不是必需的**。证据：库模式 `createServiceTunnels()` 在调用方
  进程内实现了全部能力（发现/代理/隧道/网关/认证），零 IPC；`proxy --foreground`、
  `daemon start --foreground`、`ui` 也全部在进程内运行。
- daemon 真正买到的是三样东西：① CLI 短命进程之间的**跨调用连续性**；② **单一写者**
  串行化共享状态；③ **会话无关生命周期**（MCP/CI 客户端退出后隧道不中断）。这三样是
  "并发客户端 + 自动化"的诉求，不是"单用户交互"的诉求。
- **Gradle 是更贴合的参照**：它证明"**静默自动启动的 daemon**"是主流开发工具的标准
  做法——首次需要时后台拉起（提示一次）、后续隐式复用、空闲自动退出、版本不匹配时
  另起新版（旧的自然空闲退出）、`--status`/`--stop` 可查可停。本包现状已有雏形
  （tunnel/expose/proxy 的 auto-daemon），缺的是 Gradle 的关键实践（§2.3）。
- **ssh 前台模型是同一设计空间的反向端点**：命令不返回、Ctrl+C 即停、生命周期=进程
  ——适合容器/单命令脚本/调试，作为**免 daemon 逃生门**（`--no-daemon`）而非默认。
- **建议**（下文方案，演进式落地）：
  1. **保留 daemon 为默认**，补齐 Gradle 实践：版本戳 + 版本回收（停旧启新，借鉴非
     照搬——Gradle 是起新不杀旧）、**条件化空闲自动退出**（无运行中隧道/绑定/存活
     helper/ssh 网关时才退）、首次 auto-start 一次性提示、ssh 等命令统一 auto-start、
     `daemon status` 显示 version/startedAt；
  2. **新增 `--no-daemon`**（ssh 风格前台会话 = 免 daemon 模式）：操作在 CLI 进程内
     执行；start-like 命令（expose/tunnel start/proxy start/gateway start）变前台
     会话（URL 就绪打印 + 日志流 + Ctrl+C 清理），查询/停止类命令照常返回；
  3. **全部操作在无 daemon 时也可用**：读 state.json + 进程组信号 + 文件锁——停止类
     命令不依赖 daemon 存活；
  4. 自动化客户端（MCP/IDE/CI）默认 daemon（Gradle 模型，auto-start 自动满足），
     需要时内嵌库。
- 净效果：补齐 Gradle 实践后 daemon 变成"自管理基础设施"（自动拉起/复用/空闲退出/
  版本回收），用户几乎无感；`--no-daemon` 提供"零隐藏进程"的前台模式。两类需求各得
  其所：单用户交互默认无感复用 daemon；容器/单命令/调试走 `--no-daemon`；自动化
  客户端默认 daemon（Gradle 模型），必要时内嵌库。

---

## 1. 现状盘点：daemon 在做什么，成本在哪里

### 1.1 daemon 职责清单（判定"IPC 是否必需"的依据）

| # | 职责 | 现状实现 | 无 IPC 的替代路径 | 判定 |
|---|---|---|---|---|
| 1 | 持有隧道进程（跨 CLI 调用可见/可控） | daemon 内存 TunnelManager | state.json 记 pid/url + 进程组信号 | **可文件化** |
| 2 | 持有 nginx/authelia/redis 单例 | daemon 内存 + state.json 镜像 | reuse-if-alive（pid+starttime 探活，alive 则接管） | **可文件化（需新增 claim-or-reuse）** |
| 3 | expose 多步编排状态 | daemon 内存 | 本就以文件为准（tunnels.json/sites.json/state.json） | **已文件化** |
| 4 | proxy 注册表（D4 绑定） | daemon 内存 + state.json 镜像 | 已持久化 bindings，启动 restore（daemon-server 已做） | **已文件化** |
| 5 | 单一写者串行化 | 进程内天然串行 | 文件锁（O_EXCL + 重试/stale 清理） | **需新增文件锁** |
| 6 | IPC 边界校验（dangerous 门禁 / auth-none 禁令 / autheliaReloadCmd 阻断） | daemon RPC 层 | 库内已有同款双入口校验（index.ts / expose.ts） | **已具备（进程内同样生效）** |
| 7 | 跨客户端统一控制面（CLI/UI/MCP/IDE 共享） | RPC 方法面 | 各客户端内嵌库 | **客户端选择问题，非必须** |
| 8 | 会话无关生命周期（MCP 客户端退出隧道不断） | daemon 持有 | detached 会话（`--detach`） | **保留为 opt-in** |
| 9 | Windows IPC（无 unix socket → TCP + secret） | 127.0.0.1 + 每实例随机 secret | 前台会话根本不需要 IPC | **前台模式下整个消失** |
| 10 | 崩溃兜底清理（guardian 看护 daemon） | `spawnGuardian(process.pid)` | 前台模式由 shell/进程组兜底；detached 仍需 guardian | **前台模式消失** |

**结论：仅 1/2/5 是真正的 "IPC 依赖"**，且全部有文件/信号替代路径；其余要么本来就
以文件为事实源，要么是客户端形态选择问题。

### 1.2 daemon 的成本（逐条对应源码）

- `src/daemon.ts`：`pidAlive()` 的 zombie 检测（`/proc/<pid>/stat` 'Z'）、`stopDaemon()`
  的 `spawnSync("sleep")` 忙等轮询、`requestDaemon()` 的 5s 超时 + 无法区分
  "daemon 不在"与"daemon 拒绝"的 ambiguous null。
- `src/daemon-server.ts`（728 行）：整个 JSON-RPC 服务端 + Windows TCP+secret +
  `spawnGuardian(process.pid)` + 重启 rehydrate（`tunnels.hydrate` / `proxy.restore`）
  语义。
- `src/cli.ts`：`tunnel`/`expose`/`proxy` 分支的"auto-start daemon + 轮询等 socket
  （5s deadline）"样板。
- `state.json` 的 `daemon{pid,ipc,ipcSecret}` 块 + 每次调用前的 liveness 检查。
- 语义债务：daemon RPC 返回 null 时 CLI 只能打印泛化错误（见 cli.ts `expose` 分支的
  "rejected by daemon"）。

**这些成本在纯前台会话模式下全部消失**：没有 detached 进程 → 没有 zombie/guardian/
等待 socket；没有 IPC → 没有 secret/超时/ambiguous null；命令退出即清理 → 没有
rehydrate 语义。

---

## 2. 参照系：ssh 前台模型 vs Gradle 静默 daemon

### 2.1 SSH：前台会话是隧道工具的答案

| | ssh | 本包现状 | Gradle 参照 | 本方案 |
|---|---|---|---|---|
| 长生命周期单位 | 前台会话 | detached daemon | 静默 daemon | daemon（默认）/ 前台（`--no-daemon`） |
| 跨调用控制 | 无（除非控制 socket） | IPC RPC（必经路径） | RPC（必经路径） | RPC（快速路径），信号+文件兜底 |
| 生命周期 = 进程 | 是 | 否（daemon 持有） | 否（daemon 持有） | 默认否；`--no-daemon` 时是 |
| 后台化 | shell `&` / `-f` | 内置 daemon start | 自动（静默） | 自动（静默，Gradle 式） |
| 清理 | Ctrl+C / 进程组 | guardian + daemon shutdown | 空闲自动退出 + `--stop` | 空闲自动退出 + `stop-all` |

ngrok / cloudflared tunnel / bore / ssh -R 全部是前台会话：命令不返回、输出 URL、
日志流、Ctrl+C 停止——**隧道工具阵营的主流**。但构建工具阵营（Gradle / kotlin daemon）
恰恰相反：**静默 daemon**（§2.3）。两个模型各自主流于不同的"长生命周期"形态：隧道是
"用户看着它跑"，构建是"用户不关心它怎么跑"。本包两种形态都涉及（expose 像隧道，
`tunnel start`/UI 更像后台服务），所以方案取**Gradle 式 daemon 默认 + ssh 式
`--no-daemon` 逃生门**。

### 2.2 澄清："不是每个命令都不返回"

只有**持有长生命周期进程**的命令不返回：

- 不返回（前台会话）：`expose`、`tunnel start`、`proxy start`、`gateway start`、`ui`
- 返回：查询类（`status`/`list`/`discover`/`config`）、配置变更类（`tunnel add`/
  `auth user add`/`site add`）、停止类（`tunnel stop`/`expose stop`/`stop-all`——读
  state.json 发信号）

不变量：**前台命令退出 == 对应服务已停止**（无孤儿，by construction）。

### 2.3 Gradle 参照系：静默 daemon 的具体做法

Gradle（以及 kotlin daemon、部分 IDE 后台进程）是"**daemon 作为隐式基础设施**"的
成熟范例：用户不管理 daemon，daemon 由工具自动拉起/复用/回收。这比 ssh 前台模型更
贴合本包现状——`expose`/`tunnel start` 这类"命令返回但服务常驻"的场景本来就是 daemon
模型的主场；问题不在"有没有 daemon"，而在 daemon 是否**规矩**：

| Gradle 实践 | service-tunnels 现状 | 差距 |
|---|---|---|
| 首次构建静默拉起 daemon（提示一次 "Starting a Gradle Daemon"） | tunnel/expose/proxy 已 auto-start，但**无任何提示**；`ssh *` 子命令**不** auto-start（daemon 未跑时返回 null） | 缺：一次性启动提示；ssh 命令补 auto-start；所有 daemon 依赖命令统一行为 |
| 版本戳：daemon 与 CLI 版本不一致 → 起新；旧的自然空闲退出（Gradle 语义，不主动杀） | state.json daemon 块只有 `{pid, ipc}`，无版本 | 缺：加 `version`/`protocol`/`startedAt`；本方案因**有状态单 daemon 模型**改为停旧启新（借鉴非照搬，回收前 ping 护栏，见 §6 #9） |
| 空闲自动退出（默认 3h）+ `--stop` 手动停 | 无空闲退出；daemon 活到 `stop-all`/机器重启 | 缺：**条件化**空闲退出（见下） |
| daemon 可随时杀死重来，文件全可丢弃 | state.json 可丢弃 + 启动 rehydrate（daemon-server 已做） | ✅ 已有 |
| `gradle --status` / `--stop` | `daemon status` / `daemon stop` | ✅ 已有（status 补 version/startedAt） |
| daemon 崩溃 → 下次调用透明重启 | `daemonStatus` 探活（含 zombie 检测）+ auto-start | ✅ 已有 |
| 单 daemon 复用（同版本/同用户） | 单 daemon per cacheDir | ✅ 已有 |
| `--no-daemon`（进程内执行，命令返回） | 库模式即进程内；CLI 无该开关 | 缺：CLI `--no-daemon` 逃生门 |

**关键差异（决定"空闲退出"怎么做）**：Gradle daemon 是**无状态**的（build cache 在
盘上），空闲退出不丢任何东西；本包 daemon 是**有状态**的——持有隧道进程/代理绑定/
网关 helpers/ssh 网关。因此空闲退出必须**条件化**：仅当"无运行中隧道 ∧ 无代理绑定 ∧
无存活 internal helpers ∧ **无 ssh 网关监听中**（SshManager 在 daemon 进程内监听，
daemon 退出即断服务，见 review §2.6）"时才允许计时退出；有任一活资产时 daemon 必须
存活（这正是它存在的意义）。全部资产停掉后启动 N 分钟空闲计时（默认建议 10–30
分钟，可配 `SERVICE_TUNNELS_DAEMON_IDLE_MS`），到时无新活动即优雅 shutdown（复用
现有 `shutdown` RPC 路径；非 Linux 上需按 pid 列表补清理，见 review §2.2）。

---

## 3. 设计空间

### 设计 A：维持现状（daemon + IPC 为必经路径）
- 优点：单写者串行、会话无关生命周期、跨客户端统一控制面（今天的 mcp-server-plan
  选它的原因）。
- 缺点：§1.2 全部成本（无空闲退出、无版本戳、无提示、ssh 命令不 auto-start）；
  容器/单命令脚本 awkward。

### 设计 A2：Gradle 式静默 daemon（改进现状，推荐默认）
- 现状 A + §2.3 补齐项：版本戳/版本回收、条件化空闲退出（含 ssh 网关）、一次性启动
  提示、ssh 等命令统一 auto-start、`daemon status` 补字段；外加 `--no-daemon` 逃生门。
- 优点：保留 daemon 全部收益（单写者、会话无关、跨客户端统一），UX 与 gradle 对齐
  （用户无感、命令照常返回、daemon 自管理）；`--no-daemon` 覆盖"不想有隐藏进程"的
  场景。
- 缺点：仍保留守护/IPC 代码（但空闲退出/版本回收把"daemon 管理"变成自管理）；
  `--no-daemon` 前台会话仍需 §4.2 的免 daemon 操作层（state.json + 信号 + 文件锁）。

### 设计 B：纯前台会话（ssh 模型，零 daemon）
- `sts expose 5173` 前台；`--detach` 后台化；`sts tunnel stop web` 读 state.json →
  进程组信号。
- 单例复用：Gateway/Redis/AuthRegistry 增加 claim-or-reuse（internal 表 + liveness，
  复用 `daemon.ts` 的 pidAlive/zombie 逻辑）。
- 并发写：文件锁（git index.lock 风格）。
- 优点：运行时成本最低；与 ngrok/ssh UX 一致；容器友好；命令退出即清理。
- 缺点：并发客户端需锁纪律；UI/其他进程看不到前台会话的 in-memory exposes 列表
  （但关键结果已落 state.json，见 §6.3）。

### 设计 C：前台会话 + 可选控制 socket（ssh -M 模型）
- B + 会话可开控制 socket（默认 `cacheDir/sessions/<name>.sock` 或 `--control-socket`），
  复用现有 newline JSON-RPC 帧（把 daemon-server.ts 的 `serveSocket`/`handleLine`/
  `requestDaemon` 抽成 `src/ipc.ts`）。
- `sts <op>` 解析顺序：state.json 有存活 controlSock → RPC；否则 → 信号+文件。
  **IPC 从必经路径降级为快速路径**。
- 优点：B 的全部收益 + 跨调用丰富操作（实时状态/事件）仍可用；代价是保留一小块
  RPC 服务器代码。

### 设计 D：交互前台 + 自动化内嵌库，砍掉共享 daemon
- 交互用户走 B/C 的 CLI；自动化（MCP/CI/IDE/UI）**进程内嵌库**（已支持、零 daemon）；
  确需会话无关生命周期时用 `--detach` 会话（等价今天的 daemon，但只是一类会话，
  不是体系）。
- 优点：客户端不再被单一共享 daemon 绑定，各自选择生命周期语义；daemon 从
  "基础设施"降级为"可选会话类型"。
- 缺点：多个自动化客户端各自内嵌 = 各自进程树，状态靠文件协调（锁纪律）；
  MCP"会话退出隧道不断"的诉求需显式 `--detach`。

### 3.1 对比

| 维度 | A 现状 | A2 Gradle 式 | B 纯前台 | C 前台+socket | D B/C+内嵌客户端 |
|---|---|---|---|---|---|
| 运行时复杂度 | 高 | 中 | 最低 | 低 | 低 |
| 单用户交互 UX | 异类 | 主流（无感复用） | ssh 风格 | ssh 风格 | ssh 风格 |
| 跨调用控制 | ✅ RPC | ✅ RPC | ⚠️ 信号+文件 | ✅ socket 优先 | ✅ 视会话形态 |
| 并发写安全 | ✅ 单写者 | ✅ 单写者 | ⚠️ 文件锁 | ⚠️ 文件锁 | ⚠️ 文件锁 |
| 自动化/CI | ✅ | ✅ | ⚠️ 需 --detach | ✅ | ✅ 内嵌/--detach |
| 容器/单命令 | ❌ 繁琐 | ✅（--no-daemon） | ✅ | ✅ | ✅ |
| 崩溃清理 | guardian | guardian | shell/进程组 | shell/进程组 | 同左 + guardian |
| 代码增量/删除 | — | 小增量 | 最大改动 | 中 | 中 |

---

## 4. 推荐方案：Gradle 式 daemon 默认 + `--no-daemon` 逃生门，演进式落地

原则：**daemon 是默认（补齐 Gradle 实践）；`--no-daemon` 是逃生门（ssh 前台模型）；
IPC 是优化不是依赖；全部操作在 daemon 缺席/死亡时也可用。**

### 4.1 用户可见语义变更

```text
# 默认（Gradle 式）：sts expose 5173 → 静默 auto-start daemon（首次提示一次）
#   → 命令返回，打印 URL；daemon 持有隧道；空闲（无活资产）自动退出

sts expose 5173                 # 默认：daemon 持有，命令返回，打印 URL
sts expose 5173 --no-daemon     # 免 daemon：进程内前台会话（URL 就绪打印 + 日志流，Ctrl+C 停）
sts tunnel start web            # 默认同上（daemon 持有）
sts tunnel start web --no-daemon# 前台会话
sts tunnel stop web             # 读 state.json（或控制 socket）→ 进程组 SIGTERM；daemon 死没死都 work
sts daemon status               # 显示 version / pid / startedAt / 活跃隧道数
sts daemon stop                 # 优雅退出（等当前操作完成）——gradle --stop 语义
```

> 注：`--no-daemon` 与 Gradle 的 `--no-daemon` 语义不同——Gradle 是"构建在 client
> JVM 完成、命令照常返回"；本包 start-like 命令是**常驻服务**，`--no-daemon` 只能
> 前台持有（命令不返回）。查询/停止类命令在 `--no-daemon` 下才与 Gradle 一致。

**daemon 自管理（Gradle 实践落点）**：
- 版本戳：state.json daemon 块加 `version`/`protocol`/`startedAt`；`daemonStatus`
  发现不匹配 → SIGTERM 停旧 + auto-start 新版（回收前 ping 确认空闲，参照 gradle
  `--stop`"等当前构建完成"；此为借鉴非照搬——Gradle 是起新不杀旧，见 §2.3）；
- 条件化空闲退出：无运行中隧道 ∧ 无代理绑定 ∧ 无存活 internal helpers ∧ 无 ssh
  网关监听中 → N 分钟（默认 15，可配 `SERVICE_TUNNELS_DAEMON_IDLE_MS`）无活动则调
  `shutdown` RPC 优雅退出（非 Linux 上补按 pid 清理，见 review §2.2）；
- 一次性提示：首次 auto-start 打印 `service-tunnels daemon started (pid X)`，之后
  静默复用（gradle "Starting a Gradle Daemon" 语义）；
- 统一 auto-start：`ssh *` 等剩余命令补齐（与 tunnel/expose/proxy 一致）。
- **M1 前置修复**（现状 bug，方案依赖的前提）：① `state.json` 的 `internal` 表从不
  被持久化（daemon 与库模式都不写）——claim-or-reuse 依赖的 internal 镜像要先建立；
  ② daemon 日志从未落盘（`logPath` 计算了但 spawn `stdio` 全 ignore，`daemon logs`
  指向空文件）——先修 `logFile` 重定向，否则"check daemon logs"是空指引（详见
  docs/session-model-design-review.md §2）。

### 4.2 免 daemon 操作层（核心工程：让每条命令在无常驻进程时也能完成）

1. **state.json 扩展 `sessions` 表**：

   ```jsonc
   "sessions": [{
     "kind": "expose" | "tunnel" | "proxy" | "gateway" | "ui",
     "name": "web",
     "pid": 12345,
     "starttime": 234234234,        // pid 复用防护（复用 guardian 的 readStarttime）
     "controlSock": "unix://...",   // 可选（--detach 默认开，前台 opt-in）
     "detached": true,
     "startedAt": 1700000000000
   }]
   ```
   `tunnels`/`bindings` 已有镜像；sessions 让停止/状态类操作无需 IPC。
   前台会话也要把 internal 注册表发布到 state.json——**现状 daemon 与库模式都不写
   state.internal**（daemon-server 只 rehydrate 从不 persist，见
   docs/session-model-design-review.md §2.1），这是 M1 前置修复，也是 claim-or-reuse
   的前提。

2. **两类停止路径**（`killSession()`，抽公共）：
   - **隧道（detached 子进程，独立进程组）**：复用 tunnels.ts 的 groupKill——POSIX
     `process.kill(-pid, sig)`（整个进程组），SIGTERM → 等待 → SIGKILL 兜底；Windows
     `process.kill(-pid)` 不支持（tunnels.ts 的 catch 回退 `child.kill(sig)` 只杀直接
     子进程）——封装 `taskkill /PID <pid> /T`。
   - **nginx/authelia/redis（非 detached，与持有者同进程组，`kill(-pid)` 不可用）**：
     按 pid 列表逐个 kill——pid-registry 的 `registered-pids-<pid>.json` 跨平台，
     无需 /proc（cleanup.ts 的角色清扫是 Linux-only，见 review §2.2/§2.3）。
   - 停止类命令：读 state.json → 校验 pid+starttime → `killSession()`。

3. **单例 claim-or-reuse**（替代"daemon 是唯一 nginx/authelia/redis 持有者"）：
   - 前提（M1）：internal 持久化先落地（见 review §2.1）——否则 state.json internal
     表永远是空/陈旧，"接管"永远走不到。
   - Gateway/Redis/AuthRegistry 增加 `claimOrReuse`：先查 state.json internal 表
     （role → pid/port）+ liveness（pid + starttime，复用 pidAlive 的 zombie 处理），
     alive 则**接管**（注册 host / 写配置 + `nginx -s reload` / authelia 配置重写+
     重启——这些本就走文件+信号，不依赖 IPC）；死了则清表并自己 spawn。
   - 端口冲突本就不存在：随机端口 + reuse 命中同一实例。
   - 注意：库模式（内嵌）与 daemon 模式目前都不写 internal——M1 统一
     "持有单例者发布 internal 表"的行为。

4. **文件锁**（并发写者：前台会话 / --detach / UI / 内嵌库）：
   - 新增 `src/lockfile.ts`：`O_EXCL` 原子创建 `<target>.lock`（git index.lock 风格）
     + 写入持有者 pid/starttime + 重试/超时（默认 5s）；异常退出靠 starttime 探活
     清理 stale 锁。
   - 上锁的写路径：tunnels.json、sites.json、state.json、authelia config-tunnels.yml、
     nginx 配置目录。读路径无锁。
   - 单进程库模式（内嵌）内部已有串行假设，不需额外锁（state.ts 注释已声明
     "single writer assumed"）。

### 4.3 `--no-daemon` 前台执行（ssh 风格逃生门）

- `--no-daemon`（env `SERVICE_TUNNELS_NO_DAEMON=1` 亦可）：操作在 CLI 进程内执行。
  `expose` / `tunnel start` / `proxy start` / `gateway start` / `ui` 变前台会话：把
  daemon-server.ts 的核心循环抽成可内嵌的 `runSession()`（进程内已有全部能力，见
  index.ts 库模式），stdout 流式输出（URL 就绪即打印，之后隧道/网关日志），信号处理
  （SIGINT/SIGTERM → 进程组清理 → 退出，即 daemon shutdown 的同一路径）。
  **前台日志流同时修复"daemon 日志不可见"现状 bug**（daemon 模式日志从未落盘，
  见 review §2.7）。
- 前台会话必须 **spawn guardian（`guardian: true`）**：cli.ts 现为全局 `guardian:
  false`，不 spawn guardian 则 SIGKILL 后 nginx/authelia/redis 是持久孤儿
  （cleanupStaleDirs 只删文件不杀进程，见 review §2.8）。
- 查询/停止类命令在 `--no-daemon` 下照常返回（本就不依赖 daemon）。
- 前台会话同样把 sessions/internal 发布到 state.json（§4.2），因此另一终端的
  `tunnel stop` / `status` 可见可控。

### 4.4 控制 socket（现状保留 + ssh -M 式 opt-in）

- 默认 daemon：维持现状 socket（unix / Windows TCP+secret），跨调用 RPC 不变。
- `--no-daemon` 前台会话：`--control-socket <path>` opt-in（默认不开——单终端用户
  不需要）；从 daemon-server.ts 抽 `src/ipc.ts`（serveSocket / handleLine /
  requestDaemon 现成）供复用。
- `sts <op>` 解析顺序：读 state.json → 有存活 controlSock → RPC；否则 → 信号 + 文件
  （§4.2）。**IPC 从必经路径降级为快速路径**。

### 4.5 客户端策略

- **MCP / IDE / 宿主**：默认**内嵌库**（进程内、零 daemon、今天已支持）；确需会话
  无关生命周期（客户端退出隧道不断）时，默认 daemon 的 auto-start 自动满足（Gradle
  模型）——无需客户端管理 daemon。
- **mcp-server-plan 结论基本维持**：C（daemon 托管）仍是自动化客户端的合理默认——
  Gradle 模型补齐空闲退出/版本回收后，daemon 是"自管理基础设施"而非负担；内嵌库
  （A）作为兜底不变。安全门继承关系不变（库内双入口校验已具备，§1.1 #6）。
- **UI**：`sts ui` 内嵌库前台会话（今天已支持）；后台 UI 用 `ui --daemonize`（已有）。

---

## 5. 实施里程碑

### M1 — daemon 补齐 Gradle 实践（不动 UX，先让 daemon"规矩"）
- [ ] **前置修复**：state.internal 持久化（register/unregister 同步写 state.json，
      daemon 与前台会话都发布——review §2.1）；daemon 日志落盘（`logFile` 重定向
      spawn stdio + 简单轮转，review §2.7）
- [ ] state.json daemon 块加 `version`/`protocol`/`startedAt`；版本不匹配 → 停旧启新
      （回收前 ping 确认空闲）
- [ ] 条件化空闲退出：无运行中隧道 ∧ 无代理绑定 ∧ 无存活 internal helpers ∧ 无 ssh
      网关监听中 → N 分钟无活动优雅 shutdown（复用现有 `shutdown` RPC；非 Linux 上
      按 pid 列表补清理——review §2.2）
- [ ] 首次 auto-start 一次性提示；`ssh *` 等命令统一 auto-start（与 tunnel/expose/
      proxy 一致）
- [ ] 免 daemon 操作层：state.json `sessions` 表 + `killSession()`（隧道=进程组信号，
      helpers=按 pid 注册表 kill，review §2.3）+ `src/lockfile.ts`（O_EXCL +
      stale 清理）——停止/状态类命令在 daemon 缺席/死亡时也可用
- 验收：`sts expose 5173` 后 `sts tunnel list`/`sts expose stop` 可用；隧道全停后
  daemon 空闲自动退出（ssh 网关在跑时不退）；旧版 daemon 在跑时新 CLI 自动回收重启；
  `daemon logs` 有内容。

### M2 — `--no-daemon` 逃生门（免 daemon 模式）
- [ ] 抽 `runSession()`（daemon-server 核心循环 → 可内嵌）+ `src/ipc.ts`（帧复用）
- [ ] `--no-daemon`（env `SERVICE_TUNNELS_NO_DAEMON=1`）：start-like 命令前台会话
      （URL 就绪打印 + 日志流 + Ctrl+C 清理）；查询/停止类照常返回
- [ ] Gateway/Redis/AuthRegistry 加 `claimOrReuse`（internal 表 + liveness）——
      前台会话与 daemon 共存时复用单例
- 验收：`sts expose 5173 --no-daemon` 前台跑、另一终端 `sts tunnel list` 可见、
      Ctrl+C 后 state 干净（无孤儿）。

### M3 — 控制 socket 统一解析
- [ ] 默认 daemon 维持现状 socket；前台 `--control-socket` opt-in
- [ ] `sts <op>` 解析顺序：state.json 有存活 controlSock → RPC；否则 → 信号 + 文件
      （M1 降级路径）
- 验收：socket 文件消失（进程已死）后 `sts tunnel stop` 走信号仍成功。

### M4 — 客户端修订 + 文档
- [ ] mcp-server-plan / vscode-extension-plan：daemon（Gradle 模型）默认不变，
      `--no-daemon`/内嵌为兜底
- [ ] README / docs/cli.md / docs/design.md §4.9 更新；CHANGELOG 标注（--no-daemon
      新增、daemon status 字段、空闲退出、版本回收）

---

## 6. 风险与未决问题

1. **并发写**：前台会话（多终端）+ detached + UI + 内嵌库并发写 tunnels.json /
   state.json 需锁纪律。缓解：M1 文件锁 + 原子 tmp+rename（已有）+ 写路径统一过
   lockfile。单用户交互几乎不并发，风险低；自动化多客户端建议仍走单一 detached
   会话（单写者天然串行）。
2. **Windows**：无 unix socket（控制 socket 用 TCP + secret，已有实现）；进程组
   kill 需 `taskkill /T` 封装（tunnels.ts 的 `kill(-pid)` catch 回退只杀直接子进程，
   不够）；前台 Ctrl+C 在 console 可用，需实测 `--detach` 下 secret 生命周期。
   **另注**：cleanup.ts 的 `killRoleProcesses`/guardian 的 `collectDescendants` 均为
   Linux-only（`/proc`）——macOS/Windows 上 daemon shutdown 与 guardian 只靠 pid 注册
   表（`registered-pids-<pid>.json`）清理；空闲退出路径必须按 pid 列表补清理
   （review §2.2）。
3. **UI 与前台会话的 in-memory 状态**：`exposes()` 是进程内记录（"为显示、不持久"，
   见 index.ts），前台会话的列表不会被 UI 看到——但 expose 关键结果（URL/隧道 pid/
   绑定）都已落 state.json，UI 展示不受影响。若 UI 需要"哪个前台会话活着"，读
   sessions 表即可。
4. **guardian**：前台 `--no-daemon` 会话必须 spawn guardian（`guardian: true`，
   cli.ts 现为 false）——SIGKILL 后 nginx/authelia/redis 靠 guardian 按注册 pid 清理；
   cleanupStaleDirs 只删目录/注册文件不杀进程（review §2.8）。detached 会话继续
   spawn guardian（现状）。
5. **API 兼容**：`st.daemon.*` 保留（现在就是显式 API）；新增 `st.sessions.*`
   （list/stop/status）。CLI 输出格式变更需 CHANGELOG 注明。
6. **expose 的等待语义**：前台模式下 `expose` 必须等 URL 就绪再进入日志流，否则
   用户看不到 URL——现 daemon RPC 的 90s 超时逻辑改为"就绪事件 + 后续日志流"。
7. **多实例 cacheDir**：多个 `--cache-dir` 指向同一目录的并发会话共享锁——锁路径
   基于 cacheDir，天然覆盖。
8. **空闲退出的安全边界**：daemon 空闲判定必须覆盖"它自己拥有的任何活资产"——运行中
   隧道、代理绑定（proxy transport 在服务绑定）、存活的 internal helpers
   （nginx/authelia/redis）、**以及 ssh 网关监听中**（daemon 进程内 SSH 服务，退出即
   断连接；daemon 重启会自动 restore，但服务中断是实时的）。任一存在即不算空闲；
   隧道全停后才启动计时。误杀即停服务，宁可保守（默认计时 15 分钟，比 Gradle 的 3h
   短得多但足够覆盖交互间隙）。
9. **版本回收 vs 进行中的操作**：停旧启新不能打断正在跑的 expose 流程——参照 gradle
   `--stop`"等当前构建完成"，回收前先 ping 并等待（带超时），超时才强停。

---

## 7. 与现有文档/客户端的衔接

- `docs/design.md §4.9`：进程模型一节重写为"会话模型"（Gradle 式 daemon 默认 +
  `--no-daemon` 前台逃生门）。
- `docs/cli.md`：daemon 段补空闲退出/版本戳/一次性提示；expose/tunnel 示例补
  `--no-daemon`。
- `docs/mcp-server-plan.md`：架构结论基本维持（C daemon 托管为主、A 内嵌兜底）——
  daemon 补齐 Gradle 实践后是自管理基础设施；安全门继承关系不变。
- `docs/vscode-extension-plan.md`：本就推荐"内嵌库 + daemon 兜底"——结论不变，
  兜底可加 `--no-daemon`。
- `docs/idea-plugin-plan.md`：Java 客户端"daemon IPC 桥接"仍是合理默认（daemon 保留）；
  标注可选的前台/内嵌替代。

---

## 8. 一个底线判断

不要为了删 daemon 而删 daemon：**自动化多客户端 + 会话无关生命周期**（CI 里
`sts expose` 后进程退出、URL 长期有效；MCP 会话结束隧道不断）是真实需求，daemon
（Gradle 式，含控制 socket）必须保留为默认。本方案的价值在于把 daemon 从"需要用户
管理的隐藏进程"变成"工具自管理的基础设施"，并保留一条 `--no-daemon` 逃生门：

> **daemon 负责"命令返回但服务常驻"；`--no-daemon` 负责"生命周期 = 进程"。**

单用户交互默认无感复用 daemon；容器、单命令脚本、调试走 `--no-daemon` 前台会话；
自动化客户端默认 daemon，必要时内嵌库。
