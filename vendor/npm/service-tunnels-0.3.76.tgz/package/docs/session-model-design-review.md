# 方案审核报告：daemon 会话模型（session-model-design.md 深入审核）

> 审核对象：`docs/session-model-design.md`（Gradle 式 daemon 默认 + `--no-daemon` 逃生门）。
> 审核方法：逐条核对方案断言与源码（`src/daemon.ts` / `daemon-server.ts` / `cli.ts` /
> `index.ts` / `tunnels.ts` / `cleanup.ts` / `guardian.ts` / `state.ts` 等）及 Gradle
> 官方文档（docs.gradle.org/…/gradle_daemon.html, 9.7.0）。
> 审核日期：2025 年 2 月（对应代码版本 0.3.32）。

---

## 0. 结论摘要

**方案方向成立，推荐可落地，Gradle 参照有据**；但审核发现：

- **3 处事实性错误**（方案的"已有条件"其实不存在或比方案写得弱）：
  1. `state.json` 的 `internal` 表**从不被持久化**——方案 §4.2 "tunnels/internal/bindings
     已有镜像" 对 internal 不成立，claim-or-reuse 的地基（查 state.json internal 表）当前
     是空/陈旧数据；
  2. `killRoleProcesses` / `killRoleProcessesSync` / guardian 的 `collectDescendants`
     **全部 Linux-only**（`process.platform !== "linux"` 直接返回）——macOS/Windows 上
     现有 daemon shutdown 本来就留 nginx/authelia/redis 孤儿，方案的空闲退出若复用
     `shutdown` RPC 会继承该缺口；
  3. **nginx/authelia/redis 的 spawn 不带 `detached`**——它们不是独立进程组，方案 §4.2
     的 `killSession()` 进程组信号（`kill(-pid)`）只对隧道有效，对 gateway/redis/provider
     无效。
- **2 处 Gradle 参照偏差**（需向读者/用户明示，避免按 Gradle 直觉误用）：
  4. Gradle 的版本兼容是"**起新不杀旧**"（不兼容就另起 daemon，旧的自然 3h 空闲退出），
     方案写"停旧启新"是借鉴而非照搬，应标注；
  5. Gradle 的 `--no-daemon` 是"构建在 client JVM 完成、**命令照常返回**"；方案的
     `--no-daemon` 因服务常驻本质只能定义为**前台会话（不返回）**——两者语义不同。
- **1 处现状 bug 未被方案指出**：
  6. **daemon 日志从未落盘**：`startDaemon` 计算了 `logPath` 但 spawn 时 `stdio` 全
     `ignore`，`daemon logs` 指向的文件不存在/为空——expose 失败诊断链断裂（CLI 提示
     "check daemon logs"，但日志是空的）。方案 §4.3 前台日志流恰好解决它，但应显式列为
     M1 修复项（`logFile` 重定向）。
- **1 处空闲判定遗漏**：
  7. 空闲条件漏了 **ssh 网关**（SshManager 在 daemon 进程内监听端口，且 daemon 启动时
     `#load()` 自动 restore 并 start）——daemon 空闲退出会杀掉正在服务的 ssh 网关。

**审核结论**：方案的核心主张（daemon 是自管理基础设施、`--no-daemon` 是逃生门、停止类
命令不依赖 daemon 存活）全部成立；修订以下小节即可进入 M1 实施。

---

## 1. 事实核对表（方案断言 vs 源码/官方文档）

| # | 方案断言 | 源码/文档位置 | 结论 |
|---|---|---|---|
| 1 | daemon-server 728 行 | `wc -l` = 733 | ⚠️ 733（可忽略） |
| 2 | `pidAlive` zombie 检测（`/proc/<pid>/stat` 'Z'） | `daemon.ts:20` | ✅ |
| 3 | `stopDaemon` 用 `spawnSync("sleep")` 忙等轮询 | `daemon.ts:136` | ✅ |
| 4 | `requestDaemon` 5s 超时 + 无法区分"不在/拒绝"的 null | `daemon.ts:50` | ✅ |
| 5 | state.json daemon 块 `{pid, ipc}`（无版本） | `state.ts` `DaemonState`（实为 `{pid, ipc, ipcSecret?}`） | ✅（有 ipcSecret） |
| 6 | tunnel/expose/proxy 命令 auto-start daemon + 5s 轮询等 socket | `cli.ts` tunnel/expose/proxy 分支 | ✅ |
| 7 | `ssh *` 子命令**不** auto-start，daemon 未跑时返回 null | `cli.ts` ssh 分支直接 `d.request` | ✅ |
| 8 | `proxy --foreground` 进程内运行 | `cli.ts` proxy start --foreground → `st.proxy.create` | ✅ |
| 9 | `daemon start --foreground`、`ui` 进程内运行 | `cli.ts` daemon/ui 分支 | ✅ |
| 10 | expose 的 90s 超时 | `cli.ts` `request("expose", …, 90_000)`；expose 内部 `waitForUrl(…, 30_000)` | ⚠️ 90s 是 CLI RPC 总超时，URL 等待是 30s |
| 11 | guardian 看护 daemon（`spawnGuardian(process.pid)`） | `daemon-server.ts:702`（由 daemon-server 自身调用，非 daemon.ts） | ✅ |
| 12 | 重启 rehydrate：`tunnels.hydrate` / `proxy.restore` | `daemon-server.ts:77` / `:672` | ✅ |
| 13 | RuntimeState = `{daemon, internal, tunnels, auth, bindings}` | `state.ts` | ✅ |
| 14 | `updateState` "single writer assumed" | `state.ts:85` | ✅ |
| 15 | 隧道 spawn `detached:true` + `kill(-pid)` groupKill + `child.kill` 回退 | `tunnels.ts` `start()`/`stop()` | ✅ |
| 16 | "tunnels/internal/bindings **已有镜像**" | tunnels（daemon-server persistTunnels）/ bindings（proxy onChange）✅；**internal 无任何 writeState 写它** | ❌ internal 镜像不存在 |
| 17 | claim-or-reuse"先查 state.json internal 表 + liveness" | internal 表永远空/陈旧（见 #16） | ❌ 需先建 internal 持久化 |
| 18 | "库模式（内嵌）目前不把 internal 写 state.json" | 正确，但**daemon 模式也不写**（daemon-server 3 处 writeState 均不含 internal） | ⚠️ 方案低估（以为 daemon 有镜像） |
| 19 | 空闲退出复用现有 `shutdown` RPC | `shutdown` handler 存在（stopAll + killRoleProcesses + exit） | ✅ 存在；但见 #21 |
| 20 | 清理靠角色标记 + guardian | `killRoleProcesses*` **Linux-only**（`cleanup.ts`）；guardian `collectDescendants` 读 `/proc`（Linux-only） | ❌ macOS/Windows 缺口被低估 |
| 21 | nginx/authelia/redis 可被进程组信号清理 | `gateway.ts`/`redis.ts`/`authelia.ts` spawn **无 `detached`** | ❌ `kill(-pid)` 对它们无效 |
| 22 | guardian 兜底"角色标记 + cleanupStaleDirs 周期清扫" | `cleanupStaleDirs` 只删 `nginx-<pid>/` 目录与 `registered-pids-<pid>.json` **文件，不杀进程**；且只在 guardian 进程内跑；`cli.ts` 全局 `guardian: false` | ❌ 表述有误；--no-daemon 必须 spawn guardian |
| 23 | Gradle 空闲 3h 自动退出 | docs.gradle.org："Daemon has been idle for 3 hours" | ✅ |
| 24 | Gradle 版本不匹配 → 停旧启新 | docs.gradle.org："starts a new Daemon if no idle or compatible Daemons exist"；同版本才复用；**不主动停旧** | ❌ 与 Gradle 不符（借鉴需标注） |
| 25 | `gradle --status` / `--stop` | docs.gradle.org ✅ | ✅ |
| 26 | Gradle 首次"Starting a Gradle Daemon"提示 | Gradle 首次启动提示（社区共识） | ✅ |
| 27 | （方案未提及）ssh 网关生命周期 | `ssh/manager.ts` 构造 `#load()` 自动 restore + `gateway.start()` 监听 | ⚠️ 空闲判定漏 ssh 网关 |
| 28 | （方案未提及）`daemon logs` 可用 | `daemon.ts:96` 计算 `logPath` 但 spawn 未用（`stdio: ignore`）；`cli.ts` `daemon logs` 输出该路径 | ❌ daemon 日志从未落盘 |
| 29 | （方案未提及）daemon 重启后 proxy transport 恢复 | `proxy-manager.ts` `restore()` 只填 bindings map，transport 由 expose/proxy.start 显式启动 | ⚠️ mode proxy 本地 vhost 需再次 start 才恢复 |

---

## 2. 关键发现详述

### 2.1 ❌ state.internal 表从不持久化——claim-or-reuse 的地基不存在

全库搜索 `writeState`/`updateState`：

- `daemon-server.ts`：3 处——persistTunnels（tunnels）、proxy.onChange（bindings）、
  启动写 daemon 块；
- `index.ts`：proxy.onChange（bindings）、tunnels persistState（tunnels）。

**没有任何一处写 `state.internal`**。daemon-server 启动时
`for (const entry of readState(stateFile).internal) internal.register(...)` 读到的永远
是空数组（rehydrate 是死代码）；`cli.ts` `discover` 分支"从 state.json 加载框架内部端口"
同样加载空表。

影响：
- 方案 §4.2 第 3 条 claim-or-reuse"先查 state.json internal 表"——表是空的，必然走
  "死了就自己 spawn"，永远无法"接管"已存在的单例；
- `sts status` 的 `internal` 字段永远空/陈旧；
- daemon 重启后 internal registry 丢失（nginx/authelia/redis 端口从 0 重新分配，配置
  与端口漂移）。

**修订**：M1 前置增加"internal 持久化"——`InternalRegistry` 的
register/unregister 同步写 state.json（或由持有者（daemon/前台会话）在
registerInternal 回调里 updateState）。这也是方案 §4.2 第 3 条"需统一'持有单例者发布
internal 表'的行为"的完整版本（方案只点了库模式，没点 daemon 模式）。

### 2.2 ❌ killRoleProcesses / guardian 子进程收集是 Linux-only

`cleanup.ts`：`killRoleProcesses` 与 `killRoleProcessesSync` 开头都是
`if (process.platform !== "linux") return 0;`。`guardian.ts` 的 `collectDescendants`
读 `/proc`（Linux-only）；macOS 上 guardian 只能依赖 `registered-pids-<pid>.json`
（需要 spawn 方注册）。

推论（现状即存在，方案需继承并写明）：
- **macOS/Windows 上 `daemon stop`（shutdown RPC）只停隧道**（`tunnels.stopAll` 是
  进程组 kill，跨平台），nginx/authelia/redis 变孤儿；
- 方案的空闲退出若复用 `shutdown` RPC，在 macOS/Windows 会同样留孤儿；
- 方案 §6.2 只提了 Windows 进程组 kill 需 `taskkill /T`，没提"角色清扫本身在非 Linux
  完全不存在"这一层。

**修订**：M1 的 `killSession()` 需覆盖两类对象：① detached 隧道（进程组信号，跨平台）；
② nginx/authelia/redis（**按 pid 列表 kill**——pid-registry 的
`registered-pids-<pid>.json` 是跨平台的，按 pid `process.kill` 即可，无需 /proc）。
空闲退出路径在非 Linux 上必须走"pid 列表清理"，不能只靠 `shutdown` RPC 的
killRoleProcesses。

### 2.3 ❌ nginx/authelia/redis 非 detached——进程组信号对它们无效

`gateway.ts:595/618`、`redis.ts:111`、`authelia.ts:314` 的 spawn 均无 `detached`：
它们与持有者（daemon 或前台会话进程）同进程组，`process.kill(-pid)` 会误杀持有者自身，
不能用于清理它们。方案 §4.2 把"进程组信号"当作通用停止手段，只对隧道成立。

**修订**：`killSession()` 语义改为——隧道：进程组信号；helpers：按 pid（注册表）逐个
`kill`。与 2.2 合并为"两类停止路径"。

### 2.4 ❌ Gradle 版本兼容是"起新不杀旧"，不是"停旧启新"

Gradle 官方文档（9.7.0）：
- "Gradle starts a new Daemon if no idle or **compatible** Daemons exist"；
- "a given Gradle version can only connect to Daemons of the same version"；
- 不兼容的旧 daemon **不主动被杀**，靠 3h 空闲退出自然清理。

方案 §2.3 表格与 §4.1 写"版本不匹配 → 停旧启新 / SIGTERM 停旧 + auto-start 新版"。

对 service-tunnels 而言"停旧"其实**更合理**（单 daemon per cacheDir + 有状态持有隧道，
旧 daemon 不会自然空闲退出——它持有的隧道就是活资产）。但既然以 Gradle 为参照，应明确
标注这是**借鉴而非照搬**，并保留 §6.9 的"回收前 ping 等当前操作完成"护栏。§2.3 表格
"差距"列的措辞改为"不兼容 → 起新；旧的自然退出（本方案：因有状态单 daemon 模型，
改为停旧启新，需 ping 护栏）"。

### 2.5 ⚠️ Gradle 的 --no-daemon ≠ 方案的 --no-daemon

Gradle：`--no-daemon` = 本次构建在 client JVM 完成、**命令正常返回**（只是没有后台
daemon 加速）。方案的 `--no-daemon` = start-like 命令变**前台会话、命令不返回**。

原因：`sts expose` 是常驻服务，无法"完成后返回"。**建议在 §4.1 语义块加一行注释**：
"`--no-daemon` 与 Gradle 的 `--no-daemon`（构建完成后命令照常返回）不同：本包 start-like
命令是常驻服务，`--no-daemon` 只能前台持有；查询/停止类命令在 `--no-daemon` 下才与
Gradle 语义一致（照常返回）。"——避免用户按 Gradle 直觉期待 `sts expose 5173 --no-daemon`
立即返回。

### 2.6 ⚠️ 空闲判定漏 ssh 网关

`ssh/manager.ts`：`#load()`（构造时调用）对每个 `running !== false` 的 domain 创建
`SshGateway` 并 `gateway.start(port)`——**ssh 网关是 daemon 进程内监听的常驻服务**，
daemon 重启自动恢复。daemon 空闲退出会直接断掉正在服务的 ssh 网关。

**修订**：§2.3 空闲条件补第 4 项：∧ **无 ssh 网关监听中**（`ssh.list()` 中任一
`listening`）；§6 风险 #8 同步更新。

### 2.7 ❌ 现状 bug：daemon 日志从未落盘（方案未指出，却是 M1 前提）

`daemon.ts:96` 计算 `logPath = opts.logFile ?? `${stateFile}.daemon.log``，但 detached
spawn 的 `stdio` 是 `["ignore","ignore","ignore"]`，logPath **从未被使用**。结果：
- `daemon logs` 输出的 `<stateFile>.daemon.log` 不存在或为空；
- daemon 端 `console.error`（RPC 失败、expose 的 `log:` 回调、"[daemon] failed"）全部
  进 /dev/null；
- 方案 §1.2 的语义债务"CLI 只能打印泛化错误（'rejected by daemon'）"根因正是日志不可见，
  而 CLI 提示"check daemon logs"指向空文件。

**修订**：M1 增加"daemon 日志落盘"：detached spawn 时把 stdout/stderr 重定向到
`logFile`（`fs.openSync` 或 `fd` 传入 spawn），并顺手加简单轮转（Gradle 按 daemon 每进程
一个日志 + 14 天清理，可借鉴）。前台/`--no-daemon` 模式天然解决（日志直接进终端），
但 daemon 模式（默认）必须修。

### 2.8 ⚠️ guardian 兜底表述有误：cleanupStaleDirs 不杀进程；--no-daemon 必须 spawn guardian

- `cleanupStaleDirs`（guardian 每 6h）只删 `nginx-<pid>/` 目录与
  `registered-pids-<pid>.json` **文件**，不 kill 任何进程；
- 杀进程的 `killRoleProcesses` 只在 guardian **检测到 parent 死亡**时执行；
- `cli.ts:486` 全局 `guardian: false`——今天 CLI 任何命令都不 spawn guardian。

方案 §6.4 说前台会话"SIGKILL 时靠角色标记 + cleanupStaleDirs 周期清扫兜底"——不成立：
没有 guardian 就没有任何进程清理，SIGKILL 后的 nginx/authelia/redis 是持久孤儿。

**修订**：`--no-daemon` 前台会话必须 `guardian: true`（spawn guardian 看护 CLI 进程），
或明确接受"SIGKILL 后 helpers 孤儿，需手动清理"。§4.3 加一行。

---

## 3. 内部一致性检查

| 问题 | 位置 | 说明 |
|---|---|---|
| "已有镜像"断言 | §4.2 | 见 2.1，internal 例外 |
| 前台/默认语义混用 | §2.2 不返回清单 | §2.2 列的是**提议的前台语义**，但当前所有命令都返回（daemon RPC）；未标注"现状 vs 提议"，易误读。建议加注"以下为 `--no-daemon` 模式语义；默认 Gradle 式 daemon 下这些命令照常返回" |
| 90s vs 30s | §6.6 | "现 daemon RPC 的 90s 超时"应写明：90s 是 CLI `request("expose",…,90_000)` 总超时；expose 内部 `waitForUrl` 是 30s |
| 728 vs 733 行 | §1.2 | 无实质影响 |
| 空闲条件 | §2.3 / §6#8 | 补 ssh 网关（2.6）；§6#8 与 §4.1 同步 |

---

## 4. 对方案文档的修订清单（diff 级）

1. **§2.3 表格**：版本行改为"不兼容 → 起新；旧的自然空闲退出（Gradle 语义）。本方案因
   有状态单 daemon 模型改为停旧启新——借鉴而非照搬，需 ping 护栏"。
2. **§2.3 关键差异**：空闲条件补"∧ 无 ssh 网关监听中"。
3. **§4.1**：语义块加 `--no-daemon` 与 Gradle 语义差异注；版本戳条目措辞同上。
4. **§4.2**：
   - 第 1 条把"已有镜像"改为"tunnels/bindings 已有；**internal 需新增持久化**
     （registerInternal/unregisterInternal 同步写 state.json，daemon 与前台会话都发布）"；
   - 第 2 条 `killSession()` 拆两类：隧道=进程组信号；nginx/authelia/redis=按 pid 注册表
     kill（`registered-pids-<pid>.json` 跨平台）；Windows taskkill /T 仅隧道兜底；
   - 第 3 条 claim-or-reuse 依赖的 internal 表以"M1 先建持久化"为前提。
5. **§4.3**：`--no-daemon` 前台会话加"spawn guardian（`guardian: true`）"或明示孤儿风险；
   日志流注明"顺带解决 daemon 日志不可见问题"。
6. **§5 M1**：增加——internal 持久化；daemon 日志落盘（logFile 重定向 + 简单轮转）；
   ssh 网关入空闲判定；非 Linux 上 helpers 按 pid 清理。
7. **§6 风险**：#2 补"killRoleProcesses/collectDescendants 全平台现状即 Linux-only，
   空闲退出路径在 macOS/Windows 需 pid 列表清理"；#8 补 ssh 网关；#4 改为"前台
   `--no-daemon` 必须 spawn guardian（cli.ts 现为 guardian:false）"。

---

## 5. 里程碑实施风险评估

| 里程碑 | 隐藏成本/依赖 | 风险 |
|---|---|---|
| M1 | internal 持久化是 claim-or-reuse 前置（不是"已有镜像"）；日志落盘涉及 spawn stdio 改动（需回归 daemon 日志文件权限 0600）；ssh 网关入空闲判定需 `ssh.list()` 的 listening 判定 | 中：internal 持久化触碰 daemon-server 写状态热路径（register/unregister 频次低，风险小） |
| M2 | `runSession()` 抽取需把 daemon-server 的 TunnelManager/AuthRegistry/ProxyManager 编排复用进 CLI 进程（index.ts 库模式已是同一套，成本低）；guardian 开关改动 | 低：库模式已验证进程内全部能力 |
| M3 | 现状 socket 已完整，抽出 ipc.ts 只是复用 | 低 |
| M4 | mcp-server-plan 结论基本维持（上一轮已修正），改动小 | 低 |

**总评**：M1 是真正的工程主体，且其中"internal 持久化 + 日志落盘"两项是方案未计入的
前置工作量；M2–M4 与方案一致，无新增风险。建议按修订后的 M1 顺序实施：
**internal 持久化 → daemon 日志落盘 → 版本戳 → 条件化空闲退出（含 ssh 网关）→
免 daemon 操作层（sessions + killSession + lockfile）**。

---

## 6. 结论

- 方案的核心判断（daemon 保留为默认、补齐 Gradle 实践、`--no-daemon` 逃生门、停止类
  命令不依赖 daemon 存活）**全部得到源码与官方文档支持**；
- 未发现推翻方案结构的证据；需修订的是 3 处事实性错误、2 处 Gradle 参照标注、1 处
  空闲判定遗漏、1 个现状日志 bug，以及若干表述（详见 §4）；
- 修订后即可按 M1 开工。
