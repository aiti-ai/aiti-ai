# TCP Tunnel SSH 认证网关 — 完整方案

> 目标：为 service-tunnels 的 **tcp 隧道**提供可选认证层。启用后，公网 tcp
> 入口不再是"谁都能连的裸端口"，而是接入一个**内部纯 JS SSH 服务器**（公钥
> 认证网关）：只有掌握授权私钥的用户，通过 `ssh` 端口转发才能把连接送到目标
> 服务。私钥是唯一凭据，未认证流量在 SSH 传输层即被拒绝。
>
> 范围：SSH 服务器内核（vendor 自 mscdex/ssh2，零 npm 依赖）+ domain（组）模型
> + 密钥生命周期管理 + Web 管理界面（domain / 公钥 / host key 指纹）+ 与现有
> tcp tunnel 的接线 + 用户使用流程。**不实现** shell / exec / sftp ——
> session 一律拒绝，仅端口转发。

---

## 1. 目标与背景

现有 tcp 隧道（`expose --protocol tcp`，经 ngrok / frpc / ssh 公网入口）是**纯
透传**：公网端口对互联网开放，任何人不经认证即可连到本地服务端口。tcp 场景
下 nginx 网关的 forward-auth 不可用（那是 HTTP 层协议）。

本方案为 tcp 隧道提供**传输层认证**：

| 现状 | 启用 SSH 认证后 |
|---|---|
| 公网 tcp 端口 → 直接透传到本地服务 | 公网 tcp 端口 → 内部 SSH 网关 → 公钥认证 → 固定目标端口 |
| 谁都能连，无凭据要求 | 私钥是唯一凭据，无 key 连不上 |
| 认证通过者可访问任意端口（透传目标即服务） | 认证通过者**也只能访问固定端口**（防跳板） |

## 2. 架构与数据流

```
                      ┌─────────────── service-tunnels 宿主机 ───────────────┐
  用户本地            │                                                      │
  ┌────────┐         │  公网入口 P              SSH 网关端口 B                │
  │TCP 工具│──┐      │  ┌──────────┐  tunnel   ┌──────────────────┐          │
  │(mysql/ │  │      │  │ ngrok/frpc│──透传────▶│ SSH Server       │          │
  │ psql/  │  ▼      │  │ ssh -R    │          │  (vendored ssh2) │          │
  │ RDP…)  │127.0.0.1│  └──────────┘  直连可选 ▶│                  │          │
  └────────┘ :LP     │  (P → 127.0.0.1:B)      │ ① publickey 认证 │          │
      ▲              │                         │ ② session 拒绝   │          │
      │  ssh -N -L   │                         │ ③ 固定端口转发    │──▶ 127.0.0.1
      │  (公钥认证)   │                         └──────────────────┘   :forwardPort
      └──────────────┘                                                      │
                                                        ┌───────────────────┘
                                                        ▼
                                                目标 TCP 服务（如 MySQL 5432）
```

**两条接入路径（同一 SSH 网关）：**

1. **经 tunnel**（SSH 端口藏在内网/防火墙后）：公网入口 P 由现有 tcp tunnel
   透传到 `127.0.0.1:B`。用户 `ssh -p P` 即可。
2. **直连**（SSH 端口本身对外可达）：用户 `ssh -p B` 直接连。

两条路径在 SSH 网关处汇合，认证与转发逻辑完全一致。

## 3. 安全模型

- **私钥 = 唯一凭据**。`publickey` 认证失败即断开，隧道端口对无凭据者等同黑洞；
  无 `none` / `password` / `keyboard-interactive` 分支。
- **固定端口转发（防跳板）**。认证通过后，客户端发起的任何出站连接
  （`direct-tcpip`，即 `-L`）**忽略请求中的目标端口**，一律连配置的
  `forwardHost:forwardPort`。持有私钥者无法扫描服务端内网（无法把网关当跳板）。
  反向 `tcpip-forward`（`-R`）同样忽略 `bindPort`，只在配置的固定端口监听。
- **Host key 持久化**：身份固定，用户核对指纹后可防 MITM；重启不换 key
  （known_hosts 不报警）。
- **最小面**：无 shell/exec/sftp（session 拒绝）、无 agent 转发、无 X11；
  转发的另一端默认仅 `127.0.0.1`（不开放任意出网目标）。
- **私钥最小暴露**：服务端生成的用户私钥**仅发放一次**，服务端不落盘只存公钥。

## 4. SSH 服务器内核（vendor ssh2，零 npm 依赖）

| 模块（来自 mscdex/ssh2@1.17.0，MIT） | 行数 | 用途 |
|---|---|---|
| `protocol/Protocol.js` | 2136 | 传输层：报文帧 / 算法协商 / NEWKEYS / 重协商 |
| `protocol/crypto.js` | 1602 | node `crypto` 封装：cipher / MAC 算法 |
| `protocol/kex.js` | 1908 | 密钥交换：curve25519-sha256 / ecdh / dh + host key 签名 |
| `protocol/handlers.misc.js` | 1285 | userauth + connection 消息分发 |
| `protocol/keyParser.js` | 1484 | OpenSSH / PEM / PKCS8 密钥解析（含 authorized_keys） |
| `protocol/constants.js` + `utils.js` + `zlib.js` | ~970 | 常量 / 二进制读写 / 可选压缩 |
| `server.js` | 1380 | Server：认证上下文 / session / tcpip / request 事件 |
| `Channel.js` | 295 | channel 流封装（双向 pipe） |
| `keygen.js` | ~590 | 密钥对生成（openssh-key-v1 输出，等同 ssh-keygen） |

**裁剪与改写**：

- 不需要：`SFTP.js`（4052 行）、`client.js`、`agent.js`、`http-agents.js`。
- 依赖全部消化：`asn1` 仅 2 处用法 → 手写 X25519 SPKI 编码（固定 44 字节 DER，
  ~15 行）+ keygen 的 ed25519 DER 解析（固定格式，~20 行）；`bcrypt-pbkdf`（私钥
  加密）与 `cpu-features`/`nan`（可选原生）直接删。**仅用 ed25519/rsa host key +
  curve25519 kex 时全链只用 node 内置 `crypto`**。
- 算法面：host key `ed25519` + `rsa`（2048）+ `ecdsa`(P-256) 三把（对齐 sshd
  默认，兼容老客户端）；kex `curve25519-sha256`；cipher `aes*-gcm` +
  `chacha20-poly1305`；mac `hmac-sha2-*`。
- 行为改写点（`server.js` 层，非协议层）：
  - `authentication` 事件：仅 `publickey` 分支，验签 + authorized_keys 比对；
  - `session` 事件：直接 `reject()`（shell/exec/sftp 全拒）；
  - `tcpip` 事件（`-L` 出站）：忽略 `info.destPort`，固定连 `forwardHost:forwardPort`；
  - `request` 事件：`tcpip-forward` 忽略 `info.bindPort`（但 `forwardOut()` 必须
    回传客户端登记的 bindAddr/bindPort，OpenSSH 客户端会校验），实际在独立
    `reversePort` 上监听（**与 forwardPort 分离**，避免 -L 目标被监听器截获），
    连接到达时推给客户端（`-R` 反向转发）。`reversePort` 未配置时 -R 请求被拒。

## 5. Domain（组）模型与存储

类比 basic provider（htpasswd 文件即用户库）与 `UserManager` 接口：**一个
domain = 一个独立 SSH 网关实例**（一组授权公钥 + 一把 host key 集 + 一个固定
转发目标）。

```
cacheDir/tmp/ssh/<domain>/          # 目录 0700
├── authorized_keys                 # 授权公钥（authorized_keys 格式，0600）
├── host_ed25519_key                # host key（自动生成，缺则补，0600）
├── host_rsa_key                    # 2048 位（缺则补）
├── host_ecdsa_key                  # P-256（缺则补）
└── meta.json                       # domain 元数据（固定转发端口等）
```

规则：

- domain 名复用 `validateUserName` 规则（`[a-zA-Z0-9][a-zA-Z0-9._-]*` ≤ 64，
  安全作为目录名 / YAML key）。
- host key 三把**自动生成并持久化**（启动或首次访问时补缺），永不丢失身份。
- 一个 daemon 可起多个 domain，各自独立端口 / 转发目标 / 公钥库。

## 6. 密钥生命周期

### 6.1 Host key（服务端身份）

首次启动自动生成三把（ed25519 + rsa + ecdsa），0600 持久化。提供**指纹查询**
（SHA-256），供用户核对 `ssh-keygen -lf` 一致后加入 known_hosts（防 MITM）。

### 6.2 用户公钥（两种供给方式，同一 authorized_keys 库）

**方式 A — 用户上传已有公钥**（自带 key）：

```
POST sshKey.add { domain, publicKey: "ssh-ed25519 AAAA… user@host" }
```
`keyParser.parseKey()` 校验格式（ed25519 / rsa / ecdsa 均可），重复指纹拒绝，
成功写入 `authorized_keys`。

**方式 B — 服务端代生成密钥对**（1 到多个）：

```
POST sshKey.generate { domain, type: "ed25519"|"rsa", bits?, comment? }
→ { privateKey: "-----BEGIN OPENSSH PRIVATE KEY-----…",   // 仅此一次返回
    publicKey:  "ssh-ed25519 AAAA…",
    fingerprint: "SHA256:…" }
```
- 私钥 OpenSSH 格式（openssh-key-v1），可直接 `ssh -i` 使用；**服务端只存
  公钥**，私钥不落盘、不重放（用户丢失需重新生成）。
- 支持批量生成（`count: 1..N`），便于一用户多设备 / 多用户分发。

**撤销**：`sshKey.remove { domain, fingerprint }` 从 authorized_keys 删除即
立即生效（认证时实时查库）。

## 7. 与现有 tcp tunnel 的接线

复用现有 tunnel 基础设施，只改"目标"：

- `expose --protocol tcp` 的 tcp tunnel 目标端口**由服务端口改为 SSH 网关端口
  B**（`127.0.0.1:B`）。即公网入口 P → 透传 → B。
- 可选参数 `--ssh-gateway <domain>`：指定后 tunnel 目标自动指向该 domain 的
  SSH 端口；未启用 SSH 网关的 tcp tunnel 保持现状（裸透传）。
- 公网入口 P 对未认证者可见但不可用（SSH 握手需 host key + 公钥认证，认证失败
  即断）。可选仅监听 `127.0.0.1:B`（SSH 端口不直连公网，全部走 tunnel）。
- 与现有 `tunnels.ts` 的 `ssh -R` 反向隧道不冲突：那是"本地端口 → 公网 ssh
  服务器"的出口；本方案是"用户 → 我们网关"的入口，角色互补。

## 8. 用户使用流程

### 8.1 OpenSSH 客户端（Linux / macOS / WSL / Win10+）

```bash
# 一次性：核对 host key 指纹（与管理员提供的一致）
ssh-keyscan -p <P|B> <host> | grep ed25519

# 常驻转发：本地 127.0.0.1:3306 → 网关 → 固定目标端口（如 5432）
ssh -N -i ~/.ssh/id_ed25519 \
    -L 127.0.0.1:3306:127.0.0.1:5432 \
    -p <P|B> sshuser@<host>
```

之后任意 TCP 工具（`mysql -h 127.0.0.1 -P 3306`、psql、Redis CLI、RDP、数据库
GUI…）连 `127.0.0.1:3306` 即可——工具不感知 SSH，转发在系统层完成。需要多条
`-L` 也可（多条连接同一固定目标，或 ssh 配置 `LocalForward`）。

### 8.2 PuTTY（Windows，无 OpenSSH 时）

1. 私钥：PuTTYgen → Conversions → Import key → 选我们下发的 OpenSSH 私钥 →
   Save private key 存为 PPK（0.68+ 全版本支持；0.76+ 另有 kex-strict 兼容）。
2. Session：Host = 公网入口，Port = P（或 B）→ Connection > SSH > Auth >
   Credentials 选 PPK。
3. Connection > SSH > Tunnels：Source `3306`，Destination
   `127.0.0.1:5432`，Local，Add；Open 后本地工具连 `127.0.0.1:3306`。

## 9. 管理 API（daemon IPC，与现有 JSON-line 协议一致）

```
sshDomain.create  { domain, sshPort, forwardPort, reversePort?, forwardHost?, listenAddr? }
sshDomain.remove  { domain }
sshDomain.list    → [{ domain, sshPort, forwardPort, forwardHost, hostKeyFingerprints }]
sshKey.add        { domain, publicKey, comment? }        → { fingerprint }
sshKey.generate   { domain, type?, bits?, comment?, count? } → [{ privateKey, publicKey, fingerprint }]
sshKey.list       { domain }                             → [{ fingerprint, type, comment, addedAt }]
sshKey.remove     { domain, fingerprint }
```

## 10. Web 管理界面（UI）

接入现有 `src/ui.ts`（node 内置 http + 内存模板 + CSRF + 中英 i18n，默认
127.0.0.1:4181），沿用其页面/路由/模板模式，不引入新依赖。

### 10.1 导航与页面

新增导航项 `SSH`（`/ssh`），三个页面：

| 页面 | 路由 | 内容 |
|---|---|---|
| SSH 网关列表 | `GET /ssh` | domain 卡片：监听端口 / 固定转发目标 / 连接数 / host key 指纹；创建、删除入口 |
| Domain 详情 | `GET /ssh/<domain>` | host key 三把指纹 + 公钥列表（指纹 / 类型 / 注释 / 添加时间 / 撤销按钮）+ 两个新增入口 |
| 密钥生成结果 | 模态框（前端） | 生成成功后**一次性**展示私钥全文 + 复制/下载按钮 + 红色警示 |

### 10.2 操作路由（POST，均带 CSRF）

```
POST /ssh/add                        # 创建 domain（端口/固定转发端口/转发目标）
POST /ssh/<domain>/remove            # 删除 domain（二次确认弹窗）
POST /ssh/<domain>/keys/add          # 上传公钥（textarea，parseKey 校验后入库）
POST /ssh/<domain>/keys/generate     # 生成密钥对（类型/数量/注释）→ 模态框展示私钥
POST /ssh/<domain>/keys/<fp>/remove  # 撤销公钥（指纹标识）
```

### 10.3 交互与安全细节

- **私钥展示**：模态框内只显示一次；提供「复制」「下载 .key 文件」；关闭后不可
  重看（重新生成才有新私钥）；页面标注「私钥不会保存在服务器，请立即保存」。
- **host key 指纹**：domain 详情页提供三把 host key 的 SHA-256 指纹 + 一键复制，
  供管理员外带核对（防 MITM）。
- **批量生成**：`count` 上限 10；批量结果逐条展示，每条独立复制/下载。
- **i18n**：新增 `ui.nav.ssh` / `ui.ssh.*` 等 CATALOG key，中英双语与现有页面一致。
- **与库/daemon 关系**：UI 直接调用 `ServiceTunnels` 库方法（与现有 auth/sites
  页面同模式，如 `ctx.st.ssh.*`；隧道相关才走 daemon IPC）。SSH 网关是库级能力，
  UI 层不碰文件系统。

## 11. 配置项

```yaml
# 配置文件（config.yml 风格，对齐现有暴露配置）
ssh-gateway:
  domains:
    - domain: mygroup
      ssh-port: 22022        # SSH 网关监听端口；listenAddr 默认 127.0.0.1
      forward-port: 5432     # 固定转发目标端口（认证通过者 -L 唯一可访问的端口）
      reverse-port: 22023    # 可选：-R 反向转发监听端口（与 forward-port 必须不同）
      forward-host: 127.0.0.1
      # host-keys-dir 缺省 cacheDir/tmp/ssh/<domain>（自动生成三把 host key）
```

CLI：`service-tunnels ssh-gateway --domain mygroup --ssh-port 22022 --forward-port 5432`
库 API：`createSshGateway({ domain, sshPort, forwardPort, forwardHost })`。

## 12. 安全细节清单

- 文件权限：host key / authorized_keys 0600，目录 0700（对齐 basic 的 htpasswd 处理）。
- 认证失败限速：同一来源连续认证失败（默认 10 次）临时退避（默认 60s），
  退避期间连接在握手前即被拒（`authFailLockout` 可调）；未认证连接超时
  （默认 10s）：**前置 net 监听器**对每个 raw socket 设空闲超时，静默
  （不发 SSH version）的连接直接销毁——ssh2 本身在客户端 banner 前无法超时。
- 并发上限：每 domain 最大连接数（默认 128），超过拒绝新连接。
- `forwardHost` 仅允许回环/内网地址（127.0.0.1/::1/10./192.168./172.16-31/169.254./fd00:/fe80:），
  公网目标在 `ssh.domain.create` 即被拒（防网关成为出口代理）。
- 私钥一次性发放；`sshKey.list` 只回指纹/注释，不回任何密钥材料。
- 可选：domain 可停用（`sshDomain.remove` 关监听 + 删公钥库前二次确认）。
- Host key 指纹可通过 `sshDomain.list` 查询，供部署方外带核对。

## 13. 实现计划

| 阶段 | 内容 | 验收 | 状态 |
|---|---|---|---|
| M1 vendor | `src/vendor/ssh2/`：protocol（去 SFTP）+ server.js + Channel.js + keygen.js；手写 X25519 SPKI；`npm ls` 无新增依赖 | `npm test` 全绿；`npm run build` 通过 | ✅ 完成（154 测试 0 失败；dist 运行时验证通过） |
| M2 网关内核 | publickey-only 认证、session 拒绝、`tcpip` 固定端口、`tcpip-forward` 固定端口（`reversePort`）、多 host key 自动生成持久化 | 系统 `ssh -L` 直连冒烟通过 | ✅ 完成（-L 双向 echo / 错误 key 拒绝 / 目标端口固定 / **-R 反向转发**，4/4 测试过） |
| M3 domain 存储 | authorized_keys 管理、meta.json、host key 补缺、指纹查询 | 单元测试覆盖增删查 + 持久化 | ✅ 完成（5/5：host key 三把自动生成+幂等+系统指纹一致；增删查/重复/垃圾拒绝/持久化；generateKey 私钥一次性；meta） |
| M4 管理 API | daemon IPC 六方法 + CLI 命令 | 与 daemon 现有协议风格一致 | ✅ 完成（`ssh.domain.list/create/remove` + `ssh.key.add/generate/list/remove` + `ssh.host.fingerprints` 八个 IPC 方法；CLI `ssh` 子命令全家；daemon 重启恢复；e2e：IPC 建域→生成密钥→系统 `ssh -L` 透传→移除） |
| M5 UI | `/ssh` 三个页面 + 五个 POST 路由 + i18n（对齐 ui.ts 模式） | 手工冒烟：创建 domain → 生成密钥 → 私钥展示/下载 → 撤销 | ✅ 完成（导航 `/ssh`；网关列表 + domain 详情（host key 指纹/公钥表）+ 密钥生成模态框（私钥一次性+复制/下载）；POST：add/remove/keys add/generate/remove，CSRF 覆盖，daemon IPC null→400；中英 i18n） |
| M6 集成 | `expose --protocol tcp --ssh-gateway <domain>` 接线；文档 | 公网入口 → 网关 → 目标全链路 e2e | ✅ 完成（`--ssh-gateway` 时 tcp tunnel target 指向网关 SSH 端口；daemon 提供 resolver；CLI 透传；e2e：command tunnel 模拟公网入口 → SSH banner → 授权 key `ssh -L` → echo 全链路） |
| M7 加固 | 限速 / 超时 / 并发 / 权限 / 指纹文档 | 安全清单逐项验证 | ✅ 完成（认证失败限速 per-source 退避；前置 socket 空闲超时切断静默 raw 连接；`forwardHost` 仅回环/内网；文件权限 0600/0700 验证） |

## 14. 测试计划

- **单元**：keygen 输出可被系统 `ssh-keygen -y` / `-l` 解析；parseKey 校验
  各种公钥格式；authorized_keys 增删查与持久化；fingerprint 计算。
- **协议层**：vendored protocol 直接喂固定报文向量（来自 ssh2 上游测试）。
- **集成（真实客户端）**：spawn 系统 `ssh` 做 e2e：
  - `ssh -L` 直连网关 → 目标 echo 服务 → 本地 curl 验证透传；
  - `ssh -R` 反向：网关固定端口 → 客户端本地端口；
  - 错误私钥 / 无 key / 伪造 key 必须被拒；session 请求（`ssh host` 不带 -N）
    必须被拒；请求非固定端口（`-L x:127.0.0.1:9999`）仍转到固定端口；
  - ed25519 与 rsa host key 两种客户端协商路径。
- **兼容**：OpenSSH 客户端（系统 ssh）、PuTTY（手动记录）、`ssh -V` 多版本。
- **UI 冒烟**（M5 交付）：node http 直接请求各页面/路由：GET 三页面 200 +
  CSRF 校验生效；POST 无 token 被拒；生成密钥后私钥只出现一次；`/ssh/<d>/remove`
  二次确认参数校验。
- **回归**：`npm test`（现有测试不回归）；CI 上跑 M1–M6 的 e2e 脚本。

## 15. 性能分析（实测）

> 实测环境：AMD Ryzen 9 7940HS（16 核），Node.js v24.11.1（OpenSSL 3.4.1），
> 全部 loopback（127.0.0.1）。验证脚本：ssh2@1.17.0 server + client 转发链路
> （与本方案 vendor 同源代码）；系统 OpenSSH 客户端（C 实现）作对照。

### 16.1 结论速览

| 路径 | 实测吞吐（256 MiB 单向） |
|---|---|
| 全 JS：ssh2 client ↔ ssh2 server 转发 | **462 MiB/s**（默认 chacha20-poly1305）/ 408 MiB/s（aes128-gcm） |
| 混合：OpenSSH 客户端 → ssh2 server 转发 | **402 MiB/s** |
| 反向上传（全 JS） | **394 MiB/s** |

即：单核可支撑 **≈3.7 Gbit/s** 的隧道流量。对端口转发/隧道场景（通常单隧道
MB/s～几十 MB/s）**余量巨大，性能不是瓶颈**。

### 16.2 分层实测数据

**对称加密（node crypto，单核，128 MiB）**：加密全部走 OpenSSL（C），不是瓶颈：

| 算法 | 吞吐 | 备注 |
|---|---|---|
| aes-128-gcm | ~335 MiB/s | 有 AES-NI 加速（实测波动 287–532） |
| aes-256-gcm | ~335 MiB/s | |
| chacha20-poly1305 | ~275–395 MiB/s | 无硬件加速，纯软 |
| hmac-sha2-256 | ~780 MiB/s | 旧式加密+MAC 方案的 MAC 部分 |

**握手（每连接一次，微秒级开销）**：ed25519 签名 80µs / 验签 363µs；
X25519 密钥对 70µs + DH 123µs。一次完整握手（含 KEX + NEWKEYS）loopback
开销 <5ms，连接频繁建立/断开也无压力。

### 16.3 瓶颈定位与优化方向

- **瓶颈在 JS 报文处理层，不是加密**：SSH 报文按 32 KiB 分块，每块都经历
  JS 层帧解析/组装、流拷贝、事件循环调度；实测吞吐低于 OpenSSL 单核加密
  峰值，说明是 JS 单线程吞吐 + 内存拷贝受限，而非密码学。
- **C 实现（OpenSSH）对比**：OpenSSH loopback 转发典型值约 1–3 GB/s（C +
  AES-NI + 零拷贝），本方案约为其 1/4–1/3。对隧道场景（互联网链路才是
  瓶颈）无实际影响；仅当同机多隧道聚合到数 Gbit/s 级别才需要关注。
- **可选的免费优化**：
  1. cipher 优先 `aes*-gcm`（AEAD，免二次 HMAC；chacha20 软实现更慢）；
  2. 调大 SSH channel window（ssh2 默认 32 KiB 窗口，TCP 场景可放大减少
     WINDOW_ADJUST 往返）；
  3. 关闭压缩（默认 off，转发场景压缩无收益还吃 CPU）；
  4. Node 20→24 有吞吐提升，保持引擎 ≥ 22.19（项目已要求）。
- **多连接扩展**：Node 单进程单事件循环；若未来出现多隧道聚合吞吐需求，
  按 domain 分进程（现有 daemon/guardian 多进程架构可复用）即线性扩展。

### 16.4 对本方案的影响

- 端口转发是**流式、单方向大块传输**，是 ssh2 最擅长的路径（无 PTY/无
  交互开销）；实测数据即真实落点，无隐藏降级。
- host key 用 ed25519（签名 80µs，比 rsa-2048 的 509µs 快 6 倍）降低握手
  成本，高连接率下收益明显——与 §4 算法面选型一致。
- 内存：每并发连接约 1–2 MB（协议缓冲 + 流），128 并发 ≈ 200 MB 内，
  符合默认并发上限（§12）。

## 16. 发布与合规影响

- **内部 npm（镜像 alot.pw）**：vendor 代码随包发布，零外部依赖；`files` 增加
  `src/vendor/ssh2`。
- **公共 npm（registry.npmjs.org）**：vendor 代码保留 ssh2 的 MIT LICENSE 头 +
  `docs/` 注明来源与版本（ssh2@1.17.0 相应文件），符合 MIT 署名要求；无原生
  模块、无新运行时依赖，"依赖仅 justget" 的约定保持成立（vendor 非 npm 依赖）。
- 安全公告跟踪：vendor 后需跟随 ssh2 上游安全修复（如 kex 相关 CVE），在
  `docs/` 记录 vendored 版本与升级路径。
