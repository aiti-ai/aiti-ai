# service-tunnels 性能分析 + Rust/Go 移植方案（2026-08-07）

> 内部评审文档。结论基于本机（Linux x86-64, Node v24）实测，基准代码见附录，
> 可在 CI/目标机复现。所有"每请求"数字均为 keep-alive 小包（≈2B body）loopback
> 测量，真实负载（大 body / 慢上游 / 公网隧道）下这些差距会被网络延迟稀释。

---

## 0. 结论摘要

1. **控制面（CLI/daemon/discovery/隧道编排/nginx 网关生成）不是热点，无性能
   问题**，为性能移植 Rust/Go 不值得。
2. **数据面（内置 proxy，`--mode proxy/both` 的 4180 端口 + 决策 API）有真实的
   性能问题**，但瓶颈**不是 Node 本身，而是三个算法/架构决策**：
   - **basic 认证每次请求重算 APR1（1000 轮 MD5）= 2.94ms/请求** → 单核上限
     **~340 req/s**。这是全部热点里最严重的，且与语言无关（Node 的 crypto 已是
     原生 OpenSSL）。
   - **forward-auth 每次请求一次 loopback authz 探针（232µs）+ 3s 超时**，Node
     单事件循环串行化 → 单核上限 **~4.3k req/s**，且 provider 卡死时会
     head-of-line 拖慢整条 proxy。
   - **token/basic 校验用 `readFileSync` 同步读文件 + 每请求解析**（43µs/请求）。
3. **纯透传吞吐实测（2026-08-07 交叉复测修正）**：早期"Node 6.3k / Go 29k /
   Rust 80k"是同语言客户端+服务端合值，**高估了差距**——Node 客户端（~6-11k
   上限）把 Node 服务端压到了 6.3k。换成同一多线程 Go 客户端后：**Node proxy
   ~30-34k rps、Go proxy ~93-138k、Rust hyper 调优版 ~118-157k** → 真实
   服务端差距 ≈ **3-5×**（Node ≈ Go 的 25-33%、Rust 的 20-27%），不是早前
   估计的 1/12。详见 §3.4 与 `test/perf/cross-client/`。
   但该差距只在**单核、纯代理、高并发**场景显著；真实隧道场景（外部二进制
   ngrok/frp/cloudflared 已是 Go/Rust）与 nginx 网关路径**完全不受影响**。
4. **推荐路线**：先在 JS 内做算法/工程层优化（portal 本地验签、探针工程化、
   凭据缓存），预计解决 90%+ 问题；**只当数据面需要万级 rps/核时才移植
   proxy 数据面为 Rust sidecar**（复用项目已有的"生成小服务器脚本再
   spawn"模式）。**不建议整体移植 CLI**——控制面无性能收益，重写 ~12k 行
   编排代码（discovery/providers/nginx 生成/authelia/oauth2/UI/i18n）风险高、
   收益低。
5. **重要修正（评审后）**："决策缓存（探针结果 TTL 缓存）"**不是标准做法**，
   且有撤销/登出延迟语义，本版已弃用；正确姿势见 §3.1/§3.2——portal 走本地
   验签（JWT 模式，零探针）、authelia/oauth2-proxy 保持每请求探针（nginx
   auth_request 同款标准语义）、只缓存**凭据查找**（token/htpasswd 文件，
   mtime 失效）而非**认证决策**。

---

## 1. 架构与请求路径分解

```
公网客户端
   │
   ├─ [模式A 隧道] ngrok/frp/cloudflared/bore/ssh/...（外部 Go/Rust 二进制）
   │        │  ← 纯透传通道，与认证/路由无关（架构原则）
   │        ▼
   │   127.0.0.1:<gateway> nginx（auth_basic/auth_request，native，快）
   │        ▼
   │   本地应用
   │
   └─ [模式B proxy]  客户端 → 内置 Node proxy(:4180)
            │
            ▼
   createProxyServer.handle()  ← 数据面热点（每请求）
            │
            ▼
   resolveServiceHost() 决策 API（与嵌入方 middleware 共用）
     ├─ parseServiceHost()          host 正则解析       0.11µs
     ├─ isAllowed()                 D4: () => true      ~0
     ├─ resolveSite()               绑定 Map 查询         ~1µs
     ├─ gateBackend()               认证门禁             ★热点★
     │    ├─ basic:  verifyHtpasswd() → md5Crypt 1000轮  2941µs ★★★
     │    ├─ token:  verifyBearerToken() 读文件+sha256     43µs ★
     │    └─ forwardAuth: checkForwardAuthReq() loopback   232µs ★★
     │                      探针（3s 超时，无缓存）
     └─ forward/pipe               http.request + pipe    158µs/请求（含上游）
```

各模式结论：

| 部署路径 | Node 参与数据面？ | 性能风险 |
|---|---|---|
| tunnel（ngrok 等）+ nginx 网关认证 | 否（仅编排） | 无 |
| tunnel + 内置 proxy 认证（嵌入式宿主） | 是（决策 API） | basic/forward-auth 热点 |
| proxy / both（内置 4180 端口） | 是（完整数据面） | 见 §3 |
| 控制面（daemon IPC/CLI/discovery） | 是（低频） | 无 |

---

## 2. 测量方法（本机实测，可复现）

### 2.1 微基准（单请求成本）

| 基准 | 内容 | 结果 |
|---|---|---|
| `auth-bench.mjs` | APR1 校验（verifyHtpasswd 复刻） | **2941µs/次**（340 次/s） |
| `auth-bench.mjs` | token 校验（sync read+JSON.parse+sha256） | 43µs/次（23k 次/s） |
| `auth-bench.mjs` | host 正则解析 | 0.11µs/次（可忽略） |
| `fwprobe-bench.mjs` | forward-auth loopback 探针（含 keep-alive） | 232µs/次（4.3k 次/s，串行） |

### 2.2 吞吐基准（⚠ 客户端/服务端必须区分）

早期同语言客户端+服务端的测量**会把两者瓶颈混在一起**（Node 客户端只有
~6-11k 上限，把 Node 服务端压到 6.3k），不能用于跨语言对比。修正口径：

| 组合 | rps（errors=0） | 说明 |
|---|---|---|
| Node client → Node proxy（旧值） | 6.3k | 客户端+服务端合值，**仅反映 Node 客户端上限** |
| Node client → Go proxy | 11k | Node 客户端打快服务端的天花板 |
| **Go client → Node proxy** | **30-34k**（conc 100→1000 持平） | 服务端真实吞吐；事件循环饱和 |
| Go client → Node undici-fetch proxy | 29-34k | undici 上游无改善（瓶颈在 http.Server） |
| Go client → Node bare server | 25-30k | 裸 server 也同量级 |
| **Go client → Go proxy** | **93-138k**（conc 100→1000） | 服务端真实吞吐（httputil.ReverseProxy），随并发增长 |
| Go client → Go bare server | 81-90k → 134k（conc 1000） | Go 客户端天花板随并发上移 |
| Go client → Rust hyper proxy（**朴素**） | 55-63k | **每请求 Regex::new 编译 + Uri 重建**，非 Rust 上限 |
| Go client → Rust hyper proxy（**调优**） | **118-157k**（conc 100→1000） | 正则编译一次 + Uri 预构建 + 池化显式；天花板 ~157k |

复现脚本：`test/perf/cross-client/`（同一 goclient 打所有服务端，只数成功
响应）。三种语言的旧自bench（`test/perf/*-proxy-bench*`）保留作回归，但
**跨语言对比一律用 cross-client 口径**。

> 注：以上为无认证开放 vhost 上限。带认证时实际上限由 §1 门禁热点决定，
> 远低于此（basic ~340 req/s、forward-auth ~4.3k req/s）。

---

## 3. 逐热点分析（Node 版）

### 3.1 ★★★ basic 认证：每次请求重算 APR1（2.94ms）

`verifyHtpasswd()`（providers/basic.ts）在**决策 API 进程内**每请求执行
`md5Crypt()`——1000 轮 MD5 + timingSafeEqual：

- 单核上限 ~340 req/s；10 并发 × 100 req 的预热后 rps 即被钉死。
- 成本与语言无关：Node 的 `crypto.createHash("md5")` 已是 OpenSSL 原生；Rust
  （ring/md5）移植后也只是 2.9 → ~1.5-2.5ms 的量级改善。
- **先判断：这是不是"做错了"？——不是。** nginx `auth_basic` / Apache htpasswd
  同样是**每请求**做 1000 轮 MD5（同算法同量级），逐请求校验是 basic 的行业
  标准语义，**不该缓存校验结果**（密码修改/撤销须即时生效）。
- **真正的结论是定位**：basic 天生不适合高 QPS 热路径，业界它就是 dev/CI/
  管理端认证。生产流量应使用会话类认证（portal/oauth2-proxy）。因此修复
  **不是缓存 APR1**，而是：
  1. 高流量场景换 portal/oauth2-proxy（会话类）承载；basic 只留给低流量
     入口；
  2. 注意：**不要**用 bcrypt/argon 替换 APR1——nginx auth_basic 只认
     APR1/crypt，换算法破坏 nginx 网关兼容（除非网关侧同步改）。

### 3.2 ★★ forward-auth：每请求一次探针 + 事件循环串行化（232µs + HOL）

`checkForwardAuthReq()` 对 portal/authelia/oauth2-proxy 每请求发一次
`127.0.0.1:<authPort>` 的 authz 探针：

- 单核串行上限 ~4.3k req/s（探针是同步等待）。
- **3s 超时**：provider 挂起时，每个在途请求占一个 socket 等 3s；Node 单事件
  循环下高并发会快速耗尽 fd，且探针的 `await` 会与其他请求共享调度——这是
  **tail latency 与可用性的最大风险**，比吞吐更危险。
- **先判断：这是不是"做错了"？** 每请求探针本身是标准（nginx
  `auth_request`/Caddy `forward_auth`/Traefik `forwardAuth` 都是每请求探），
  但我们把它搬进 Node 单事件循环 + 3s 超时 + 无连接复用，这才是与标准的
  差距。**"探针结果 TTL 缓存"不是标准做法**（撤销/登出最长延迟一个 TTL，
  登录态失效不即时），已弃用。
- 修复（按标准性排序）：
  1. **portal 本地验签（零探针，推荐）**：`verifySession()` 是纯本地 HMAC
     验签（签名+过期+2FA flag，不查用户库），cookie 是自包含签名会话（JWT
     模式）——决策 API 共享 HMAC 密钥即可内联验签，探针 232µs → 0，无缓存、
     撤销语义与现在逐请求探针完全等价（本来也只认过期时间）。
  2. **探针工程化**（authelia/oauth2-proxy 必须每请求探，这是它们的设计）：
     复用 keep-alive Agent；超时降为 1s（内部 loopback 200ms 内应答属正常）+
     provider 熔断（连续超时快速失败，nginx `fail_timeout` 等价物）。
  3. 可选：1-5s 微缓存仅作**突发吸收**，须文档化撤销延迟（业界有但非默认）。
- 若移植 Rust/Go：异步叠加后单机吞吐不再被"串行等待"限制（瓶颈只在 CPU），
  但**探针往返本身（232µs）在两种语言里都省不掉**——Rust 的价值是"并发探针"
  而非"更快探针"；portal 本地验签的收益两语言一致。

### 3.3 ★ token/basic 校验的同步文件 I/O（43µs/请求）

`verifyBearerToken()` 每请求 `readFileSync(tokens.json)` + `JSON.parse`：
- 43µs/次 → 单核 ~23k req/s，一般可接受，但**同步读文件会阻塞事件循环**
  （大 tokens 文件 / 慢盘时更糟）。
- 修复：**凭据查找缓存**（标准且安全——缓存的是查找不是决策，token 是凭据，
  文件 mtime 失效即时生效，无撤销延迟语义）：内存 Map + mtime 失效；token
  hash 比较改为内存 Map（O(1) 而非 O(n)）。

### 3.4 纯透传吞吐：交叉复测修正（Node 30-34k vs Go 93-138k vs Rust 调优 118-157k）

**为什么早期数字（6.3k/29k/80k）不准**：它们都是同语言客户端+服务端合值。
Node 客户端是单事件循环，本身只有 ~6-11k 上限（打 Go 服务端也只有 11k），
把 Node 服务端压到了 6.3k——**这不是服务端性能，是客户端性能**。

用同一多线程 Go 客户端交叉测量后（errors=0）：

| 服务端 | conc=100 | conc=1000 | 结论 |
|---|---|---|---|
| Node proxy（仓库同款路径） | 30-34k | 30.5k | **事件循环饱和**：并发再高也持平 |
| Node bare server | 25-30k | — | 裸 server 同量级 → 瓶颈在 http.Server，不在代理逻辑 |
| Node undici-fetch proxy | 29-34k | — | undici 上游无改善（瓶颈不在上游客户端） |
| Go proxy（httputil.ReverseProxy） | 93k | 138k | 随并发增长；天花板 ~138k |
| Rust hyper proxy（朴素实现） | 55-63k | — | **每请求 Regex::new 编译 + Uri 重建**，非 Rust 上限 |
| Rust hyper proxy（调优版 server bin） | 118k | 157k | 正则编译一次 + Uri 预构建 + 池化显式；天花板 ~157k |

真实结论：

1. **服务端差距：Node ≈ Go 的 25-33% ≈ Rust 的 20-27%**（按各自天花板），
   不是早前估计的 1/12。差距根源是 Node 单事件循环：并发 100→1000 吞吐
   持平（每请求仍要事件循环串行处理请求头/响应/上游往返），Go goroutine
   多线程并行、Rust async 无运行时争用，两者都随并发线性增长。
2. **Node 客户端（~6-11k）是全链路最弱环节**——CLI/嵌入方自己发请求时注意；
   浏览器/curl/Go 等外部客户端不受限。
3. **undici 替代 http.request 不改善服务端**（瓶颈在 http.Server 事件循环，
   不在上游客户端）。
4. **Rust 调优实验的教训**：朴素版 55-63k → 调优版 118-157k（+2.5×），元凶
   是 **`Regex::new` 每请求编译**（~10-30µs 串行在事件循环上）——语言上限
   ≠实现即得，移植时正则/解析器必须编译一次。
5. 真实隧道场景里公网 RTT（10-200ms）远大于 loopback 开销，此差距被稀释到
   <5%；只有**纯本地/局域网 proxy 高并发**才值得在意。

### 3.5 控制面：无热点

- discovery 有 5s TTL 缓存；`isServicePortAllowed` 只在低层 `create()` 无 D4
  resolver 时走发现列表（`some()` 遍历，端口数很小）。
- daemon IPC / tunnel spawn / nginx 配置生成均低频。
- `parseServiceHost` 每请求构造 RegExp（V8 按源码缓存编译），实测 0.11µs，
  可忽略。

---

## 4. 生产性能结论：会不会有问题？折扣多少？

**先给结论：作为"隧道编排 + 开发代理"工具，绝大多数生产场景无性能问题。**
作为"真实流量的认证反向代理"（`--mode proxy/both` 长期服务生产流量），
**basic 与 forward-auth 两条路径不优化会被流量打穿**。

| 场景 | 单核上限（Node 现状，服务端口径） | 够不够 | 缺口（vs Go/Rust） |
|---|---|---|---|
| 开放 vhost 纯代理 | ~30-34k rps（并发再高持平） | 中低流量够 | ~3-5×（Go 93-138k；Rust 调优 118-157k） |
| token 认证 | ~23k rps | 够 | 3× 左右 |
| forward-auth（portal 本地验签后） | **~0 探针开销** | 够 | 并发能力是主要差距（authelia/oauth2-proxy 仍需探针） |
| forward-auth（authelia/oauth2-proxy，每请求探针） | ~4.3k rps + HOL 风险 | 中低流量够 | 并发能力是主要差距 |
| basic 认证 | **~340 rps** | **不够（高流量）** | 算法成本两语言相同；修复 = 换会话类认证承载高流量，非缓存 |

> 注：`~30-34k rps` 为 Go 客户端交叉测量（`test/perf/cross-client/`）的
> 服务端真实吞吐；早期同语言自bench的 6.3k 是 Node 客户端上限，勿混用。

"折扣多少"的量化口径（修正后）：

1. **开放代理服务端吞吐**：Node ~30-34k（并发不增长）vs Go 93-138k vs Rust
   调优 118-157k → **Node ≈ Go 的 25-33%、Rust 的 20-27%**——不是早前的 1/12。
   Rust 调优实验证明**语言上限≠实现即得**：朴素版仅 55-63k（每请求
   `Regex::new` 编译），修掉后 118-157k。
2. **认证路径**：折扣来自**设计**而非语言——basic 路径 Node 与 Rust 同为
   ~2-3ms/请求量级（都是 APR1 算法成本，逐请求校验是行业标准语义）；
   forward-auth 的 232µs 探针往返两种语言都省不掉。**Go/Rust 真正的增量是
   "并发"**（多线程/异步 vs 事件循环串行），不是单请求延迟；portal 本地验签
   （JWT 模式）两语言收益一致。
3. **Node 客户端（~6-11k）是全链路最弱环节**：CLI/嵌入方自用注意；外部客户端
   （浏览器/curl/Go）不受限。
4. **端到端**：经公网隧道（RTT ≥ 10ms）时，Node 与 Go/Rust 的端到端差距
   **<5%**——瓶颈是网络不是代理。

### 生产部署形态建议（不移植也能上生产）

- 高流量认证场景：**让 nginx 网关负责认证**（basic/token 走 auth_basic /
  auth_request——native、并行、无 Node 热点），Node 只做编排。架构已支持
  （gatewayMode basic/token），这是**零移植**的生产化路径。
- 嵌入式宿主（Next middleware 类，无法保留 vhost Host，决策 API 在进程内）：
  先做 §3.1/3.2 的优化（portal 本地验签、探针工程化、凭据缓存）再谈流量规模。
- 多核：Node 数据面可加 cluster/多实例 + 前置 LB，线性扩展（每 worker
  ~30-34k → 8 worker ~200k+，超过 Go 单进程）——注意共享状态（bindings/
  #registered/provider 实例）需随主进程同步，这是真实架构改动，不是纯性能项。

---

## 5. Rust / Go 移植方案

### 5.1 分层决策：什么值得移植

| 层 | 代码 | 值得移植？ | 理由 |
|---|---|---|---|
| CLI/控制面 | cli.ts/daemon/discovery/expose/tunnels/gateway 生成 | **否** | 无性能问题；重写 12k 行编排风险高；认证正确性（APR1/oauth2/authelia 流）重验成本大 |
| 数据面决策 | proxy.ts 决策 API（host 解析 + 门禁） | **条件性** | 见 5.3 |
| 数据面传输 | proxy.ts 的 pipe/upgrade | **条件性** | 服务端吞吐 3-5× 差距（Go 客户端交叉口径），仅本地高并发场景显著 |
| provider 探针 | portal/authelia/oauth2-proxy 的 authz 端点 | 否 | 已是生成的小脚本服务器；QPS 靠 portal 本地验签（零探针）+ 探针工程化解决 |
| nginx 网关 | 外部 nginx | 否 | 已是 native |

### 5.2 CLI 移植 Rust 评估（用户明确问的）

**可行性**：高（项目零依赖、逻辑自洽、CLI 边界清晰）。
**性能收益**：≈0（控制面无热点；daemon 秒级操作不受语言影响）。
**其他收益**：
- 单静态二进制分发（用户免装 Node ≥ 20.19，Windows/macOS/Linux 一包走）；
- 启动更快（Node ~50-100ms → Rust ~5ms）、内存更低（~40MB → ~10MB）；
- 无 npm 供应链（`justget` 依赖消失）、无 runtime 崩溃面。
**成本/风险**：
- 重写量：≈12k 行 TS（cli 4k + discovery 3.6k + expose 3.4k + tunnels 3.5k +
  providers 2.7k + gateway 2.6k + UI 4.8k + i18n 2.8k …）；
- 平台细节重验：/proc 解析（Linux/macOS/Windows 三套）、端口发现、进程树；
- 认证正确性重验：APR1（已有纯 JS 实现可对照）、oauth2/authelia 重定向流、
  TOTP、nginx 配置渲染等价性——**这是最容易悄悄引入安全回归的部分**；
- 生态：`service-tunnels` 的库 API（`st.proxy.resolve` 等）是 embedder 契约，
  移植版必须双实现或放弃嵌入式市场。
**建议**：**不为性能移植 CLI**。若目标是无 Node 分发，先做"轻量 Rust 启动器"
（下载/引导现 Node 包）或 Bun 打包，验证用户价值后再决定全移植。

### 5.3 数据面 Rust sidecar（推荐路径，若需要真性能）

复用项目已有的**"生成小服务器脚本再 spawn"模式**（portal/token 探针都是写
`.mjs` 再 `spawn(process.execPath)`），把数据面替换为 Rust sidecar：

```
Node 编排进程（决策/配置/绑定不变）
   │  spawn + 环境变量/配置文件传递 suffixes/bindings/auth 策略
   ▼
rust-proxy sidecar（单静态二进制）
   ├─ hyper/tokio accept :4180
   ├─ host 正则（regex crate，编译一次）
   ├─ 决策表（绑定 Map，共享内存或文件热更新）
   ├─ 门禁：portal 本地验签（HMAC 密钥共享）、APR1 校验（与 Node 同算法成本）、
   │        token 凭据缓存（mtime 失效）、forward-auth 并发探针（无事件循环串行）
   └─ pipe/upgrade 转发（tokio 双向 copy）
```

接口建议（与现架构同构，降低改造面）：
- 决策输入：Host/URL/method/authorization/cookie → 与现 `ServiceHostDecision`
  对齐的枚举输出（deny/deny-auth/pipe/redirect/static/forward）。
- 门禁数据（htpasswd/tokens/provider 端口）经**文件 + mtime 轮询**传递——
  与现有 token 探针"每请求读文件"的设计一致，但 Rust 侧可缓存解析。
- 内嵌模式（宿主 middleware 无法起端口）保留 Node 决策 API，共享同一套缓存
  策略代码的 JS 实现。

预期收益（实测，Go 客户端口径）：开放路由 Node 30-34k → Rust 调优版实测
118-157k（3.5-5×）；forward-auth 并发探针不再 HOL；portal 本地验签零探针；
token 凭据缓存 43µs → ~1µs。APR1（basic）两语言同成本，不靠移植解决。
**移植要点（Rust 调优实验实证）**：host 正则编译一次（OnceLock）、上游 Uri
预构建、客户端池化显式声明——否则朴素实现只有 55-63k。

### 5.4 Go 替代评估

- Go 单进程 93-138k rps（Go 客户端交叉口径，conc 100→1000），是 Node 服务端
  （~30-34k）的 3-4.5×，工程上比 Rust 好写（gc、生态、团队上手快），
  `net/http` + `httputil.ReverseProxy` 即插即用；Rust 调优版（118-157k）略
  高于 Go，但差距不大，选择取决于团队熟练度与分发诉求。
- 缺点：二进制 ~8-15MB（vs Rust ~2-3MB）、内存 ~15-30MB、极端并发下 GC
  压力（>50k rps 时）不如 Rust 稳。
- **建议**：若团队 Go 熟、需求是"比 Node 强 5× 且开发快"→ Go；若目标是
  "数据面长期扛万级 rps/核 + 静态小分发"→ Rust。两者对**认证算法瓶颈
  （APR1）都没有免费午餐**（逐请求校验是标准语义，不缓存）；portal 本地验签
  与 token 凭据缓存两语言都要做。

---

## 6. 执行路线图

```
Phase 0  基准固化（已做，脚本在 test/perf/，npm test 不误跑；CI 可选）
Phase 1  JS 内算法/工程优化（不改架构，2-3 天）
         ├─ portal 本地验签：决策 API 共享 HMAC 密钥，verifySession 内联
         │    （JWT 模式，探针 232µs → 0，无缓存、撤销语义不变）
         ├─ 探针工程化：keep-alive Agent + 1s 超时 + provider 熔断
         │    （authelia/oauth2-proxy 保持每请求探针——nginx auth_request 语义）
         ├─ token 凭据缓存：内存 Map + 文件 mtime 失效（缓存查找，非决策）
         └─ 回归：全部现有 node --test 通过 + 基准复测记录前后数字
Phase 2  压测复验（autocannon/wrk 对内置 proxy 全模式矩阵：
         open/basic/token/forward-auth × 100/1k/10k rps）
         产出：明确的单核上限表 + 是否触发 Phase 3 的阈值
Phase 3  （条件）Rust 数据面 sidecar 原型（2-3 周）
         ├─ proxy.ts 决策 → Rust 决策表（端口/绑定/suffixes 同构）
         ├─ 门禁：portal 本地验签 / token 凭据缓存 / forward-auth 并发探针
         ├─ 灰度：daemon 模式默认 sidecar，库内嵌模式仍走 Node 决策
         └─ 对照基准：同机同负载 Node vs Rust sidecar
Phase 4  （可选）分发包改进：Rust 启动器/单二进制，与性能无关，单独立项
```

**触发 Phase 3 的阈值建议**：实测 `--mode proxy` 流量 > 3k rps/核（开放）或
> 300 rps/核（basic）且持续 1 小时以上；否则 Phase 1 的优化（portal 本地
验签 + 探针工程化 + 凭据缓存）+ nginx 网关认证已足够生产化。

---

## 7. 附录：基准复现

基准代码已入库 `test/perf/`（`npm test` 的 glob 是 `test/**/*.test.mjs`，不会
误跑这些压力脚本；运行方式见 `test/perf/README.md`）：

- `test/perf/node-proxy-bench.mjs` — Node 透传 proxy（host 正则 + pipe，自bench）
- `test/perf/go-proxy-bench/` — Go httputil.ReverseProxy 同路径（自bench）
- `test/perf/rust-proxy-bench/` — Rust hyper 1.x 同路径（tokio multi-thread，自bench）
- `test/perf/cross-client/` — **跨语言交叉基准（推荐）**：同一 Go 客户端打
  Node/Go/Rust 服务端，得到可对比的服务端真实吞吐（早期同语言自bench
  混淆了客户端/服务端瓶颈，见 §2.2）
- `test/perf/auth-bench.mjs` — APR1/token/host 正则微基准
- `test/perf/fwprobe-bench.mjs` — forward-auth loopback 探针往返

复现注意（与目标机差异相关）：固定 Node engines（>=20.19）与压力参数，避免
CI 环境差异导致不可比。测量注意事项：
- 客户端必须 keep-alive + 读空 body 才可复用连接（Go 侧实测未 drain body 时
  吞吐掉 50%）。
- **客户端必须只数成功响应并报 errors**（connection refused 的错误吞吐 ~90k+
  会被误当服务端性能，cross-client 目录的教训）。
- 预热 ≥ 300 请求后再计时；报 rps 同时报 P50/P99 延迟（现有脚本未打分位数，
  做对比时自行加）。
- 跨语言对比一律用 cross-client 口径（同一客户端）；自bench 仅作回归。
- 同机对比时注意并行负载（首次运行可丢弃，取第 2 次之后稳定值）。
