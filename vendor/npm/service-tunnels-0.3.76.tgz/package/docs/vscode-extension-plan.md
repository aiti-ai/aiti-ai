# VS Code 插件 + JS 可适配插件生态：公网端口暴露计划

> 目标：做一款 VS Code 扩展，一键把用户本地 dev server 端口暴露到公网
> （隧道 + 可选认证），并把 service-tunnels 沉淀为一套"任何 JS 生态工具都能
> 接入的公网暴露能力"。本文是计划文档：架构选型、功能路线、技术要点、
> 打包发布、外扩适配套件、里程碑与风险。
>
> **深挖结论见 [vscode-extension-research.md](vscode-extension-research.md)**
> （2026-08 代码级 + 实测调研：ESM 加载、spawn node、guardian、端口门禁、
> state.json 冲突、schema 冻结、Node 版本矩阵）。本文与之一致。
>
> **实施蓝图见 [vscode-extension-implementation.md](vscode-extension-implementation.md)**
> （仓库布局、扩展骨架、激活流程、Manager 封装、四层发现器、schema 表单契约、
> MVP 命令流、Phase 0 真机验收清单）。

---

## 0. 结论摘要

1. **service-tunnels 是为"被嵌入"而生的**：零运行时依赖、库模式进程内单例、
   schema 驱动 UI（新增隧道/provider 无需改客户端）、认证与隧道解耦、
   `host-integration.ts` 示例就是"宿主应用内嵌"的标准写法——VS Code 扩展
   正是理想的宿主形态。
2. **推荐架构 = 扩展宿主进程内嵌库 + 失败兜底走 daemon IPC**：内嵌获得最佳
   UX（discovery、事件、进程清理），daemon 兜底解决跨版本/嵌入失败场景。
   两种形态都无需外部二进制常驻（portal/basic 认证路径零外部依赖）。
3. **安全默认开箱即用**：默认 `--auth auto`（Windows=portal 零二进制，
   Linux/macOS=authelia），暴露即受保护；D4 零转发保证本地端口不裸奔。
4. **发布依赖公共 npm 迁移**（AGENTS.md 阻塞项）：VS Code 扩展要上
   Marketplace 必须先完成 service-tunnels 的清洗上架（内部→公共 npm），
   否则只能走内部私有市场/本地 .vsix。
5. **外扩是第二战场**：CLI（任意语言一行调用）+ 库（JS/TS 内嵌）+
   daemon JSON-RPC（任意语言原生 IPC）+ env 注册扩展点（零代码自定义隧道）
   四层适配面，覆盖 Vite/SSG/Electron/CI/其他编辑器。

---

## 1. 定位与用户故事

**一句话**：在 VS Code 里对任何本地端口执行"暴露"（tunnel / proxy / both），
拿到公网 URL，自动带认证，停止/清理一键完成。

**核心用户故事**：

| 用户 | 场景 |
|---|---|
| 前端开发者 | `npm run dev` 起 Vite → 状态栏点一下 → 公网 URL 发给客户验收/联调 |
| 全栈联调 | 本地 5173 前端 + 3000 后端，两个端口各自暴露或走 proxy 固定域名 |
| 微信/支付宝回调调试 | ngrok/natapp 拿公网 HTTPS URL 填到回调配置，收到 webhook |
| 教学/演示 | 临时把本地演示站暴露给远程观众，演示完一键收回 |
| 团队共享 | portal/basic 认证 + 用户管理，同事用自己的账号进 |
| 机器访问 | CI/脚本用 `auth token`（Bearer header），无登录页 |

**非目标（v1 前）**：不做托管的"我的隧道"账号体系；不做团队协作后台；
不接管用户已有的 nginx/Authelia 部署（用库的自动拉起即可）。

---

## 2. 为什么是 service-tunnels（而不是直接调 ngrok CLI）

| 维度 | ngrok CLI 直调 | service-tunnels 内嵌 |
|---|---|---|
| 隧道多样性 | 只 ngrok（要账号） | 9 种：cloudflared（零账号）/ bore（自建零账号）/ natapp（CN）/ ssh / serveo / frpc / localtunnel / ngrok / command |
| 认证 | 无（或 Edge OIDC 要钱） | portal（零二进制，Windows 友好）/ basic / authelia / oauth2-proxy + 2FA + Bearer token |
| 中国网络 | 差 | natapp + 下载镜像（ghproxy/npmmirror）优先 |
| 进程发现 | 无 | `st.discovery` 直接列出用户 dev server 端口 |
| 清理 | 手动 | guardian + state.json：崩溃/退出自动回收子进程 |
| 库形态 | 黑盒二进制 | 纯 JS 内嵌，事件订阅（tunnel:url 等） |
| 配置隔离 | 全局 | 每扩展/每站点独立 config/cache 目录（0600） |

---

## 3. 架构选型

### 3.1 三种接入方式对比

| 方式 | 形态 | 优点 | 缺点 |
|---|---|---|---|
| A. 内嵌库 | 扩展宿主进程内 `createServiceTunnels()` 单例 | 最佳 UX：discovery、事件、无外部进程、进程退出自动清理 | ESM 打包挑战；扩展宿主 Node 版本门槛（≥20.19）；终端 task 进程不在扩展宿主进程树下 |
| B. CLI 侧车 | spawn `sts daemon start` + 每次 `sts ...` 命令调用 | 实现最薄；daemon 跨调用持有隧道 | 需依赖 CLI 安装或随包捆绑；每操作一次子进程开销；UX 难做细（状态同步靠轮询） |
| C. daemon IPC | 扩展直接连 daemon JSON-RPC（unix socket / Windows TCP+secret） | 跨语言、可被任何工具复用；daemon 常驻持隧道 | 需维护 RPC 客户端；状态事件需要轮询或扩展 daemon |

### 3.2 推荐：A 为主，C 兜底（混合）

```
┌─────────────── 扩展宿主（VS Code 内置 Node，扩展本体为 CJS） ─────────────┐
│  const { createServiceTunnels } = await import("service-tunnels");  ←动态import│
│  st = createServiceTunnels({ configDir, cacheDir, marker:"vscode-st",       │
│                              nodePath: process.execPath })   // F2          │
│  discovery / expose / auth.user / sites / events（库模式进程内单例）        │
│       │ 失败（版本/嵌入异常）                                             │
│       ▼                                                                  │
│  daemon 客户端（spawn `sts daemon start` → 连 JSON-RPC）                 │
└──────────────────────────────────────────────────────────────────────────┘
```

- **扩展本体必须 CJS**：VS Code 尚不支持 ESM 扩展（官方 issue #130367 仍
  Open），用 `await import("service-tunnels")` 动态桥接 ESM-only 库——
  已实测通过，且避免 esbuild 打包（CJS 输出下 `import.meta` 为空对象，
  daemon.js 加载即崩，见 research F1）。
- 扩展宿主里 `process.execPath` 是 VS Code 二进制而非 node：需传
  `nodePath` 并让库侧 spawn 带 `ELECTRON_RUN_AS_NODE=1`（库侧小改，见
  research F2），否则 portal/token 认证 provider 无法拉起。
- 内嵌失败或扩展宿主 Node 过旧时，回退 C：`sts daemon start` 自动拉起后
  通过 `st.daemon.request()` 同名 RPC 调用（库自带 `requestDaemon`，无需自研）。
- 两种形态暴露相同的最小接口集（见 §4.4），上层 UI 不感知差异。

### 3.3 进程模型与端口发现（关键约束）

- `st.discovery` 默认以 `process.pid`（扩展宿主）为根扫描后代：
  - ✅ **debug 会话启动的进程**是 debug adapter 的子进程 → adapter 是扩展宿主
    后代 → 能被发现；
  - ⚠️ **集成终端里手动跑的 `npm run dev`** 是终端 pty 进程的后代，**不在**
    扩展宿主进程树下 → discovery 直接扫不到。
- **但 expose 的门禁不是进程树，是 `verifyPortOwner`（同 OS 用户）**
  （expose.ts 双路径确认）：终端手动启动的服务，只要与 VS Code 同用户，
  暴露时端口归属校验直接通过——原"发现不到就不能暴露"的担忧不成立
  （research F4）。进程树 discovery 只影响**端口选择器 UX**。
- **对策（端口选择器，四层获取）**：
  1. `st.discovery.getPorts({ rootPid: <扩展宿主 pid> })` —— 覆盖 debug 场景；
  2. `tasks.onDidStartTaskProcess` 拿 task 进程 pid → 以其为 root 再 discovery
     —— 覆盖 Task（Ctrl+Shift+B）启动的服务；
  3. 终端 shell integration（VS Code 1.93+）`terminal.processId` → rootPid=终端
     —— 覆盖终端手动 `npm run dev`；
  4. 常见开发端口探测（5173/4173/3000/8000/8080/4200…，仅 127.0.0.1 非框架
     端口）+ 手动输入兜底。
- 暴露对象 = 端口号，与语言/框架无关——插件对任何 dev server 都成立。

---

## 4. 功能规划

### 4.1 MVP（v0.1，目标 3-5 天）

**命令（Command Palette）**：

| 命令 | 行为 |
|---|---|
| `st: Expose Port…` | 弹出端口选择（discovery 结果 + 常见端口 + 手动输入）→ 选隧道类型（默认按平台：cloudflared 零账号 / natapp CN / ngrok）→ 选认证（默认 auto）→ 暴露 |
| `st: Stop Exposure` | 列出当前暴露项，停止并清理 |
| `st: Open in Browser` | 打开公网 URL |
| `st: Copy URL` | 复制到剪贴板 |

**UI 元素**：
- **状态栏**：暴露后显示 `🌐 <域名>`（点击复制 / 右键菜单：打开、停止）；
  无暴露时显示 `🌐 未暴露`（点击走 Expose 流程）。
- **输出通道** `service-tunnels`：隧道启动日志、URL、错误。
- **设置项**：`configDir` / `cacheDir` / 默认隧道类型 / 默认认证模式 /
  `preferMirrors`（CN 镜像优先）/ `allowToolDownload` / 端口探测列表。

**生命周期**：
- `activate`：`st.init()` + 恢复 state.json 中的存活隧道并订阅事件
  （`tunnel:url` / `tunnel:stop` 刷新状态栏）。
- `deactivate` / 窗口关闭：`st.shutdown()`（清理全部子进程；guardian 兜底
  扩展宿主崩溃场景）。
- 每次暴露默认 `--auth auto`，**不允许裸奔**（联动 `allowAuthNone` 粘性开关）。

**验收标准**：`npm run dev`（终端手动启动）→ 手动输端口 → 一条命令拿到
带认证的公网 URL → 停止后本地/公网入口都回收 → 关闭 VS Code 无残留进程。

### 4.2 v1（5-8 天）

> 认证管理 UX 已细化到实施蓝图 §9（bootstrap/SecretStorage/TreeView/命令流/安全自检）。

- **侧边栏 TreeView**：当前暴露列表（端口/隧道类型/URL/认证状态）+
  启停删 + 展开显示认证详情。
- **认证管理页**：
  - 首次暴露引导创建初始用户（`st.auth.addUser`，随机密码一次展示）；
  - 用户增删/改密（`auth.user.*`）、TOTP 2FA 开关（`auth.totp.*`）、
    Bearer token 管理（`auth.token.*`，供 CI 机器访问）。
- **schema 驱动表单**：用 `st.schemas.tunnels()` / `authProviderSchemas`
  （含 i18n `localizeSchemas`）动态渲染隧道参数与 provider 参数表单——
  **新隧道类型/新 provider/用户 env 注册的自定义隧道自动出现在表单**，
  插件零改动。表单提交走 CLI 同款校验语义（`--set` / `--provider-set` 参数）。
- **多隧道并存**：一次暴露多端口；`--mode both`（本地 proxy + 公网隧道
  同 site 同用户）；`--mode proxy`（仅本地固定域名，适合内网联调）。
- **site 支持**：进阶设置里可建多个 site（认证域），把不同项目隔离
  （项目 A 用户不能进项目 B）。

### 4.3 v2（待定）

- **debug/task 集成**：launch.json 起服务后自动提示暴露；task 结束时自动回收。
- **URL 二维码**（手机扫码演示）、**端口转发面板**（内置转发器，无需 node_modules
  依赖时也可用）、**配置文件驱动**（.service-tunnels.json 声明默认隧道/认证）。
- **Telemetry-free 上报日志导出**（方便用户反馈问题时脱敏导出）。
- **Web 视图**（webview）：把 `sts ui` 的核心页面搬进侧边栏（复用 ui.ts 的
  schema 渲染逻辑）。

### 4.4 最小接口集（内嵌/daemon 双形态必须一致）

```
discover()                                  → ServicePortInfo[]
expose(port, { mode, tunnelType, auth, site?, tunnelParams?, providerParams? })
                                            → { url, loginUrl, tunnel, provider }
stop(port) / listExposes()
authUserAdd(name, password?, site?)          → { password(首次随机), providers }
authTokenCreate(description, expires?)       → { token }   // 机器访问
tunnelList() / tunnelStop(name)
events: tunnel:url / tunnel:stop / expose:error
```

---

## 5. 关键技术点

### 5.1 ESM 加载（最大技术风险，已深挖：research F1）

- **VS Code 不支持 ESM 扩展**（官方 issue #130367 仍 Open，milestone
  Backlog）→ 扩展本体必须 CJS，`"type"` 不能设为 module。
- **esbuild 打 CJS 实测失败**：`import.meta` 被替换为空对象（4 处警告），
  `daemon.js` 在**模块加载时**执行 `fileURLToPath(import.meta.url)` →
  import 即 TypeError。banner shim 可修但等于给库打补丁，不采用。
- **采用：CJS 扩展 + 动态 import 桥接**（实测通过）：
  ```js
  const { createServiceTunnels } = await import("service-tunnels");
  ```
  库以真实 ESM 从 node_modules 加载，`import.meta.url` 指向真实路径，
  内部 spawn 脚本解析全部正确；vsce 打包 node_modules（service-tunnels
  + justget，纯 JS <1MB）。未来 VS Code 开放 ESM 扩展可无缝切换。

### 5.2 Node 版本门槛（已深挖：research F8）

- **dist 运行时下限实测是 Node 18**（promotion-plan §2.2 实测表），engines
  `>=20.19` 是策略非硬限；22.19 只是 dev/test 直跑 `src/*.ts` 的要求。
- VS Code 扩展宿主内置 Node：1.98+ 为 20.19+，近期版本 22+ → 满足策略下限；
  更旧的 1.9x（20.14/20.18）dist 也兼容。
- 对策：`engines.vscode` 声明保守下限（建议 `^1.85.0` 起步，Phase 0 用
  product.json 逐版本核对精确值）；activate 检测 `process.versions.node`，
  <20.19 时提示或切 daemon 兜底。
- 库模式不依赖系统 Node——扩展宿主自带，用户无感知。

### 5.3 安全设计（默认即安全）

- 暴露默认 `auth: "auto"`（Windows→portal 零外部二进制；Linux/macOS→authelia
  完整 2FA）；用户主动选 `none` 需确认弹窗。
- 透传隧道永远只指向本地网关端口（127.0.0.1 白名单 + D4 零转发），未 enroll
  的端口公网不可达。
- `configDir`/`cacheDir` 权限 0600；portal 登录 RSA 加密 + 防爆破；
  token 只在创建时显示一次、库内只存哈希。
- **无遥测**：不上报任何使用数据；输出通道日志用户可控（脱敏导出）。
- 暴露 URL 是公网可访问的——UI 上显著提示"已公开"状态，一键收回。

### 5.4 多语言

库自带 i18n（`t()` / `localizeSchemas`），扩展 UI 文案复用同一机制：
`zh`/`en` 起步，跟随 VS Code 的 `nls` 语言设置。

---

## 6. 打包与发布

### 6.1 依赖形态

- **内部阶段**：package.json 依赖 `service-tunnels: "file:../service-tunnels"`
  （或私有 registry `npm.alot.pw`），vsce 打包 .vsix 内部安装/私有市场。
- **公共阶段（阻塞项）**：必须先把 service-tunnels 按 AGENTS.md / 
  `docs/promotion-plan.md` 完成迁移清洗并发布公共 npm，插件改为依赖
  `service-tunnels: "^0.4"` 后上 VS Code Marketplace。

### 6.2 vsce 打包要点

- `vsce package`：files 只含 `dist`（打包后产物）+ `README` + `LICENSE` +
  图标；service-tunnels 与 justget 进 node_modules（依赖仅 justget，无原生
  模块；ngrok/authelia 等二进制按需下载到 cacheDir，**不进 vsix**）。
- 扩展大小预期 < 2MB，远低于 Marketplace 限制。
- CI：GitHub Actions `vsce publish`（内部阶段可先只打 .vsix artifact）。

### 6.3 Marketplace 上架清单

- 图标、README（中英）、LICENSE（MIT，与 service-tunnels 一致）、SECURITY。
- 声明"暴露公网"用途，提供安全指引（认证默认开、勿暴露敏感端口）。
- 版本策略跟随 service-tunnels 发布节奏；破坏性 API 变动前先发扩展兼容层。

---

## 7. 外扩：JS 可适配插件的适配套件（第二战场）

> 目标：让"任何跑得起来 JS 的工具/插件"都能通过 service-tunnels 对外暴露
> 端口，按接入成本从薄到厚分四层；每层都有现成入口，不需要改库。

### 7.1 四层适配面

| 层 | 入口 | 适合对象 | 最小示例 |
|---|---|---|---|
| L1 CLI | `sts expose <port> --mode tunnel --auth auto --json`（已有 JSON 输出） | 任何语言/脚本/编辑器插件 | `sts expose 5173 --auth auto` 拿 `{url, loginUrl}` |
| L2 库内嵌 | `createServiceTunnels()` + `st.auth.expose()` | JS/TS 应用（Electron、CLI 工具、CI 脚本） | 见 `examples/expose-self.ts`（3 行） |
| L3 daemon IPC | newline JSON-RPC over unix socket（0600）/ Windows TCP+secret（state.json 取地址与密钥） | 任意语言写原生客户端（Java/Go/Python/Rust） | 见 7.2 |
| L4 零代码扩展点 | `SERVICE_TUNNELS_TUNNEL_COMMAND_<NAME>`（自定义隧道）/ `SERVICE_TUNNELS_OAUTH2_VARIANT_<NAME>`（自定义 IdP） | 任何想注册自有隧道/认证形态的一方，纯 env，不改库不改客户端 | `export SERVICE_TUNNELS_TUNNEL_COMMAND_sshbox="ssh -R {{port}}:127.0.0.1:{{localport}} u@h"` |

### 7.2 daemon IPC 协议（L3 最小客户端规格）

- 定位：POSIX `cacheDir/state.json` 中 `ipcPath`（unix socket）；Windows 为
  `tcp://127.0.0.1:<port>` + `ipcSecret`。
- 协议：每行一个 JSON 请求 `{id, method, params}` → 响应 `{id, result|error}`；
  Windows 走 HTTP POST，需带 `x-service-tunnels-auth: <secret>` 头。
- 关键方法（现成）：`tunnel.list/add/start/stop/remove`、`expose`、
  `proxy.start/status/bindings`、`auth.user.*`、`auth.token.*`、`auth.totp.*`、
  `internal.list`、`config.*`、`schemas`（schema 驱动：**新隧道/provider 自动
  出现，客户端零改代码**）。
- 任意语言实现成本：一个 socket 连接 + JSON 编解码，约 50-100 行。

### 7.3 目标适配清单（按投入产出排序）

| 目标 | 接入层 | 场景 | 备注 |
|---|---|---|---|
| **Vite 插件**（`@service-tunnels/vite`） | L2 | `vite dev` 启动时可选暴露，terminal 里打印 URL | 监听 vite `configureServer`，拿 `server.httpServer.address().port` |
| **webpack-dev-server / Storybook** | L2 | 同上 | 用 `devServer.port` 暴露 |
| **SSG（vitepress/docsify/serve）** | L1 | 静态站一键分享 | 包装成 `sts-serve` bin |
| **Electron/Tauri 应用** | L2 | 内置服务对外演示/联调 | 内嵌库，生命周期随应用退出清理 |
| **CI（GitHub Actions）** | L3/L1 | 预览环境、e2e 共享 URL | token 认证（Bearer）给机器访问，无登录页 |
| **其他编辑器**（Sublime/neovim/emacs） | L1 | 终端命令即可 | 插件只需一行 `sts expose` |
| **JetBrains 系** | L3 | 原生客户端走 IPC | 写最小 Java client，或退化为调 CLI |
| **测试工具**（Playwright/WebdriverIO） | L1/L3 | 临时公网 URL 跑远程验证 | 隧道生命周期 = 测试进程生命周期 |

### 7.4 适配套件交付物

1. `docs/adaptation-kit.md`：四层接入指南 + **L3 daemon IPC 协议完整规范**
   （寻址/帧格式/方法目录全表/安全边界/Go 最小客户端）✅ **已落地**
   （2026-08-07）。
2. `examples/`：`vite-plugin` / `ci-github-actions` / `ipc-client-go`
   三个参考实现 ✅ **已落地**（2026-08-07，各含 README；Go 客户端编译通过
   + 真机冒烟；vite 插件与 bash 脚本语法/编译校验通过）。
3. CLI 输出收敛：**审计已完成**——操作类命令 `--json` 已全覆盖
   （adaptation-kit §1.2 全表），无需补齐；后续破坏性字段变更走 §5 冻结承诺。
4. schema 接口稳定化（冻结 `tunnelParamSchemas` / `authProviderSchemas` 字段）
   ——**已落地**（2026-08-07）：`schemasVersion`（`TUNNEL_SCHEMAS_VERSION` /
   `AUTH_SCHEMAS_VERSION`，schemas RPC 与 `st.schemas.versions()` 均返回）+
   `test/schemas-freeze.test.mjs` 8 项形状断言（字段基线/类型/选项/基线类型
   清单，只增不减）。契约见 adaptation-kit §5。

---

## 8. 里程碑与工作量（单人）

| Phase | 内容 | 工时 | 产出 |
|---|---|---|---|
| 0a | 库侧适配补丁：spawnNode（Electron 宿主 node 运行时）+ guardian 可移植 main 检测 + 单测 | ✅ 已落地（research §11） | src/spawn-node.ts + 4 处调用点改造 + guardian.ts 修复 |
| 0b | 真机 spike：CJS 动态 import / portal expose（ELECTRON_RUN_AS_NODE）/ 终端+task 发现 / Windows 延迟 / Node 版本映射（验收清单见 implementation §8） | 1-2 天 | 技术结论 + engines.vscode 精确值 |
| 1 | MVP：骨架/命令/状态栏/四层发现器/生命周期/设置项（implementation §2-§7） | 3-5 天 | 可安装 .vsix，内部试用 |
| 2 | v1：TreeView、认证与用户/2FA/token 管理、schema 动态表单、多隧道、site 隔离 | 5-8 天 | 功能完整的 v1 |
| 3 | 生态：适配套件文档 + 三个参考实现 + CLI --json audit + schema 冻结评审 | ✅ 已落地（2026-08-07） | adaptation-kit（协议+契约）、vite-plugin / ci-github-actions / ipc-client-go、schemas-freeze 测试 8 项、CLI --json 审计表 |
| 4 | 发布：公共 npm 迁移（前置阻塞项）→ Marketplace 上架、图标/README/SECURITY、CI 构建 vsix | 2 天（不含迁移） | 公共市场 v1.0 |
| 5 | v2 前瞻：debug/task 集成、二维码、webview 管理页 | 待定 | 后续迭代 |

**合计：MVP 约 1 周，v1 约 2 周，生态层并行 1 周。**

---

## 9. 风险与开放问题

| # | 风险 | 影响 | 对策 |
|---|---|---|---|
| 1 | VS Code 扩展宿主 Node 版本 < 20.19 | 内嵌失败 | **已解**：dist 下限实测 Node 18（research F8）；engines 保守声明 + 版本检测 + daemon 兜底 |
| 2 | ESM 加载 | 构建阻塞 | **已解**：CJS 扩展 + `await import()` 桥接，实测通过（research F1）；esbuild 打 CJS 已证不可行 |
| 3 | 集成终端 dev server 不在扩展宿主进程树 | 端口选择器漏项 | **已解**：expose 门禁是同用户非进程树（research F4）；选择器四层获取（task pid / 终端 pid / 探测 / 手动） |
| 4 | `process.execPath` 非 node | portal/token provider 无法拉起 | **已解**：库侧 `nodePath` 选项 + `ELECTRON_RUN_AS_NODE=1`（research F2，需库小改，见 §9） |
| 5 | guardian 在 Node 20 静默失效 | 崩溃时清理不及时 | **已解**：可移植 main 检测（research F3）；扩展侧 `guardian:false` + deactivate shutdown |
| 6 | state.json 多写入者冲突 | 隧道状态互相覆盖 | **已解**：扩展用专属 config/cache 目录（research F5） |
| 7 | 公共 npm 未迁移（AGENTS.md 硬阻塞） | 无法上 Marketplace | 先内部 .vsix 试用；公共发布列入 Phase 4 前置项，勿跳步 |
| 8 | 暴露公网 = 安全暴露面 | 用户数据风险 | 认证默认开、D4 零转发、显著公开提示、一键收回、无遥测 |
| 9 | schema 未冻结 → 插件/外部客户端升级即碎 | 生态信任 | Phase 3 冻结 schema 字段 + `schemasVersion` + 形状断言（research F6） |
| 10 | 二进制工具被安全软件误报（frpc 等） | 用户体验 | 沿用 design.md §8.1 声明；下载前确认；可用 cloudflared 等零风险替代 |

**剩余开放问题（Phase 0 真机 spike 验证，详见 research §11）**：
- VS Code 各版本 → 内置 Node 精确映射（用于 engines.vscode 精确值）；
- `ELECTRON_RUN_AS_NODE` 在 VS Code 官方二进制上的真实行为（Extension
  Development Host 里 portal expose 冒烟）；
- CJS 动态 import 在扩展宿主 loader 下的 node_modules 解析；
- Windows discovery（PowerShell）在扩展宿主高频调用下的延迟；
- 是否把扩展与 service-tunnels 库同仓维护（推荐：同仓 `extensions/vscode/`
  子目录，随库版本发布）。
