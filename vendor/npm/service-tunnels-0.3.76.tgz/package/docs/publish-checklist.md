# 公开仓发布清单（内部文档，不入公开仓）

> 用途：推送到公共 GitHub/Gitee 仓库前的**文件清单核对**与**隐私清洗核对**。
> 本文件本身属于内部文档，**不得随公开仓发布**（发布时删除本文件）。

---

## 1. 隐私信息清洗（已完成 ✅）

| 文件 | 位置 | 处理 |
|---|---|---|
| `src/providers/portal.ts` | L384 注释 `8905-pi-web.pi.alot.pw` | → `5173-app.example.com` |
| `test/portal.test.mjs` | L293-294 注册 host / TOTP label 断言 | → `5173-app.example.com` |
| `test/proxy.test.mjs` | L746/748/753/757 label/site `pi-web` | → `app` |
| `CHANGELOG.md` | 0.3.12 条目「嵌入方(pi-web Next middleware)」 | → 「宿主应用」 |
| `SECURITY.md` | 状态说明「当前发布在私有 registry」 | → 删除私有 registry 表述 |
| `docs/mirrors.md` | 「私有项目镜像」小节（内部仓库） | → 删除 |
| `package-lock.json` | ① `../pi-web/node_modules/...` 外链条目（53 处）② `resolved` 指向 `npm.alot.pw` 内部 registry ③ engines/bin 与 package.json 不同步 | → 全量重新生成：删除 node_modules + lockfile 后 `npm install`（`NODE_ENV` 非 production 时记得 `--include=dev`；registry 用 `https://registry.npmjs.org`） |

**清洗后校验命令**（应输出 0 匹配）：

```bash
grep -rniE "alot\.pw|pi\.alot|pi-web|npm\.alot|30141|30142|57442|/home/wind" \
  --include="*" . | grep -vE "node_modules|^\./dist|^\./\.git|^\./test/perf/rust-proxy-bench/target"
```

剩余匹配全部位于 §3 EXCLUDE 清单内的文件，属预期。

---

## 2. 公开仓保留清单（INCLUDE）

### 根目录
- `package.json`（bin=`service-tunnels`/`sts`，engines `>=20.19.0`，已核对）
- `package-lock.json`（已清洗）
- `README.md`（无内部信息）
- `SECURITY.md`（已清洗）
- `CHANGELOG.md`（已清洗）
- `tsconfig.json` / `tsconfig.build.json`
- `.gitignore`
- `LICENSE` ⚠️ **缺失**：package.json 声明 MIT，公开前必须补 MIT LICENSE 文件

### src/（核心库，全部保留）
- `src/*.ts`（31 个：authelia / auth-provider / auth-registry / cleanup / cli / config /
  daemon-server / daemon / discovery / expose / gateway / guardian-spawn / guardian /
  i18n / index / internal / marker / pid-registry / ports / proxy-manager / proxy /
  redis / sites / spawn-node / state / tools / tunnels-config / tunnels-custom /
  tunnels / ui / validation）
- `src/providers/*.ts`（basic / oauth2-proxy / oauth2-variants / portal(已清洗) / token）
- `src/ssh/*.ts`（domain / gateway / manager / vendor）
- `src/vendor/ssh2/**`（vendored ssh2，MIT，随包零依赖）

### test/（npm test 覆盖的功能测试）
- 已入库：`auth-none / auth / config / daemon / discovery / expose-default /
  expose-proxy / expose-shared / gateway-portal / guardian / i18n / oauth2-gateway /
  oauth2-proxy / oauth2-variants / plugins / portal(已清洗) / proxy(已清洗) / sites /
  token / tools / tunnels / validation`（22 个 `.test.mjs`）
- ⚠️ 未入库（发布前需先 git add）：`schemas-freeze / spawn-node / ssh-daemon /
  ssh-domain / ssh-expose / ssh-gateway / ssh-hardening / ssh-ui`（8 个新功能测试）

### docs/（成熟功能/设计文档，11 + 1 个）
- 已入库：`api.md / auth-cross-platform.md / auth-provider.md / cli.md / config.md /
  design.md / input-validation-security.md / mirrors.md(已清洗) / oauth2-variants.md /
  sites-design.md / token-auth-design.md`
- ⚠️ 未入库：`adaptation-kit.md`（daemon IPC 协议 + schema 契约，对公共用户有价值；
  发布前先 git add）

### examples/（公共示例，均无内部信息）
- `expose-child.js/.ts`、`expose-self.js/.ts`、`host-integration.ts`
- ⚠️ 未入库：`ci-github-actions/`、`ipc-client-go/`、`vite-plugin/`

### scripts/（构建与测试必需）
- `fix-dts.mjs`、`copy-vendor.mjs`（`npm run build` 依赖）
- `mock-idp.mjs`（oauth2 测试依赖）
- `browser-serve.mjs`（开发者浏览器验证工具，无内部信息）

### tools/
- `verify-policy.mjs`（portal 认证策略端到端验证，无内部信息）

---

## 3. 公开仓剔除清单（EXCLUDE）

### 内部约定 / 评审 / 发布文档
| 文件 | 原因 |
|---|---|
| `AGENTS.md` | 内部开发/发布约定，含 alot.pw、pi-web、内部端口 |
| `docs/promotion-plan.md` | 内部评审结论 + 推广计划（tracked） |
| `docs/perf-analysis.md` | 内部评审文档（tracked） |
| `docs/session-model-design-review.md` | 内部审核报告（untracked） |
| `docs/publish-checklist.md` | 本文件 |

### 内部规划 / 调研 / 设计文档（均为 untracked 内部中间产物）
- `docs/expose-landscape-plan.md`（含 pi-web/opencode/PiClaw 大量内部引用）
- `docs/expose-research-summary.md`（内部调研）
- `docs/idea-plugin-plan.md`（含 alot.pw 引用）
- `docs/mcp-server-plan.md`（含 alot.pw / 内部端口 / /home/wind 引用）
- `docs/p0-dual-base-design.md`（pi 扩展 / MCP 内部设计）
- `docs/session-model-design.md`（内部设计）
- `docs/tcp-tunnel-ssh-auth.md`（含 npm.alot.pw 引用）
- `docs/vscode-extension-plan.md`（含 npm.alot.pw 引用）
- `docs/vscode-extension-implementation.md`（内部实现）
- `docs/vscode-extension-research.md`（内部调研）

### 内部运维 / 宿主集成脚本
- `scripts/sync-to-piweb.sh`（宿主集成，含 pi-web 路径）
- `scripts/mirror-to-gitee.sh` / `scripts/mirror-code-push.sh` / `scripts/mirror-tools-to-gitee.sh`
  （维护者私有 Gitee 镜像 org 运维脚本；公共镜像 URL 已写在 docs/mirrors.md，无需脚本）
- `.github/workflows/sync-gitee.yml.example`（镜像 workflow，引用内部仓库路径）

### 内部基准 / 调试代码
- `test/perf/**`（全部：auth-bench、cross-client、fwprobe-bench、go-proxy-bench、
  node-proxy-bench、rust-proxy-bench + README —— 内部性能研究，tracked，公开前 git rm）
- `test/.dbg-m6.mjs`（调试草稿，untracked，不入库）

### 构建 / 运行产物（.gitignore 已覆盖，确认不入库即可）
- `dist/`、`node_modules/`、`*.tgz`、`.playwright-mcp/`
- `test/perf/rust-proxy-bench/target/`、`test/perf/*/` 编译二进制
  （goclient / goproxy-server / gobare-server / benchrs 等，**注意这些二进制内含
  本机路径字符串，严禁入库**）

---

## 4. 发布前待办（按 AGENTS.md 与 promotion-plan.md）

1. **补 `LICENSE`**（MIT，写明版权人）——目前缺失，npm 与 GitHub 都要求。
2. **剔除 EXCLUDE 文件**：公开推送前先 `git rm`（或另建分支/filter 导出）；
   untracked 的 EXCLUDE 文件直接不 add。
3. **`npm publish --dry-run` 核对 files 清单**：
   - 当前 `package.json` `files` 含 `docs`（会把内部规划文档一并打进去）——建议改为
     显式列出公开 docs 文件，或发布前把内部文档移出 docs/；
   - 确认 `dist` 与 `src` 同步（`npm run build` 后再打包）。
4. **确认 `dist/` 无残留内部字符串**：本次清洗后已重新 build 校验通过
   （`grep alot\.pw|pi-web|/home/wind dist` 为 0）。
5. 仓库更名 / 发布注册：`service-tunnels`（公共 npm 名称当前可用，见 promotion-plan §2.1）；
   bin 用 `sts`（`st` 已被月下载 130 万活跃包占用，弃用）。
6. 公共 CI（test/lint）可在公开后再补；内部 sync-gitee 类 workflow 不随公开仓发布。
