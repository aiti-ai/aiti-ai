# IntelliJ IDEA 插件 + Java 移植：公网端口暴露计划

> 目标：做一款 IntelliJ IDEA 插件，一键把用户本地 dev server 端口暴露到公网
> （隧道 + 可选认证），并把 service-tunnels **核心移植为 Java 库**内嵌进插件
> （不依赖系统 Node）。本文是计划文档：移植范围与架构选型、Java 模块映射、
> IDEA 插件层设计、关键技术点、打包发布、里程碑与风险。
>
> 姊妹篇：[`vscode-extension-plan.md`](vscode-extension-plan.md)（VS Code +
> JS 生态方案）。本方案与其共享同一套架构原则（认证统一在本地端口侧、D4
> 零转发、schema 驱动 UI、默认即安全），差异在**宿主形态与移植策略**：
> IDEA 是 JVM 平台，插件运行在 IDE JVM 内，天然适合**核心纯 Java 内嵌**，
> 无需 Node 运行时。

---

## 0. 结论摘要

1. **推荐架构 = 纯 Java 移植核心 + 插件内嵌（进程内单例），daemon IPC 仅作
   过渡与 CLI 等价物**。与 VS Code 方案不同：VS Code 宿主自带 Node 20.19+ 可
   直接内嵌 npm 库；IDEA 插件运行在 JBR（JetBrains Runtime，JDK 21 系）内，
   系统不保证有 Node——所以**核心必须 Java 化**才能获得与库模式同等的 UX。
2. **Java 移植比 Node 版更顺手**：JDK 17+ 原生提供 Node 版要拼凑的多数能力——
   `ProcessHandle`（跨平台进程树，替代 Linux /proc + macOS ps + Windows
   PowerShell 三套实现）、`java.net.http.HttpClient`（HTTP/2 下载）、
   `java.util.zip` + gzip（zip/gz 解压）、`UnixDomainSocketAddress`
   （daemon IPC unix socket）、`javax.crypto`（HMAC/RSA-OAEP/TOTP 全有）。
   需要外带的只有：JSON（Gson 或手写极简解析器）、scrypt/APR1 口令散列
   （JDK 无 scrypt；APR1 是 80 行公开算法，可手写或换 BouncyCastle）、
   tar.gz 解压（commons-compress 或自实现 tar reader）。
3. **外部二进制与隧道工具不移植、不改**：nginx / Authelia / redis / ngrok /
   frpc / cloudflared / bore 等都是外部可执行文件，Java 侧只做"解析 + 生成配置 +
   进程管理 + 输出解析"，与原设计完全一致（design.md §4）。隧道永远是纯透传，
   认证统一在本地网关端口侧。
4. **分阶段落地**：Phase 1 插件 MVP 先走 daemon IPC 桥接（复用现有 Node daemon，
   1 周内出可用的 .zip 插件，验证 UX）→ Phase 2 按依赖顺序把核心移植为 Java
   （discovery → proxy/basic+portal+token → tunnels → gateway/authelia/redis）
   → Phase 3 插件切内嵌、去 Node 依赖。**桥接只是过渡，不是长期形态**。
5. **发布受 AGENTS.md 约束**：内部阶段仅内网分发（本地仓库/内部市场），上
   JetBrains Marketplace 前必须完成 service-tunnels 公共 npm 迁移清洗
   （promotion-plan.md），插件依赖、文档、示例全部去内部化。
6. **IDEA 特有加分项**（相对 VS Code）：运行配置（Run Configuration）启的
   dev server 是 IDE JVM 后代，`ProcessHandle.descendants()` 直接发现；集成
   终端的 shell 也是 IDE 进程后代（PTY 由 IDE JVM spawn）——**端口发现覆盖
   度天然高于 VS Code**；插件可挂钩 Run Configuration 生命周期自动提示暴露/
   回收。

---

## 1. 定位与用户故事

**一句话**：在 IntelliJ IDEA 里对任何本地端口执行"暴露"（tunnel / proxy /
both），拿到公网 URL，自动带认证，停止/清理一键完成；核心逻辑是 Java 库，
不依赖系统 Node。

**核心用户故事**：

| 用户 | 场景 |
|---|---|
| 后端/全栈开发者 | `npm run dev`（IDEA 终端）或 Spring Boot 运行配置起来 → 插件发现端口 → 点一下拿公网 URL 发同事联调/回调调试 |
| 微服务联调 | 多端口各自暴露或走 proxy 固定域名（`8080-api.st.localhost`） |
| 微信/支付宝回调调试 | ngrok/natapp 公网 HTTPS URL 填回调配置收 webhook |
| 教学/演示 | 临时暴露演示站，结束一键收回 |
| 团队共享 | portal/basic 认证 + 用户管理，同事用自己的账号进 |
| CI/脚本 | `auth token`（Bearer header）机器访问，无登录页 |

**非目标（v1 前）**：不做托管账号体系；不做团队协作后台；不接管用户已有
nginx/Authelia 部署（用库自动拉起即可）。

---

## 2. 架构选型

### 2.1 三种接入方式对比

| 方式 | 形态 | 优点 | 缺点 |
|---|---|---|---|
| **A. 纯 Java 内嵌** | 把核心移植为 Java 库，插件进程内 `ServiceTunnels.create()` 单例 | 无 Node 依赖；discovery/事件/清理最佳 UX；JBR 自带 JDK 全能力 | 移植工作量大（~20 模块）；需维护 TS/Java 双实现 |
| **B. daemon IPC 桥接** | 插件做薄 Java 客户端，连现有 Node daemon JSON-RPC（L3 层，见 vscode-extension-plan §7.2） | 实现最薄（~100 行客户端 + 表单）；复用现成 daemon | **依赖系统 Node**（IDEA 不保证有）；UX 靠轮询；与"Java 移植"目标背离 |
| **C. CLI 侧车** | 插件 spawn `sts daemon start` + 每次 `sts ...` 命令 | 最薄；CLI 已存在 | 每操作一次子进程；状态同步难；同样依赖 Node 安装 |

### 2.2 推荐：A 为最终形态，B 为过渡（分阶段切换）

```
Phase 1（过渡）：┌────────── IDEA 插件（JVM）──────────┐
                 │  Java 客户端 ←─ JSON-RPC ─→ Node daemon │
                 └────────────────────────────────────┘
                          （复用现有 daemon，1 周出 MVP）

Phase 2→3（最终）：┌────────── IDEA 插件（JVM）──────────┐
                 │  ServiceTunnelsCore（Java 移植核心）   │
                 │  discovery/proxy/tunnels/providers    │
                 │  内嵌单例，辅助进程为插件后代           │
                 └────────────────────────────────────┘
```

- 两个阶段暴露**相同的最小接口集**（§4.4），上层 UI 不感知差异；
- Phase 1 的桥接客户端、schema 表单渲染、UI 骨架在 Phase 3 原样复用，不浪费；
- daemon 模式保留为**可选**（CLI 等价物 / 外部工具接入 L3 层），但插件默认
  不再依赖它。

---

## 3. Java 移植核心（ServiceTunnelsCore）

### 3.1 模块映射

| TS 模块（src/） | Java 类 | 实现要点（JDK 能力） |
|---|---|---|
| `config.ts` | `Config` | 目录解析（XDG）、config.json 读写（0600）、环境变量优先级 |
| `discovery.ts` | `Discovery` | **`ProcessHandle.allProcesses()` / `descendants()` 跨平台进程树**；端口→PID 仍需平台探测（Linux `/proc/net/tcp{,6}`、macOS `lsof`、Windows `netstat -ano`，沿用原解析函数 `decodeIpv4/decodeIpv6/parseLsofAddress/parseNetstatAddress`）；`SERVICE_TUNNELS_ROLE` 环境标记排除辅助进程；5s TTL 缓存 |
| `marker.ts` / `pid-registry.ts` | `Marker` / `PidRegistry` | 环境常量 + 注册文件 JSON |
| `proxy.ts` / `proxy-manager.ts` | `ProxyServer` / `ProxyManager` | 见 §5.2（HTTP 服务器 + WS upgrade + D4 enrollment） |
| `internal.ts` | `InternalRegistry` | 内存 + state.json 端口注册表 |
| `validation.ts` | `Validation` | 全量移植（fail-closed；ssh 选项注入 / frpc INI 注入 / 路径穿越 / 控制字符） |
| `tunnels.ts` | `TunnelManager` | `ProcessBuilder`（env 注入、单 argv、不 shell）；输出缓冲 + URL 正则解析（ngrok-free.app / trycloudflare.com / loca.lt / serveo.net… + 首 URL 兜底）；`cloudflaredNeedsEdge` SRV 探测 → `JNDI-DNS`（`com.sun.jndi.dns`）或解析失败时固定 `--edge` 参数 |
| `tunnels-config.ts` / `tunnels-custom.ts` | `TunnelConfigStore` / `CustomTunnelRegistry` | JSON 存储；env `SERVICE_TUNNELS_TUNNEL_COMMAND_*` 注册扩展点 + 单引号惰性转义 |
| `tools.ts` | `ToolResolver` | PATH > 缓存 > 下载；`java.net.http.HttpClient`（HTTP/2、重定向、镜像回退 ghproxy/npmmirror）；zip（`java.util.zip`）、**tar.gz 需外带**（§5.4）；魔数探测；原子 rename |
| `gateway.ts` | `NginxGateway` | nginx 配置生成 + `-t` 预校验 + `-s reload` + 失败回滚；进程管理（角色标记、退出清理） |
| `authelia.ts` | `AutheliaProvider` | 配置生成（base path、SQLite、file 用户库、NTP 禁用）+ `config validate` + 动态登记（config-tunnels.yml 原子重写 + 重启） |
| `redis.ts` | `RedisController` | spawn `redis-server --bind 127.0.0.1 --port <随机>`，永远单实例 |
| `providers/basic.ts` | `BasicProvider` | **APR1 md5-crypt 手写实现**（~80 行，公开算法，nginx `auth_basic` 兼容）；进程内校验，不 spawn openssl |
| `providers/portal.ts` | `PortalProvider` | `com.sun.net.httpserver` 实现 forward-auth 门户（authz 探针 / 登录页 / 会话 cookie）；**RSA-OAEP SHA-256 一次性密钥对**（`KeyPairGenerator` 2048 + `Cipher` RSA/ECB/OAEPWithSHA-256AndMGF1Padding + 5min TTL，与 WebCrypto `crypto.subtle` 互通）；HMAC-SHA256 签名 cookie + `MessageDigest.isEqual`（timingSafeEqual）；IP 限速；**scrypt 需外带**（§5.5） |
| `providers/token.ts` | `TokenProvider` | `SecureRandom` token 生成（`st_xxx`）+ 只存 SHA-256 哈希 + 过期 |
| `providers/oauth2-proxy.ts` / `oauth2-variants.ts` | `OAuth2Provider` | HTTP 编排（`HttpClient`）+ 配置生成；变体从配置档 `oauth2.variants` 动态注册 |
| `auth-registry.ts` / `auth-provider.ts` | `AuthRegistry` / `AuthProvider`（接口） | 注册表 + `capabilities` 自描述 + 插件扩展点（`ServiceLoader`，等价 TS 插件目录/`authPlugins`） |
| `sites.ts` | `SiteStore` | sites.json（0600），独立认证域实例 |
| `state.ts` | `StateStore` | 原子写（temp + rename）、无 secret |
| `daemon.ts` / `daemon-server.ts` | `DaemonServer` | **`java.net.UnixDomainSocketAddress` 原生 unix socket**（Windows 退 TCP + `x-service-tunnels-auth` secret 头）；newline JSON-RPC；`dangerous: true` 门禁 |
| `guardian.ts` / `guardian-spawn.ts` | `Guardian` | `ProcessHandle` 父进程存活探测 + 低频扫描回收孤儿辅助进程 |
| `i18n.ts` | `I18n` | `ResourceBundle`（zh/en）+ schema 文案本地化 |
| `ui.ts` | —— | Web UI 不移植（IDEA 插件用平台 UI 替代）；如需可在插件内嵌 HTTP 管理页（v2） |

### 3.2 移植原则

1. **行为等价优先于结构等价**：安全语义（fail-closed、白名单、0600）、URL 解析
   规则、认证协议（forward-auth / RSA-OAEP / APR1 / TOTP / Bearer）、虚拟主机
   语法（`<port>[-<label>].<suffix>`）必须逐字节对齐；内部结构可按 Java 习惯重写。
2. **零/极低依赖**：优先 JDK 内置；确需外带的集中在 §5.4 一张表，且只进
   `ServiceTunnelsCore` 一个模块，插件 UI 层不引第三方。
3. **共享代码位**：TS 与 Java 双实现不可避免，但**外部契约冻结**——state.json
   结构、daemon RPC 方法名/字段、schema JSON 字段、tunnels.json/config.json
   格式（§3.4）——保证 TS 版 CLI/daemon 与 Java 核心可互操作（Phase 1 桥接
   期间同读一份 state）。
4. **单测对齐**：TS 版 `test/*.test.mjs` 的语义迁移为 JUnit 5（参数化用例直接
   搬：URL 解析、APR1 向量、TOTP 向量、校验拒绝矩阵、vhost 解析、目标 URL 无
   authority 覆盖）。

### 3.3 Java 版本与 JBR

- 目标 JDK **21**（对应 JBR 21，IDEA 2024.x 自带；插件最低兼容 Java 17 编译
  产物，用 `--release 17` 交叉编译，`UnixDomainSocketAddress` 等 16+ API 需
  `--release 17` 不支持 → 桥接/daemon 相关类单独以 21 编译，或最低平台抬到
  IDEA 2024.1+（JBR 21））。建议**直接要求 IDEA 2024.1+ / JBR 21**，少一个
  兼容维度。
- 插件模块用 IntelliJ Platform Gradle Plugin（`org.jetbrains.intellij.platform`），
  纯 Java（用户要求 Java 实现；不引入 Kotlin，避免双语言心智负担）。

### 3.4 外部契约冻结（TS↔Java 互操作清单）

| 契约 | 位置 | 说明 |
|---|---|---|
| 目录布局 | `config.json`/`tunnels.json`/`sites.json`/`users.yml`/`state.json`/`daemon.sock` | 与 design.md §2 完全一致；Java 版读写同一布局（0600） |
| state.json 字段 | `tunnels[]`、`bindings[]`、`internalPorts`、`ipcPath`/`ipcSecret` | 桥接期 Node daemon 写、Java 客户端读 |
| daemon RPC 方法 | `tunnel.*`/`expose`/`proxy.*`/`auth.user.*`/`auth.token.*`/`auth.totp.*`/`internal.list`/`config.*`/`schemas` | 见 vscode-extension-plan §7.2；冻结后客户端不因库升级而碎 |
| schema JSON | `tunnelParamSchemas` / `authProviderSchemas` 字段 | schema 驱动表单的数据源；冻结字段名（对齐 promotion-plan 的 API 冻结） |
| 协议细节 | forward-auth 探针路径、RSA-OAEP 密文格式、APR1 哈希格式、TOTP Base32/步长、`ST_TUNNEL_URL:` 输出标记 | 逐条对齐，双实现互测 |

---

## 4. IDEA 插件层设计

### 4.1 定位（相对 VS Code 方案）

| 维度 | VS Code 扩展 | IDEA 插件（本方案） |
|---|---|---|
| 宿主运行时 | 扩展宿主 Node ≥20.19（VS Code 自带） | **插件在 IDE JVM（JBR 21）内**，无需 Node |
| 核心接入 | 内嵌 npm 库（ESM 打包是最大风险） | 内嵌 Java 核心库（无打包风险，天然同 JVM） |
| 端口发现 | 三层：discovery rootPid + 常见端口探测 + 手动（**集成终端进程不在宿主树下**） | `ProcessHandle.current().descendants()`：**IDEA 终端 shell 与运行配置子进程都是 IDE 后代** → 覆盖度高得多；外部终端启动的服务仍走探测+手动兜底 |
| 状态持久 | 无（库内内存 + state.json） | 同：内嵌核心 + state.json |
| UI 技术 | StatusBar / TreeView / webview | Tool Window（Swing 树表）/ StatusBar widget / Actions / Settings 页 |

### 4.2 功能规划

#### MVP（v0.1）

**Actions（主菜单 / 右键 / 快捷）**：

| 命令 | 行为 |
|---|---|
| `Service Tunnels: Expose Port…` | 端口选择（发现结果 + 常见端口 + 手动输入）→ 隧道类型（默认按平台：cloudflared 零账号 / natapp CN / ngrok）→ 认证（默认 auto）→ 暴露 |
| `Service Tunnels: Stop Exposure` | 列出当前暴露项，停止并清理 |
| `Service Tunnels: Open in Browser` | 打开公网 URL |
| `Service Tunnels: Copy URL` | 复制到剪贴板 |

**UI 元素**：
- **Tool Window「Service Tunnels」**：暴露列表（端口/label/隧道类型/URL/认证
  provider/状态），双击 URL 打开浏览器，右键菜单（打开/复制/停止/日志）；
  顶部工具栏：Expose / Stop / Refresh。
- **StatusBar widget**：暴露后显示 `🌐 <域名>`（点击打开菜单：打开/复制/停止）；
  无暴露显示 `🌐 未暴露`。
- **输出视图**（console 工具窗口 tab）：隧道启动日志、URL、错误（`runProcessWithConsole`）。
- **Settings 页**（`PersistentStateComponent`）：configDir / cacheDir / 默认隧道
  类型 / 默认认证模式 / `preferMirrors` / `allowToolDownload` / 端口探测列表 /
  `allowAuthNone` 开关（安全粘性）。
- **首次运行向导**：创建初始用户（portal/basic/authelia），随机密码一次性展示
  + 复制按钮（对齐 `st.auth.addUser` 语义）。

**生命周期**：
- `projectOpened` → `ServiceTunnelsCore.init()`（单例，按项目隔离 configDir/site）
  + 恢复 state.json 存活隧道 + 订阅事件（`tunnel:url`/`tunnel:stop` 刷新 UI）；
- `projectClosed` / 插件 `dispose` → `shutdown()`（清理全部子进程；guardian
  兜底 IDE 崩溃场景）；
- 每次暴露默认 `--auth auto`，不允许裸奔（联动 `allowAuthNone` 粘性开关）。

**验收标准**：IDEA 终端 `npm run dev` → 插件自动发现 5173 → 一条命令拿到带认证
公网 URL → 停止后本地/公网入口都回收 → 关闭项目无残留进程。

#### v1（Phase 3 完成后）

- **Run Configuration 集成**：当前运行配置启动的服务自动出现在"可暴露"列表；
  服务停止（run 配置结束）自动回收暴露。
- **认证管理页**（Tool Window 内 tab）：用户增删/改密、TOTP 2FA 开关、
  Bearer token 管理（CI 机器访问）。
- **schema 驱动表单**：读 `schemas` JSON 动态渲染隧道参数/provider 参数表单
  （`--set`/`--provider-set` 语义）——新隧道类型/新 provider/env 自定义隧道
  自动出现，插件零改动。
- **多隧道并存 / 多项目隔离**：一次暴露多端口；`--mode both`/`--mode proxy`；
  每个 IDEA 项目独立 site（认证域），用户库互不共享。
- **暴露中提示**：URL 已公开的状态显著显示（"已公开"徽标），一键收回。

#### v2（待定）

- 本地端口转发面板（内置转发器，无外部二进制场景）；`expose` 二维码
  （手机扫码演示）；配置文件驱动（`.service-tunnels.json` 项目级默认）。
- Tool Window 内嵌管理页（把 `sts ui` 核心页搬进插件，复用 schema 渲染）。

### 4.3 端口发现（IDEA 具体实现）

```
1. ProcessHandle.current().descendants()          // IDE JVM 后代：终端 shell、run 配置、debug 子进程
   + /proc (Linux) / lsof (macOS) / netstat (Win) 解析监听端口
   + SERVICE_TUNNELS_ROLE 标记排除插件自拉起的辅助进程
2. 常见开发端口探测兜底（5173/4173/3000/8080/4200/9000…），只探测
   127.0.0.1 上确实监听且非框架端口（复用 isServicePortAllowed 语义）
3. 手动输入（默认表单项，覆盖一切边缘情况）
+ Run Configuration 联动：运行中的 run 配置 → 其端口直接进列表（IDEA 特有）
```

### 4.4 最小接口集（内嵌/桥接双形态一致，对齐 vscode 方案 §4.4）

```
discover()                              → ServicePortInfo[]
expose(port, { mode, tunnelType, auth, site?, tunnelParams?, providerParams? })
                                        → { url, loginUrl, tunnel, provider }
stop(port) / listExposes()
authUserAdd(name, password?, site?)     → { password(首次随机), providers }
authTokenCreate(description, expires?)  → { token }
tunnelList() / tunnelStop(name)
events: tunnel:url / tunnel:stop / expose:error
```

---

## 5. 关键技术点

### 5.1 JSON

- JDK 无内置 JSON。两个选择：
  - **手写极简 JSON parser**（~300 行，值类型 + 递归下降）——对齐零依赖精神；
    配置/state/schema 都是小文档，风险可控；**推荐 v1 前先做**（也是 Phase 0
    spike 之一）。
  - Gson（~1.2MB，零传递依赖）——省心但破"零依赖"。
- 倾向：核心库用**手写 parser**（保持零依赖声明），若 spike 发现 schema 文档
  复杂度超预期（深嵌套 + unicode 转义）再降级 Gson（单依赖，可接受）。

### 5.2 HTTP 服务器（proxy 核心，最大的技术选型点）

需求：泛域名反向代理（流式透传 SSE ✓）+ **WebSocket upgrade 转发**（Vite HMR
走 WS，proxy 模式必须支持）+ 请求头/路径原样透传。

| 方案 | 优点 | 缺点 |
|---|---|---|
| `com.sun.net.httpserver` | JDK 内置零依赖；流式 OK | 官方 API 不暴露 upgrade；并发模型一般 |
| Netty | 全能、WS 一等公民 | ~6MB 依赖，破零依赖原则 |
| **JDK HttpServer 常规请求 + 手写 upgrade 泵**（推荐） | 零依赖；upgrade 只对含 `Upgrade: websocket` 头的连接生效，用独立 `ServerSocket` 监听同端口？——不行，端口已被 HttpServer 占用 | **同端口双监听不可行**，需换方案 ↓ |
| **自研极简 HTTP/1.1 服务器**（推荐替代） | 零依赖；HTTP + upgrade + 流式全自控；~600-900 行（请求行/头解析 + 转发 + upgrade 双向泵） | 要自己处理：keep-alive、chunked、超时、慢请求防护；成熟度需大量单测 |

**建议**：v1（MVP）先用 `com.sun.net.httpserver` 支持 HTTP 透传（覆盖
webhook/回调/演示 90% 场景），WS upgrade 标记为「不支持，提示走 tunnel 模式
（nginx 网关天然支持 WS）」；Phase 3 视反馈决定是否自研极简服务器补 upgrade。
决策记录进 Phase 0 spike 结论。

### 5.3 进程发现与进程管理

- 进程树：`ProcessHandle.allProcesses()`（全系统）或 `descendants()`（子树）；
  `ProcessHandle.Info.commandLine()` 取 cmdline——Node 版三平台拼凑，Java 版
  一个 API。
- 端口→PID：平台探测沿用原实现（Linux `/proc/net/tcp{,6}` LISTEN 表 + fd
  inode 关联、macOS `lsof -nP -iTCP -sTCP:LISTEN`、Windows
  `netstat -ano` + 任务名），解析函数逐行迁移 + 单测。
- spawn：`ProcessBuilder`（env 注入 `SERVICE_TUNNELS_ROLE`、单 argv 参数、
  `redirectErrorStream` + 异步读取缓冲输出、`destroy()`/`destroyForcibly()` +
  进程组清理）。**永不 shell**（除 `command` 类型经 daemon 显式
  `dangerous: true`）。

### 5.4 需要外带的库（唯一清单）

| 能力 | 选项 | 说明 |
|---|---|---|
| scrypt 口令散列 | **BouncyCastle**（`SCrypt` 类）或自实现（公开算法 ~150 行） | portal 用户库用 `scrypt(password, salt16, 64B)`，与 node:crypto 逐字节对齐（N/r/p 参数从原实现提取固化） |
| APR1 md5-crypt | 自实现（~80 行公开算法） | nginx `auth_basic` 兼容；**不 spawn openssl**（原实现 spawn 是偷懒，Java 直接进程内算） |
| tar.gz 解压 | commons-compress（单一、纯 Java）或自实现 tar reader（~200 行） | tools.ts 下载 authelia/nginx 官方 tar.gz 需要；zip 用 JDK 内置 |
| JSON | 手写 parser（推荐）或 Gson | 见 §5.1 |

> 若坚持零依赖：scrypt + APR1 + tar + JSON 四个自实现合计 ~800 行有测试保障
> 的代码，是可行的（都是公开/标准化算法）。决策倾向：**JSON 与 APR1 自写
> （简单），scrypt 与 tar 用 BouncyCastle + commons-compress（成熟安全）**——
> 两依赖、纯 Java、无传递链，仍远低于生态平均。

### 5.5 密码学对照（双实现逐项对齐）

| 能力 | TS（node:crypto） | Java |
|---|---|---|
| portal 口令散列 | scrypt（16B salt / 64B key） | BouncyCastle `SCrypt`（参数对齐） |
| 会话 cookie 签名 | HMAC-SHA256 + `timingSafeEqual` | `Mac HmacSHA256` + `MessageDigest.isEqual` |
| 登录密码传输 | RSA-OAEP SHA-256（一次性密钥对，5min TTL，WebCrypto 前端加密） | `KeyPairGenerator(2048)` + `Cipher "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"`，SPKI DER Base64 输出与 WebCrypto `importKey` 互通 |
| TOTP 2FA | RFC 6238 SHA-1 / 6 位 / 30s / ±1 窗口（自实现，含 Base32） | `Mac HmacSHA1` + 同款 Base32 解码（对齐向量测试） |
| Bearer token | 随机 secret + SHA-256 哈希存储 | `SecureRandom` + `MessageDigest SHA-256` |
| basic | APR1（spawn openssl） | 进程内 APR1 自实现 |
| ssh host key | RSA 2048 生成（ssh/domain.ts） | `KeyPairGenerator` + PEM 序列化（可复用 JSch 免依赖的纯生成） |

### 5.6 安全设计（默认即安全，对齐原方案）

- 暴露默认 `auth: "auto"`；`none` 需确认弹窗；`allowAuthNone` 粘性开关三层
  生效（插件设置 < 环境变量 < 配置文件）。
- 透传隧道永远只指向本地网关端口（127.0.0.1 白名单 + D4 零转发），未 enroll
  端口公网不可达。
- configDir/cacheDir 0600；portal 登录 RSA-OAEP + IP 限速防爆破；token 只在
  创建时显示一次、库内只存哈希。
- **无遥测**；输出视图日志用户可控。
- 暴露 URL 公网可见——UI 显著"已公开"提示 + 一键收回。
- 校验矩阵（validation.ts）全量移植，双入口（内嵌 API + daemon RPC）fail-closed。

### 5.7 多语言

- 核心 i18n 用 `ResourceBundle`（zh/en），schema 文案本地化逻辑与 TS
  `localizeSchemas` 对齐；插件 UI 文案复用核心资源。

---

## 6. 打包与发布

### 6.1 仓库形态

- 建议**同仓子目录**：`extensions/idea/`（独立 Gradle 工程，`settings.gradle.kts`
  不并入根 npm 工程；CI 分离 job）。
- 核心 Java 库独立模块 `extensions/idea/service-tunnels-core`（纯 Java，只依赖
  §5.4 两个库），插件模块依赖它——为将来"Java 版 CLI/daemon"或第三方 JVM 宿主
  复用留口。

### 6.2 构建

- `./gradlew buildPlugin` → `build/distributions/*.zip`；`intellij.platform`
  plugin DSL；`java { toolchain { languageVersion = 21 } }`；
  `sinceBuild 241.*`（IDEA 2024.1+）。
- CI：GitHub Actions 构建 .zip artifact；内部阶段手动安装（`Install Plugin from
  Disk…`）；公共阶段 JetBrains Marketplace 上传。

### 6.3 内部 → 公共（AGENTS.md 硬约束）

| 阶段 | 依赖 | 分发 |
|---|---|---|
| 内部 | service-tunnels 内网镜像（npm.alot.pw 或 file: 引用）；插件 .zip 内部安装 | 内部试用，不走 Marketplace |
| 公共（阻塞项） | 先完成 service-tunnels 公共 npm 迁移清洗（promotion-plan.md）→ 插件清理内部域名/端口/路径/宿主名（泛化为 "embedder"） | JetBrains Marketplace |

- 插件 README/截图/示例代码发布前走与 npm 包相同的**清洗 checklist**（AGENTS.md
  §发布策略）：无 `alot.pw`/`pi.alot.pw`、无内部端口号、无 `/home/wind` 路径。
- 版本策略跟随 service-tunnels 发布节奏；schema 冻结（promotion-plan 的 API
  冻结）后插件客户端零改动升级。

---

## 7. 里程碑与工作量（单人）

| Phase | 内容 | 工时 | 产出 |
|---|---|---|---|
| **0** | spike：JBR 21 能力验证（ProcessHandle 发现 IDE 终端/run 配置端口、UnixDomainSocket、HttpServer 转发）、JSON parser 可行性、schema 表单渲染验证、daemon IPC 连通性（Node daemon ↔ Java 客户端） | 1 天 | 技术结论 + 决策记录（HTTP 服务器选型、依赖清单定稿） |
| **1** | 插件骨架 + 桥接 MVP：Actions/Tool Window/StatusBar/输出视图/设置页 + Java daemon 客户端（expose/stop/open/copy）+ 端口三层获取（先 ProcessHandle 后探测+手动） | 3-5 天 | 可安装 .zip，内部试用（依赖系统 Node） |
| **2** | Java 核心移植（顺序：config/discovery/validation/state → proxy/basic+token+portal → tunnels（cloudflared/bore/ssh/command 先行，ngrok/frpc/natapp 后）→ tools → sites/internal/i18n → gateway/authelia/redis → guardian/daemon） | 2-3 周 | `service-tunnels-core` 纯 Java 库 + JUnit 单测（对齐 TS 用例） |
| **3** | 插件切内嵌 + v1 功能：Run Configuration 联动、认证管理页（用户/2FA/token）、schema 动态表单、多隧道/多项目 site、首次运行向导 | 1-2 周 | 无 Node 依赖的功能完整 v1 |
| **4** | 发布：公共 npm 迁移（前置阻塞项）→ Marketplace 上架、README/截图/SECURITY、CI 构建、清洗 checklist | 2 天（不含迁移） | 公共市场 v1.0 |
| **5** | v2 前瞻：本地转发面板、二维码、内嵌管理页、WS upgrade（视反馈） | 待定 | 后续迭代 |

**合计：桥接 MVP 约 1 周，Java 核心 2-3 周，插件 v1 约 2 周，生态/发布另计。**

---

## 8. 风险与开放问题

| # | 风险 | 影响 | 对策 |
|---|---|---|---|
| 1 | 系统无 Node（桥接阶段） | 插件不可用 | 桥接仅过渡；插件检测 Node（含 nodejs 插件自带 JBR Node 的探测）失败即提示装 Node 或用 Vite/内置方案；Phase 3 彻底消除 |
| 2 | HTTP/WS 服务器选型 | proxy 模式 WS 转发缺失 | v1 用 JDK HttpServer（HTTP-only），WS 走 tunnel 模式（nginx 网关）；Phase 3 评估自研极简服务器（§5.2） |
| 3 | scrypt/APR1/tar 双实现漂移 | 用户库不互通（TS CLI 与 Java 插件各写各的 users.json） | 外部契约冻结 + 向量单测互测（§3.4）；scrypt/APR1 参数与格式逐字节对齐 |
| 4 | 双实现维护成本 | TS/Java 两套核心 | 外部契约冻结降低互操作风险；schema/协议冻结后 TS 演进不影响 Java；长期考虑：TS 版稳定后冻结，Java 版为主要新功能载体 |
| 5 | 公共 npm 未迁移（AGENTS.md 硬阻塞） | 无法上 Marketplace | 先内部 .zip 试用；公共发布列入 Phase 4 前置项，勿跳步 |
| 6 | 暴露公网 = 安全暴露面 | 用户数据风险 | 认证默认开、D4 零转发、显著"已公开"提示、一键收回、无遥测（§5.6） |
| 7 | 二进制工具被安全软件误报（frpc 等） | 用户体验 | 沿用 design.md §8.1 声明；下载前确认；可用 cloudflared 等零风险替代 |
| 8 | IDEA 版本矩阵（2024.1 vs 2025.x API 变动） | 构建/兼容 | 最低平台定 2024.1+（JBR 21）；CI 跑两个目标版本（2024.1 / 最新稳定）验证 |
| 9 | IDEA 终端 PTY 进程树可靠性 | 发现漏端口 | 三层端口获取 + Run Configuration 联动（§4.3）；外部终端场景走探测+手动 |

**开放问题（需 spike/评审确认）**：
- JBR 21 上 `ProcessHandle.descendants()` 对 IDEA 集成终端 shell 的覆盖度实测
  （PTY 进程是否挂在 IDE JVM 树下；Windows 上尤其要验证）；
- `com.sun.net.httpserver` 在长连接/并发场景（HMR WebSocket 之外的 SSE、大文件
  上传）的稳定性——决定是否需要自研极简服务器；
- portal RSA-OAEP 双实现（WebCrypto ↔ Java Cipher）的密文互通验证（OAEP 标签、
  MGF1 参数默认值需对齐）；
- 插件与 CLI daemon 并存时 state.json 写冲突（建议插件内嵌模式使用**独立
  configDir/cacheDir**，不与用户自己跑的 CLI daemon 共享——与 vscode 方案
  开放问题 3 同一结论）；
- 是否在 Phase 2 顺带产出 **Java 版 CLI**（`java -jar service-tunnels.jar`）与
  独立 daemon——让 Java 核心成为 L3 层的第二个实现，供非 IDEA 的 JVM 宿主复用。

---

## 9. 参考

- [`docs/design.md`](design.md) — 架构 / 模块 / 认证 provider 模型 / 平台矩阵（移植的权威依据）
- [`docs/sites-design.md`](sites-design.md) — 站点（认证域）隔离 + proxy 暴露模式
- [`docs/vscode-extension-plan.md`](vscode-extension-plan.md) — 姊妹方案（L3 daemon IPC 协议、最小接口集、schema 冻结）
- [`docs/token-auth-design.md`](token-auth-design.md) — Bearer token 认证方案
- [`docs/input-validation-security.md`](input-validation-security.md) — 校验矩阵（全量移植）
- [`docs/promotion-plan.md`](promotion-plan.md) — 公共发布前置（AGENTS.md 阻塞项）
- [`src/providers/portal.ts`](../src/providers/portal.ts) — RSA-OAEP / scrypt / TOTP / HMAC 参照实现
- [`src/providers/basic.ts`](../src/providers/basic.ts) — APR1 参照实现
