# expose 功能横向调研与快速适配计划

> **总览/执行摘要见 [expose-research-summary.md](expose-research-summary.md)**；
> P0 双底座详细设计见 [p0-dual-base-design.md](p0-dual-base-design.md)。

> 调研日期：2026-08-07
> 方法：源码级核查（opencode / pi-web / service-tunnels 本地代码；PiClaw 经 GitHub raw + tree API）+ 官方文档 + npm/GitHub 实测。
> 一句话结论：**service-tunnels 的 "隧道 × 认证 × 发现 × 嵌入" 组合已是本赛道最完整的 expose 实现**；本计划回答"哪些外部软件的 expose 功能我们能快速吸收"——按架构契合度分级为 **S（半天）/ A（1-2 天）/ B（2-5 天）/ C（5 天+）** 四档，共 16 项，前两档 10 项全部是"纯配置/命令级 + 新 provider + 语义映射"，不触碰现有安全模型。

---

## 1. 调研对象与方法

| 对象 | 核查方式 | 关键发现 |
|---|---|---|
| pi-web（agegr / windli fork） | 本地代码 `lib/service-tunnels-integration.ts`、`proxy.ts`、`docs/service-port-proxy.md` | 已深度集成 service-tunnels（见 §3.1） |
| OpenCode（anomalyco/opencode） | 克隆源码 `packages/opencode/src/share/share-next.ts`、`server/auth.ts`、`docs/*` | `/share` 是**会话分享**（云端），**无端口隧道**；`serve` 有可选密码认证（见 §3.2） |
| PiClaw（rcarmo/piclaw） | GitHub raw：`README.md`、`docs/reverse-proxy.md`、`docs/configuration.md`、tree API 定位 VNC 源码 | VNC 查看器（websocket-tcp-bridge）+ 终端 + **trust-proxy 头信任**；无隧道（期待前置反代/隧道）（见 §3.3） |
| VS Code / Cursor | 官方文档 Port Forwarding / Dev Tunnels + 论坛 | devtunnel CLI（GitHub/MS 登录），端口可见性 Private/Public（见 §3.4） |
| GitHub Codespaces | 官方文档 | 端口可见性三态 Private/Org/Public + `gh cs ports`（见 §3.5） |
| Claude Code | 官方文档 | Desktop Preview 面板（**本地** http://localhost:port，无公网隧道）（见 §3.6） |
| aider / OpenHands / Cline / Codex | 文档 + issue | 几乎无端口 expose；OpenHands issue #6183 还在**申请**原生端口转发（见 §3.7） |
| 隧道工具生态 | 官方文档/命令实测 | pinggy / localhost.run / hop.to（ssh 免安装）、zrok（开源 + 公/私双模 + TCP/UDP）、devtunnel、tailscale serve/funnel、tunnelmole（见 §3.8） |

---

## 2. 现状基线（service-tunnels + pi-web 已有能力）

已实现、本计划**不改动**的部分：

- **隧道 provider × 9**：ngrok / frpc / ssh / serveo / cloudflared / localtunnel / bore / natapp / command（`src/tunnels.ts`，schema 驱动，`TUNNEL_PARAM_SCHEMAS`）。
- **认证 provider × 5**：portal / basic / authelia / oauth2-proxy / token + TOTP 2FA + 站点隔离（site = 独立用户库/域名/策略）。
- **暴露模式**：`mode ∈ {tunnel, proxy, both}` × `auth ∈ {none, auto, <provider>}` × `protocol ∈ {http, https, tcp}`（`src/expose.ts`）。
- **安全模型**：D4 零转发（未 enroll → 403）、代理目标仅 127.0.0.1、SSRF/原型污染防护、`allow-auth-none` 全局开关、token 过期、防爆破。
- **嵌入方集成**：pi-web ServicesDialog（Ports/Users 双页签、schema 驱动表单、日志、工具下载开关）、Next middleware 进程内 `proxy.resolve()` 单实现。
- **进程模型**：guardian + pid-registry + 角色标记 + state.json 恢复。

**架构红利**（本计划反复利用的关键）：所有 provider 都是"schema → 表单/CLI 参数 → spawn → URL 解析"的数据驱动管线。**新增一个隧道 provider ≈ 改 4 处**：`TunnelType` 联合类型、`TUNNEL_PARAM_SCHEMAS`、`tunnels.ts` 的 args 构建 switch、`extractTunnelUrl` 已知域名正则（+ 可选 `src/tools.ts` 二进制下载条目）。UI/CLI/daemon/文档全部自动生效。

---

## 3. 逐家深挖

### 3.1 pi-web（windli fork，宿主）

**现状（服务端口代理方案文档 D1-D8）**：
- hostname 虚拟主机（`5173.pi.localhost`），不搞 path-prefix——绝对路径/SPA/fetch/WebSocket 天然可用。
- enrollment 白名单：发现（`discovery.getPorts()`）只是候选，expose 才授权。
- 双认证域：pi-web 自身 vs services 子进程，独立用户库。
- basePath 部署（`PI_WEB_BASE_PATH=/dev`）合并进登录路径、转发前剥离。
- tunnel 只暴露服务端口，**绝不 tunnel pi-web 本体**。

**结论**：pi-web 不是"要学的对象"，而是 service-tunnels 的**参考嵌入样板**——opencode / PiClaw 的 expose 需求若要在 pi 生态落地，都应按这个模式适配（进程内调用 `st.proxy.resolve()`，middleware 保留 vhost Host）。

### 3.2 OpenCode（anomalyco/opencode，v1.18.14）

**expose 能力清单**（源码核实）：

| 能力 | 实现 | 与端口 expose 的关系 |
|---|---|---|
| `/share` 会话分享（v1） | `share/share-next.ts`：POST `/api/share` 到 `opncd.ai`（或企业 console），增量同步 session/message/part/diff/model，携带 `secret`，支持 `autoShare`（config `share: auto`）与 `OPENCODE_DISABLE_SHARE` | **不是端口 expose**，是"会话快照公开链接" |
| v2 TUI `/share` | v2 文档明确 "currently only reports that sharing is unavailable"（重建中） | 同上 |
| `opencode serve` | headless HTTP server（OpenAPI），`--hostname/--port` 固定，`OPENCODE_SERVER_PASSWORD` 可选 basic 认证（`server/auth.ts`） | "暴露 agent 的 HTTP API"，认证 = 单密码 basic |
| `opencode web` | 本地 web app（127.0.0.1 随机端口） | 无公网 |
| **端口隧道 / 端口转发** | **不存在** | — |

**可借鉴点**：
1. **daemon 远程监听 + 用户认证**（对标 `OPENCODE_SERVER_PASSWORD`）：service-tunnels 的 daemon `daemon-server.ts` 已有 IPC 认证但只面向本地（POSIX 0600 unix socket；Windows 127.0.0.1 + 随机 secret）。加一个可选的 `--listen 0.0.0.0` 远程模式 + 复用现有 basic/token provider 的用户认证 = 小改动，让远程浏览器/CLI 管理 daemon 成为可能（对标 opencode serve 的单密码 basic 认证）。
2. **会话分享的机制**（secret + 增量同步）→ pi-web 做"分享会话快照链接"时可参考：一次性 secret、过期、可撤销。service-tunnels 侧只需要"静态快照托管 + 过期 token 放行"（token provider 已有 `expiresAt`）。

### 3.3 PiClaw（rcarmo/piclaw）

**expose 能力清单**（官方文档核实）：

| 能力 | 实现 | 要点 |
|---|---|---|
| **VNC 查看器** | `runtime/src/channels/web/vnc/vnc-session-service.ts` + `websocket-tcp-bridge.ts`（WS→TCP 桥）+ web 端 `vnc-pane.ts` | 白名单 `PICLAW_WEB_VNC_TARGETS`（JSON allowlist）+ 运行时直连开关 `PICLAW_WEB_VNC_ALLOW_DIRECT` |
| **web 终端** | `terminal-session-service.ts`（node-pty） | 认证后 pane |
| **trust-proxy 头信任** | `PICLAW_TRUST_PROXY=1`；解析 `X-Forwarded-Proto/Host/Port/For/X-Real-IP`；记录浏览器 origin 用于生成绝对链接 | 反代/隧道后置部署的标配（Cloudflare Tunnel 示例） |
| 认证 | Passkey/TOTP | 与 service-tunnels TOTP 同级 |
| **公网隧道** | **无**——文档要求自己挂 Cloudflare Tunnel / Caddy / nginx | "纯本地 + 前置反代"路线 |

**可借鉴点**：
1. **trust-proxy 语义**：确认 service-tunnels 的 proxy/gateway 对 `X-Forwarded-*` 的处理并文档化（PiClaw 的 `PICLAW_TRUST_PROXY` 是一个清晰的对外开关语义）。**注意**：service-tunnels 有 DNS-rebinding 防护（X-Forwarded-Host 校验），trust-proxy 必须带白名单，不能无脑信头——这是我们的安全底线，PiClaw 反而没有这层。
2. **VNC 查看器**：是 **pi-web 层**功能（浏览器 UI），不是库功能。pi-web 的 ServicesDialog 若给每个 TCP 暴露加"打开 VNC 面板"，需引入 noVNC 类依赖——C 级。
3. **add-ons（Proxmox/Portainer/Windows 桌面自动化）**：与 expose 无关，不做。

### 3.4 VS Code / Cursor（dev tunnels + Ports）

**expose 能力清单**（官方文档核实）：
- **devtunnel CLI**（microsoft/dev-tunnels）：`devtunnel host -p <port>`（默认 Private，需访问者登录 GitHub/MS）`--allow-anonymous`（Public，免登录）；`--allow-org`（组织）；URL 形如 `https://<port>-<tunnelId>.<region>.devtunnels.ms`；一次浏览器 OAuth 登录（GitHub 或 MS 账号），免费、无需信用卡。
- **Ports 面板**：自动检测终端输出的 URL/端口（"forward a port"一键），可见性右键切换 Private/Public。
- **Cursor 复用同一隧道基础设施**（Ports 面板 = VS Code 移植）。

**可借鉴点**：
1. **新 provider `devtunnel`**（A 级）：与 ngrok 对位但**免费免注册卡**，且可见性语义现成（Public = 匿名、Private = 账号认证）。适配点：TOOLS 条目（官方下载）、`devtunnel user login` 一次性交互（浏览器 OAuth，headless 需文档说明）、`devtunnel host -p <target> [--allow-anonymous]`、URL 正则加 `devtunnels.ms`。注意它默认 Private → 与我们的 `auth none` 正交语义，文档要讲清楚。
2. **自动发现 + 一键转发**（B 级）：VS Code 的"检测到端口 → Ports 视图提示"= service-tunnels `discovery` 已有候选，缺"auto-expose 策略"（如：仅 proxy 模式 + 仅信任的 app 白名单 + 可全局关闭），做成显式 enrollment 的提醒而非自动放行（守住 D4）。

### 3.5 GitHub Codespaces（端口可见性模型）

**expose 能力清单**（官方文档核实）：
- 端口可见性三态：**Private**（仅本人，GitHub 认证）/ **Org**（组织成员）/ **Public**（有 URL 者即可）。
- `gh cs ports` / `gh cs port-forward` 管理；`devcontainer.json` 可声明默认可见性。
- 组织策略可**限制**端口可见性档位（管理面开关）。

**可借鉴点（高价值，语义层）**：
- 把可见性三态**映射**到 service-tunnels 现有 auth 维度：`Public → auth none`、`Private → token/portal（登录）`、`Org → site（组织域，复用 site 隔离）`。expose 增加一个 `visibility` 概念字段（文档 + UI 分组），**机制零新增**，只是给用户一个心智模型 + 默认值策略（如默认 Private）。B 级中的最轻量项。
- "管理面限制可见性档位" ≈ 已有 `allow-auth-none` 全局开关——语义补齐即可。

### 3.6 Claude Code（Desktop Preview 面板）

**expose 能力清单**（官方文档核实）：
- Desktop 预览面板：`preview` 打开 `http://localhost:<port>`（本地、单机、AI 驱动）；in-app browser（点击/交互）。
- **无公网隧道/端口暴露能力**；"Claude Code on the web" 是云端托管商业产品（数据在本机之外）。

**可借鉴点**：
- **内嵌预览 iframe**（B 级，pi-web 层）：ServicesDialog 里加"预览"按钮，iframe 内嵌 vhost（`5173.pi.localhost`），处理认证 cookie 与 basePath。这是纯 UI 增强，与隧道无关。
- 不做"Claude Code on the web"式云托管——赛道不同、数据出境。

### 3.7 其它 agent（aider / OpenHands / Cline / Codex）

| agent | expose 能力 | 结论 |
|---|---|---|
| aider | `/share` 上传会话到 aider.chat（web 查看器），非端口 | 无可借鉴的端口机制；会话分享思路同 opencode |
| OpenHands | sandbox 端口转发（弱）；**issue #6183 还在申请** "detect port opened and forward like Colab/Codespaces" | 它缺的正是 service-tunnels 已有的 discovery + expose——**我们无需向它学习** |
| Cline / Roo | IDE 插件，无内置隧道（社区用 ngrok MCP 补） | 无 |
| Codex CLI | 无端口转发 | 无 |

### 3.8 隧道工具生态（新 provider 候选，重点）

| provider | 类型 | 账号/依赖 | TCP | URL 形态 | 适配成本 |
|---|---|---|---|---|---|
| **pinggy** | ssh 免安装（`ssh -p 443 -R0:localhost:<p> free.pinggy.io`） | 免费：随机子域 60 分钟硬上限；付费：持久子域（`pinggy.online`）/多端口 | ✓（`tcp@free.pinggy.io` / `tls@`） | `https://<rand>.a.pinggy.online`（free）|**S**：纯 ssh 参数预设 + URL 正则 |
| **localhost.run** | ssh 免安装（`ssh -R 80:localhost:<p> nokey@localhost.run`） | 免费随机子域 | HTTP 为主 | `https://<rand>.localhost.run`（**已在 URL 正则**） | **S**：纯预设 |
| **hop.to**（hopto.org） | ssh 免安装（`ssh -R 80:... <rand>@hopto.org`） | 免费 | HTTP | `https://<rand>.hop.to`（已在 URL 正则） | **S**：纯预设 |
| **zrok** | 开源二进制（OpenZiti 零信任网格） | `zrok enable <token>`（公共实例免费；**可自建 server**） | ✓（tcp/udp） | `https://<rand>.zrok.io`（public）；private 走 ziti 网格 | **A**：TOOLS 下载 + 双模命令（public/private） |
| **devtunnel**（微软） | CLI（官方下载） | GitHub/MS 账号一次性浏览器登录 | ✓ | `https://<port>-<id>.<region>.devtunnels.ms` | **A**：TOOLS 下载 + login 交互 + 可见性映射 |
| **tailscale serve/funnel** | tailscale CLI（用户自带） | tailnet 身份 | ✓（funnel 支持 TCP） | `https://<machine>.<tailnet>.ts.net` | **A**：仅命令封装 + ts.net URL 正则 |
| **tunnelmole** | CLI（npm/binary） | 注册免费 | HTTP | `https://<rand>.tunnelmole.net` | **A**：TOOLS 条目 |
| **cloudflared named tunnel** | 现有 provider 扩展 | 已有 | ✗（HTTP） | 自定义域名 | **B**：`--config/--token` 支持 + 本地管理 |

> pinggy / localhost.run / hop.to 三者的本质：**service-tunnels `ssh` provider 的"服务商预设"**——不需要新二进制，`host/port/remotePort/user` 全部可预设，只差 URL 正则与 schema。这正是"快速适配"的最佳样本。

---

## 4. 能力差距矩阵

| 能力 | service-tunnels 现状 | 调研对象 | 差距 | 适配档位 |
|---|---|---|---|---|
| 公网隧道 provider 数量 | 9 | 生态 ~15+ | 缺 pinggy/localhost.run/hop.to/zrok/devtunnel/tailscale/tunnelmole | S/A |
| URL 解析已知域 | ngrok/trycloudflare/loca.lt/serveo/wormhole.app/localhost.run/hop.to/natapp | — | 缺 pinggy/zrok/devtunnels.ms/ts.net/tunnelmole | S |
| 认证（用户库/2FA/站点） | 5 provider + TOTP + site | Codespaces 三态可见性 | 缺"可见性"心智模型映射 | B（轻） |
| daemon 远程管理认证 | 仅本地 IPC（socket/随机 secret） | opencode serve（password） | 加远程监听 + 用户认证 | S |
| 会话/快照分享 | 无 | opencode `/share`、aider `/share` | 静态快照 + 过期 token | B |
| 端口发现 → 一键转发 | 发现 + 手动 expose | VS Code Ports（auto-forward） | 缺 auto-expose 提醒策略 | B |
| 内嵌预览 | 无 | Claude Code Preview / Codespaces webview | iframe vhost 预览 | B（pi-web 层） |
| 终端/VNC 查看 | 无 | PiClaw（pty / VNC） | node-pty / noVNC | C |
| trust-proxy 头信任 | 部分（有 rebinding 防护） | PiClaw `PICLAW_TRUST_PROXY` | 文档化 + 开关化（带白名单） | B |

---

## 5. 快速适配清单（分级）

> 适配方式一律遵守 AGENTS.md：新 provider 只动 `tunnels.ts`/`tools.ts`/`tunnels.ts` schema，认证统一在决策 API 进程内，测试用 `pickFreePort`，安全默认（D4/allow-auth-none）不被绕过。

### S 级：纯配置/命令级（0.5~1 天，6 项）

| # | 项 | 改动点 | 说明 |
|---|---|---|---|
| S1 | **pinggy provider** | `TunnelType` + `TUNNEL_PARAM_SCHEMAS`（预设 host=free.pinggy.io, port=443, remotePort=0, 可选 token/子域）+ args switch + URL 正则 `pinggy.io/a.pinggy.online` + `tunnelSupportsTcp` | 零二进制；free 60 分钟随机子域；`tcp@`/`tls@` 用户前缀 = TCP 能力 |
| S2 | **localhost.run provider** | 同 S1（host=localhost.run, user=nokey, `-R 80:`） | URL 正则已有 |
| S3 | **hop.to provider** | 同 S1（host=hopto.org） | URL 正则已有 |
| S4 | **URL 已知域扩展** | `extractTunnelUrl` 正则加 pinggy/zrok/devtunnels.ms/ts.net/tunnelmole.net | 为 A 级铺路，独立提交 |
| S5 | **daemon 远程监听 + 用户认证** | 现状：`daemon-server.ts` 已有 IPC 认证但**仅限本地**（POSIX 0600 unix socket；Windows 127.0.0.1 + 随机 secret，`x-service-tunnels-auth`）。新增：可选 `daemon start --listen 0.0.0.0` 远程模式 + 用户可配密码/token（复用 basic/token provider 的 APR1/Bearer 校验），HTTP 层校验后才路由到 RPC | 对标 opencode `OPENCODE_SERVER_PASSWORD`；让远程浏览器/CLI 管理 daemon，密码不落日志 |
| S6 | **复制 + QR 分享链接**（pi-web 层） | ServicesDialog 每 URL 加 QR（qrcode 依赖已有）+ 复制按钮 | 纯 UI，trivial |

### A 级：新 provider / 语义层（1~2 天，4 项）

| # | 项 | 改动点 | 说明 |
|---|---|---|---|
| A1 | **zrok provider** | `TOOLS` 条目（zrok.io 官方下载 + 镜像）+ `zrok enable <token>` 首次激活（`--token` schema）+ `zrok share public\|private http://127.0.0.1:<target>`（+ tcp/udp）+ URL 正则 zrok.io | 开源、零信任、**可自建 server**（CN 友好可自建）；public = 匿名 URL；private = ziti 网格身份（文档说明与本地网关认证是**两条信任路线**，private 不需要起 nginx/authelia） |
| A2 | **devtunnel provider** | `TOOLS` 条目（devtunnel 官方 release）+ `devtunnel user login`（一次性浏览器 OAuth；headless 文档说明）+ `devtunnel host -p <target> [--allow-anonymous]` + URL 正则 devtunnels.ms | 免费、无卡；可见性 Public/Private 语义直接映射 auth none / 账号认证；组织级 `--allow-org` 与 site 对应 |
| A3 | **tailscale serve/funnel provider** | 无下载（用户自带 `tailscale`；`tools.ts` 只做 PATH 探测 + 安装提示）+ `tailscale funnel --bg <port>`（公网）/`tailscale serve --bg http://127.0.0.1:<port>`（tailnet 私网）+ URL 正则 ts.net | funnel 需 tailnet 开 HTTPS；serve = "仅 tailnet 可达" = 又一个身份认证路线（对标 Codespaces Private）；`tailscale status` 探测 machine/tailnet 名生成 URL |
| A4 | **端口可见性语义层** | `expose.ts` 增 `visibility: "public"\|"private"\|"org"`（映射：public→auth none 校验、private→token/portal 默认、org→site 必须）；schema/UI 按可见性分组；文档 | 机制零新增（全部落在现有 auth 维度），给用户 Codespaces 式心智模型；默认 private |

### B 级：新功能（2~5 天，挑 2-3 项做）

| # | 项 | 改动点 | 说明 |
|---|---|---|---|
| B1 | cloudflared **named tunnel** 完整支持 | 现有 cloudflared provider 增 `--config/--token/--url` 模式 + 自定义域名 + `tunnelName` 本地持久化 | 现有 provider 的自然延伸，稳定 URL |
| B2 | **auto-expose 检测提醒** | `discovery` 事件（新端口）→ 按策略（proxy only、app 白名单、可关闭）弹提醒/预填表单；**绝不自动放行**（D4） | VS Code Ports 行为，但守住显式 enrollment |
| B3 | **内嵌预览 iframe**（pi-web 层） | ServicesDialog 加"预览"按钮：iframe 打开 vhost，处理认证 cookie/basePath | Claude Code Preview 对标，纯 UI |
| B4 | **会话快照分享**（pi-web 层 + 库） | 把 pi 会话 JSONL 渲染为静态快照 → proxy 托管 → **过期一次性 token 链接**（token provider `expiresAt` + 一次性语义）；可撤销 | opencode `/share` 的自托管版本（数据不出本机） |
| B5 | **trust-proxy 开关文档化** | `proxy.ts`/`gateway.ts` 确认 `X-Forwarded-*` 处理 + 新增 `trustXForwarded` 开关（默认关，开时仅信任白名单 Host，DNS-rebinding 防护保持） | PiClaw `PICLAW_TRUST_PROXY` 语义，带安全底线 |

### C 级：5 天+ / 观望（3 项）

| # | 项 | 说明 |
|---|---|---|
| C1 | web 终端（node-pty） | pi-web 层；jmfederico/PiClaw 都有，是远程监督缺口，但与 expose 无直接关系 |
| C2 | VNC 查看器（noVNC + websocket-tcp-bridge） | pi-web 层；依赖策略 + 安全审查（VNC 无加密，必须过网关认证 + TLS） |
| C3 | 移动端 PWA / Tailscale 集成深度化 | ygncode 路线；非 expose 直接相关 |

---

## 6. 实施计划（阶段）

| 阶段 | 范围 | 内容 | 预计 |
|---|---|---|---|
| Phase 0 | S 级 6 项 | S1-S6 + 本文档归档 + `npm test` 新增单测（命令组装/URL 解析，纯函数） | 本周 |
| Phase 1 | A 级 4 项 | A1-A4；每个新 provider 补 e2e（`pickFreePort` + 免费端点/自建，遵 AGENTS.md 测试约定） | 下周 |
| Phase 2 | B 级选做 | B1 + B3（named tunnel / 内嵌预览）优先级最高；B2/B4/B5 按需 | 两周内 |
| Phase 3 | C 级 | C1 终端先行（远程监督价值大），C2/C3 观望 | 视需求 |

**依赖顺序**：S4（URL 域扩展）先于 A1-A3；S5（daemon API 认证）独立可并行；A4（可见性）依赖 Phase 0 的 schema 基线。

---

## 7. 明确不做

1. **OpenCode `/share` 上第三方云**（opncd.ai）：数据出境，做自托管快照（B4）替代。
2. **Claude Code on the web / Codex web / OpenHands 云 IDE 路线**：赛道不同（CLI 配套控制面板 vs 云 IDE），护城河是"共享 session + 隧道"。
3. **绕过 D4 的自动公网放行**：一切 auto-expose 只是"提醒 + 预填"，授权永远显式。
4. **无白名单的 trust-proxy 头信任**：PiClaw 语义可以学，DNS-rebinding 防护不能丢。
5. **PiClaw add-ons（Proxmox/Portainer/Windows 桌面）**：与 expose 无关。

---

## 8. 验收标准

1. **新增 provider**（S1-S3、A1-A3）：`npm test` 全绿（新增单测覆盖：args 组装、URL 解析、TCP 能力矩阵、schema 字段）；真实 e2e 至少各一条（免费端点或自建，遵 `pickFreePort` 约定）；`st.tunnelSchemas()` / `st.schemas.tunnels()` 自动出现新类型，pi-web 下拉框**零代码改动**生效。
2. **语义/安全项**（A4、S5、B5）：不新增攻击面——A4 默认不放开 `auth none`（沿用 `allow-auth-none` 开关）；S5 密码不落日志；B5 默认关、白名单生效。
3. **无回归**：324 组合矩阵抽查（proxy/tunnel/both × auth × protocol 关键路径），`npm run typecheck` 通过。
4. **文档**：README 隧道速查表、sites-design、api.md 同步更新；AGENTS.md 的发布清洗约定（内部域名/端口不入公共 npm 包）在打包前核对。

---

## 附录：证据索引（调研核实的出处）

- OpenCode：`packages/opencode/src/share/share-next.ts`（opncd.ai POST /api/share、secret 增量同步、OPENCODE_DISABLE_SHARE）；`server/auth.ts`（OPENCODE_SERVER_PASSWORD）；v2 docs "Session sharing … /share only reports unavailable"。
- PiClaw：`docs/reverse-proxy.md`（PICLAW_TRUST_PROXY、X-Forwarded-* 解析、Cloudflare Tunnel 示例）；`docs/configuration.md`（PICLAW_WEB_VNC_TARGETS / VNC_ALLOW_DIRECT / WEB_TERMINAL_ENABLED）；tree API 定位 `websocket-tcp-bridge.ts`、`vnc-session-service.ts`。
- VS Code/Codespaces：`code.visualstudio.com/docs/debugtest/port-forwarding`（可见性 Private/Public、devtunnel）；`docs.github.com/.../forwarding-ports-in-your-codespace`（Private/Org/Public）。
- Claude Code：`code.claude.com/docs/en/desktop`（preview 打开 http://localhost:<port>）。
- 隧道工具：pinggy.io/docs/usages/（`ssh -p 443 -R0:localhost:<p> free.pinggy.io`、tcp@/tls@ 前缀）；microsoft/dev-tunnels（devtunnel CLI 可见性）；openziti/zrok（public/private/tcp/udp/file、可自建）；tailscale.com/docs（serve/funnel）；localhost.run、hopto.org、tunnelmole。
- service-tunnels 现状：`src/tunnels.ts`（9 provider + schema + URL 正则 L230）、`src/tools.ts`（TOOLS 表）、`src/expose.ts`（mode×auth×protocol）、`src/daemon-server.ts`（无 API 认证）、pi-web `docs/service-port-proxy.md`（D1-D8）。

---

# 第二部分：深挖

> 在第一部分（横评 + 分级）基础上，本部分对每个可学习项做原理级深挖
> （§9），并对"向外部项目推 PR 集成 service-tunnels"做逐项目可行性/工作量
> 分析（§10）。证据均为源码/文档/API 实测（见 §附录更新）。

---

## 9. 可学习项逐个深挖

### 9.1 S1-S3：ssh 免安装 provider（pinggy / localhost.run / hop.to）

**原理深挖**（服务端机制完全相同，均依赖 OpenSSH 客户端与 `-R` 反向转发）：

```
# pinggy（免费档）—— 实测命令（pinggy.io/docs/usages/）：
ssh -p 443 -R0:localhost:<localport> free.pinggy.io
#   -R0: 请求服务端分配随机公网端口（0 = 随机）；免费档 60 分钟硬上限
#   用户名前缀切换类型：tcp@free.pinggy.io（原始 TCP）/ tls@（TLS 包装）/ qr@
#   stdout 打印 "https://<rand>.a.pinggy.online"（free）或 pinggy.online（持久子域）
#   proxied 请求带 X-Pinggy-Url 头（原始 URL）

# localhost.run —— 免账号，随机子域：
ssh -R 80:localhost:<localport> nokey@localhost.run
#   stdout 打印 "https://<rand>.localhost.run"（固定 80 → 目标端口）

# hop.to（hopto.org）—— 免账号，自定义子域可选：
ssh -R 80:localhost:<localport> <name>@hopto.org
#   stdout 打印 "https://<name>.hop.to"
```

**为什么是"快速适配"的最佳样本**：service-tunnels 的 `ssh` provider 已有全部
机制（`ssh -R <remotePort>:127.0.0.1:<target>`、`-p <port>`、user@host、
`extractTunnelUrl` 对 stdout 的 URL 提取）。三个新 provider = **`TunnelType`
联合 + schema 预设（host/port/remotePort/user 固定）+ args switch 一个 case +
URL 正则一条**。无新二进制、无账号流程（免费档）。pinggy 的 `tcp@` 前缀
把 TCP 能力**显式化**——`tunnelSupportsTcp` 对 ssh 系本来就返回 true，免费获得。

**学习点**：
1. **"服务商预设"模式**（ssh 基础能力 × 服务商配置 = 新 provider）——以后任何
   ssh 型服务（serveo 之外还有 natapp 类）都照此办理。
2. **用户名即参数通道**（pinggy 用 `tcp@`/`tls@`/token 作 ssh 用户名）——command/
   自定义隧道模板可复用的技巧。
3. **stdout URL 提取的健壮性**：pinggy/localhost.run/hop.to 的输出格式各不相同，
   `extractTunnelUrl` 的正则要覆盖 `https://<rand>.localhost.run`、
   `https://<rand>.a.pinggy.online`、`https://<name>.hop.to` 三种形态——单测
   要逐条。

**落点**：`src/tunnels.ts`（类型/schema/args/正则/tcp 矩阵）、`test/tunnels.test.mjs`
（纯函数单测）、`docs`（README 速查表）。
**风险/边界**：免费档随机子域无认证——文档必须标注"仅演示用"，且遵守
`allow-auth-none` 语义（隧道层公开 ≠ 网关放行，认证仍在本地端口侧）。

### 9.2 S4：URL 已知域扩展

**原理深挖**：`extractTunnelUrl`（`src/tunnels.ts` L230）是目前 URL 解析的唯一
权威：一条大正则匹配已知隧道域名 + bore 的 "listening at host:port" 合成 +
command/ssh 的非 localhost 兜底。新增域名只需加进正则。
**落点**：`a\.pinggy\.online|pinggy\.io|pinggy\.online|zrok\.io|devtunnels\.ms|ts\.net|tunnelmole\.net|hop\.to(已有)|localhost\.run(已有)`。
注意 `ts.net` 是 tailscale 全尾网域名后缀，要限定形态（`<machine>.<tailnet>.ts.net`）。
**风险**：`ts.net` 与 `devtunnels.ms` 的子域层级与现有正则的 `[a-z0-9.-]*\.` 前缀
模式兼容性——写单测覆盖各形态。

### 9.3 S5：daemon 远程监听 + 用户认证（对标 opencode `OPENCODE_SERVER_PASSWORD`）

**原理深挖（opencode `server/auth.ts`，源码核实）**：
```ts
password: EffectConfig.string("OPENCODE_SERVER_PASSWORD").pipe(EffectConfig.option),
// authorized()：请求带 Basic Authorization → 与 OPENCODE_SERVER_PASSWORD 比对
// authorization()：把凭据注入后续请求头
```
opencode serve 的模型 = **单密码 basic 认证 + 可选 hostname/port 绑定**，无用户库、
无 2FA。它的 web app 也受此保护（`opencode web` 未设密码时明确提示 unsecured）。

**service-tunnels 现状**（`src/daemon-server.ts`，源码核实）：
- POSIX：`listen()` 用 0600 unix socket（文件系统权限即门禁），无 HTTP 层认证。
- Windows：TCP 127.0.0.1 + 每实例随机 secret（`x-service-tunnels-auth` 头），
  secret 存 state.json（0600）。
- 结论：**本地 IPC 已有足够安全，缺的是"可选的远程管理模式"**——这正好与
  opencode serve 的模型对齐。

**学习点/落点**：
1. `daemon start --listen <host:port>` 可选参数：绑定 0.0.0.0 时强制要求认证
   （fail-closed：不配密码拒绝启动，避免裸奔——比 opencode 默认无密码更安全）。
2. 认证复用现有 provider：basic（APR1 校验已有）或 token（Bearer 已有）。
   HTTP 层校验 → 才路由到 RPC handler；密码不落日志。
3. CLI 客户端 `--api-url` + 密码/环境变量注入（不落 shell 历史）。
**工作量**：约 0.5-1 天（`daemon-server.ts` + `cli.ts` + daemon 测试）。
**风险**：远程模式 = 管理面暴露，必须默认关、文档显著告警、受 `allow-auth-none`
全局开关语义约束（管理面认证也不可关闭）。

### 9.4 S6：QR + 复制分享链接（pi-web 层）

**原理深挖**：OpenChamber `openchamber tunnel` 默认在 TTY 打印二维码（`--qr/--no-qr`），
`tunnel status` 显示 URL——"把隧道 URL 搬到手机浏览器"是远程监督场景的刚需。
pi-web 的 `package.json` 已依赖 `qrcode`（1.5.4）——组件现成。
**落点**（pi-web）：ServicesDialog 每个 URL 行加 QR 弹层 + 复制按钮；
service-tunnels CLI 可加 `sts tunnel qr <name>`（零依赖 qrcode-terminal 类库
需评估；或仅 pi-web 层做，CLI 不做）。**工作量**：0.5 天。

### 9.5 A1：zrok provider（开源、零信任、可自建）

**原理深挖（openziti/zrok，文档+社区核实）**：
```
zrok enable <token>                      # 一次性激活（token 来自公共实例或自建 server）
zrok share public  http://127.0.0.1:<p>  # 公网 HTTPS URL（https://<rand>.zrok.io）
zrok share private http://127.0.0.1:<p>  # 私享：仅已启用同一 ziti 身份的 zrok 客户端可达
zrok share tcp     <port>                # 原始 TCP（v0.4+）；udp 亦支持
zrok share file    <dir>                 # 文件分享（zrok file cp 取用）
zrok server ...                          # 自建服务端（零信任网格，需 2 个公网端口）
```
**学习点**：
1. **private 模式 = 第二条认证路线**：zrok 的私享不经过任何本地网关——身份由
   OpenZiti 网格背书（类似 tailscale 身份）。这与 service-tunnels"认证统一在
   本地端口侧"正交：**要么**隧道透传 + 本地网关认证（现有架构），**要么**用
   zrok private 这类"隧道自带身份认证"（`--auth` 语义映射为 provider "zrok-private"）。
   文档要讲清两条路线，schema 里 private 模式的 auth 下拉禁用本地 provider。
2. **可自建 = CN 友好**：自建 zrok server 后无任何外部依赖（对齐 bore/frp 的自建
   定位），适合内网/合规场景。
**落点**：`TOOLS` 条目（GitHub release 二进制 + 镜像）、schema（token + mode
public|private + protocol）、args switch（`zrok enable` 幂等 + `zrok share`）、
URL 正则 `zrok.io`、`tunnelSupportsTcp`（tcp/udp = true）。
**风险**：`zrok enable` 是交互式一次性步骤（公共实例需网页取 token）——headless
要文档；二进制 ~15MB。

### 9.6 A2：devtunnel provider（微软，免费无卡，可见性语义现成）

**原理深挖（microsoft/dev-tunnels 官方文档）**：
```
devtunnel user login            # 一次性浏览器 OAuth（GitHub 或 Microsoft 账号）
devtunnel host -p <port>        # 默认 Private：访问者须登录同一/被授权账号
devtunnel host -p <port> --allow-anonymous   # Public：任何人可访问
devtunnel host -p <port> --allow-org         # 组织内
# URL: https://<port>-<tunnelId>.<region>.devtunnels.ms（免费、稳定、无信用卡）
```
**学习点**：
1. **可见性三态 = service-tunnels auth 的天然映射**：anonymous → `auth none`
   （受 `allow-auth-none` 约束）、Private → 账号认证（可映射为 portal/token 站点）、
   Org → site（组织域）。与 A4（可见性语义层）互为表里。
2. **登录交互范式**：devtunnel 的 `user login` 是"CLI 发起 → 浏览器完成 OAuth →
   CLI 收 token 存本地"。service-tunnels 的 ngrok/oauth2 类 provider 将来要加
   账号态时可用同一模式（当前 service-tunnels 用 authtoken 字符串，无交互登录）。
**落点**：TOOLS 条目（devtunnel 官方 release，多平台）+ schema（mode
public|private|org + 预留 hostId/region）+ args switch + URL 正则
`devtunnels.ms`。**工作量**：1-2 天（含登录交互文档与 headless 提示）。
**风险**：登录态依赖浏览器 OAuth——CI/服务器场景要么预先登录、要么文档明确
不支持；URL 带 region（eu/uk/ap 等）要解析通用形态。

### 9.7 A3：tailscale serve/funnel provider（身份即认证）

**原理深挖（tailscale.com/docs，官方）**：
```
tailscale funnel --bg <port>   # 公网 HTTPS：https://<machine>.<tailnet>.ts.net
tailscale serve  --bg http://127.0.0.1:<port>   # 仅 tailnet 内：同一 ts.net 域名，公网 403
tailscale status --json        # 取 machine/tailnet 名（生成 URL 用）
# funnel 前置：tailscale up + HTTPS 证书（tailnet 需启用 funnel 特性，个人版免费）
```
**学习点**：
1. **身份认证内置**：serve = "只有我的设备能访问"，比密码更强（设备证书）。
   映射为 auth 维度"tailnet"（无需本地网关）——与 zrok private 同类。
2. **URL 解析的域限制**：`ts.net` 是全局后缀，`extractTunnelUrl` 要限定
   `<machine>.<tailnet>.ts.net` 形态 + 非 `login.ts.net`/`controlplane.ts.net`
   等保留名，防误抓。
**落点**：无下载（`tools.ts` 只做 PATH 探测 + 未装提示），命令封装 + `tailscale
status --json` 取域名 + URL 正则。**工作量**：1-2 天。
**风险**：tailscale 是用户自有账号体系；funnel 需要 tailnet 管理员开特性（个人版
默认可用）。纯可选 provider，不影响主路径。

### 9.8 A4：端口可见性语义层（Codespaces Private/Org/Public → 现有 auth 映射）

**原理深挖（GitHub Codespaces 官方文档）**：每端口三态可见性——Private（仅本人，
GitHub 认证）/ Org（组织成员）/ Public（有 URL 者）；`gh cs ports` 管理；
org 级策略可**限制**可设档位（管理面封顶）。与 service-tunnels 的对照：
`Public ↔ auth none`、`Private ↔ token/portal（登录）`、`Org ↔ site（独立认证域）`。

**学习点**：
1. **语义层不是新机制**：expose 增加 `visibility: "public"|"private"|"org"` 字段，
   内部翻译为现有 auth 参数的**推荐默认值** + 校验（如 `visibility: "public"`
   要求 `auth: "none"` 且 `allow-auth-none` 开启；`"org"` 要求显式 `--site`）。
2. **管理面封顶**：对齐 Codespaces org 策略——`allow-auth-none=false` 时
   `visibility: public` 直接拒绝（已有开关自然复用）。
3. **UI 分组**：pi-web 表单按可见性三选一，再展开对应参数（减少用户认知负担）。
**工作量**：1 天（`expose.ts` 校验 + schema + UI 分组 + 文档）。
**风险**：纯命名映射不能产生安全语义漂移——校验必须落库内（决策 API），不能只
靠 UI。

### 9.9 B1：cloudflared named tunnel 完整支持

**原理深挖（cloudflared 官方）**：
```
cloudflared tunnel login            # 浏览器 OAuth → 保存证书
cloudflared tunnel create <name>    # 生成 Tunnel ID + credentials 文件
cloudflared tunnel route dns <name> <hostname>
cloudflared tunnel --config config.yml run <name>   # 稳定自定义域名
# quick tunnel（现 provider 实现）: cloudflared tunnel --url http://127.0.0.1:<p>
```
**现状**：`src/tunnels.ts` cloudflared 分支只有 quick tunnel + `domain` 字段（实为
命名隧道提示）。**学习点**：named tunnel = 稳定 URL + 自定义域名 + 免注册卡；
`--config` 文件的生成/管理可作为 state.json 的一部分。**工作量**：2-3 天
（config 模板 + 生命周期管理 + 登录交互文档）。**风险**：账号 OAuth 交互同 devtunnel。

### 9.10 B2：auto-expose 检测提醒（VS Code Ports 行为，守住 D4）

**原理深挖（VS Code）**：Ports 面板自动抓取终端输出里的 URL/端口 → 列表展示 →
一键"Forward a Port"（点击才转发）。**学习点**：service-tunnels `discovery`
已有跨平台进程树/端口枚举；缺的是"发现事件 → 提醒/预填"，**绝不自动放行**。
**落点**：`discovery` 增加 onPortsChanged 回调（或轮询 diff）+ pi-web ServicesDialog
顶栏"新端口"气泡；策略：仅 proxy 模式候选 + app 白名单（`PI_WEB_OWN` 已有类似
机制）+ 可全局关闭。**工作量**：2-3 天。

### 9.11 B3：内嵌预览 iframe（Claude Code Preview / Codespaces webview 对标）

**原理深挖（Claude Code desktop）**：`preview` 命令打开 `http://localhost:<port>`
内嵌浏览器面板（本地、solo-first）；builder.io 文章指出其定位是"单开发者本地迭代"。
**学习点**：pi-web ServicesDialog 加"预览"按钮 → iframe 打开 vhost
（`5173.pi.localhost`）；需处理：认证 cookie 同源（vhost 是独立 origin，
portal cookie 按域隔离 → 预览需带登录态或走无认证 vhost）、basePath、X-Frame
拒绝（目标服务自己拒绝嵌入时提示"在新标签打开"）。**工作量**：1-2 天（pi-web 层）。

### 9.12 B4：会话快照分享（opencode `/share` 的自托管版本）

**原理深挖（opencode `share/share-next.ts` 源码）**：
- 创建：`POST /api/share {sessionID}` → `{id, url, secret}`（secret 服务端留存）；
- 增量同步：`POST /api/shares/{id}/sync {secret, data[]}`——session/message/part/
  diff/model 五类数据 **1 秒防抖批量**推送；
- 删除：`DELETE /api/shares/{id} {secret}`；读取：`GET /api/shares/{id}/data`；
- 关闭开关：`OPENCODE_DISABLE_SHARE`；自动分享：`share: auto` 配置。
**学习点（自托管版）**：
1. **分享 = 只读快照 + 一次性 secret + 可撤销**，与"端口 expose"完全不同的维度。
   service-tunnels 承担：把 pi 会话 JSONL 渲染的静态快照托管到 proxy
   （`<port>-share.<domain>`），访问鉴权 = **过期一次性 token**（token provider
   已有 `expiresAt`，需加"单次使用"语义）。
2. **增量同步协议**（1s 防抖 + secret 认证 + 五类数据）可直接作为 pi-web 到
   share 端点的协议参考。
**工作量**：库侧（一次性 token 语义）1-2 天 + pi-web 侧（快照渲染 + UI）2-3 天。
**风险**：快照可能含敏感信息（代码 diff、环境变量）——默认仅"会话文本+代码树"，
默认不过期不分享；UI 显著提示。

### 9.13 B5：trust-proxy 头信任开关（PiClaw `PICLAW_TRUST_PROXY` 对标）

**原理深挖（PiClaw `docs/reverse-proxy.md`）**：
- `PICLAW_TRUST_PROXY=1` 时按 `X-Forwarded-Proto/Host/Port/For`、`X-Real-IP`
  解析外部 origin 与客户端 IP；未开启时一律忽略 forwarded 头（防伪造）。
- 设计意图：web UI 可同时经"公网代理域名"与"局域网直连"访问，登录态/绝对 URL/
  WebAuthn 不串。
**学习点**：service-tunnels 的 gateway/proxy 已有 DNS-rebinding 防护
（X-Forwarded-Host 校验）——**比 PiClaw 更安全**。要做的是：① 把"哪些头信任、
信任哪些 Host"固化为显式开关 + 白名单（默认关）；② 文档化（反代部署的读者
对照 PiClaw 的心智模型）。**工作量**：1-2 天。**风险**：开信任必须绑定 Host
白名单，否则回环域名伪装可绕过 rebinding 防护——这是底线，不可省略。

---

## 10. 向外部项目推 PR 集成 service-tunnels：可行性与工作量

### 10.0 前置条件（硬门槛，先于一切 PR）

| 门槛 | 现状 | 处置 |
|---|---|---|
| **service-tunnels 上公共 npm** | 仅私有镜像 `npm.alot.pw` | **任何外部项目都无法 `npm install service-tunnels`**——必须先按 AGENTS.md 清洗（移除 .npmrc 凭据/内部域名/端口/路径，英文 README）并发布公共 npm（promotion-plan §2.1：`service-tunnels` 名称可用） |
| License | MIT ✓ | 所有目标项目均为 MIT，无冲突 |
| Node engines | >=20.19.0（AGENTS.md 22.19.0） | 目标项目均为 Node 20+ / bun（Node 22+），兼容 |
| 运行时依赖 | 仅 `justget`（下载竞速）✓ | 可嵌入性良好；二进制（nginx/authelia/redis）按需拉取，不影响依赖树 |
| 文档语言 | 中文为主 | 对外 PR 需附英文 README/文档段（promotion-plan §2.5 已有计划） |

### 10.1 agegr/pi-web（上游，windli fork 的母仓库）

**画像（2026-08-07 实测）**：MIT；Next.js + React 19；活跃发版（v0.8.7，08-06）；
**合并外部 PR**：最近一个月 10+ 个 PR 被合并（#352 即 windli2018——本 fork 作者——
的 @mention 按钮特性），维护者并非"不合并 PR"（修正了横评报告 §3.4 的旧判断）。
**集成形态**：把 windli fork 的 service-tunnels 集成**子集**作为 PR 上提——
`lib/service-tunnels-integration.ts` + `app/api/service-tunnels/route.ts` +
ServicesDialog 组件 + `proxy.ts` 的 `st.proxy.resolve()` 调用点。
**阻塞项**：① 公共 npm（10.0）；② fork 已 146 commit 领先且有私有化改造
（queue 持久化、worktree、i18n），上提时需只带 service-tunnels 相关文件并
rebase 到 agegr 当前结构；③ `PI_WEB_OWN` 等内部标记需要泛化；④ 双认证域
（pi-web vs services）的 site 预设名需文档化。
**工作量**：2-4 天（rebase + 抽子集 + 英文文档 + 在 agegr 的 CI 跑
typecheck/lint/build）。
**成功概率**：**高**——同代码库、作者已有成功 PR 先例（#352）、维护者活跃。
**价值**：把 service-tunnels 推到月下载 1.6 万的最大 pi-web 分支，等于给
service-tunnels 带来最大嵌入方 + 反向的 issue/需求反馈。

### 10.2 jmfederico/pi-web（服务式 fork）

**画像**：MIT；**Vite + tsx 全栈重写（非 Next.js）**（src/cli.ts、src/server/
sessiond.ts、nativeServices、plugin-api）；活跃（08-07 仍在推）；npm 包
`@jmfederico/pi-web`（per-user 服务安装）。
**集成形态**：两种路径——① 核心 PR：把 service-tunnels 作为 nativeService
（server 侧常驻）接入（新写，非移植——结构不同）；② 插件：其 `plugin-api`/
`extensions` 机制若能注册 server 侧服务，则插件形态（低摩擦）。
**阻塞项**：① 公共 npm；② 结构不同 → 全新集成（middleware 无、Next 无，需在其
server/原生服务层挂 `st.proxy` 与 expose API）；③ **战略顾虑**：jmfederico 是
品牌竞争者（横评 §3.4），把资产送去等于给竞争对手补短板。
**工作量**：5-10 天（新集成 + 其 CI 的 typecheck/lint/knip 门槛）。
**成功概率**：中（技术可行），但**优先级低**（战略上不宜）。

### 10.3 PiClaw（rcarmo/piclaw，Docker 全栈）

**画像**：MIT；bun + supervisor + SQLite；**严格 PR 流程**（AGENTS.md：一律 PR、
`make ci-fast`、Playwright UX 测试、两阶段 tag 发布）；活跃（每天发版）；36 open
issues；有 **addon-runtime-api**（`globalThis.__piclaw_runtime`，版本化）与
**web-pane-extensions** 两个插件面。
**集成形态**：**add-on**（其官方形态）——runtime entry 启动 service-tunnels
子进程/Node 库 + web pane 提供端口列表/expose 表单；或核心 PR 挂 reverse-proxy
文档所描述的能力（它本来就期待前置反代/隧道，service-tunnels 正好补上）。
**阻塞项**：① 公共 npm；② PiClaw 全 bun 运行时，add-on 内嵌 Node 库需打包
（bundle 或子进程 `sts` CLI——后者更稳）；③ 安全审查（VNC/终端已在其安全范围，
新增端口暴露会要求同等级审计）；④ add-on 分发渠道（官方 add-ons 目录）。
**工作量**：核心 PR 5-8 天；add-on 形态 3-5 天。
**成功概率**：中——项目专业、欢迎 PR，但集成面（bun vs node、Docker 内子进程
管理、supervisor 生命周期）比 agegr 复杂；且 PiClaw 定位"独立产品"（不回写 pi
JSONL），service-tunnels 与其共享用户场景（自托管 AI 工作区）有重叠。

### 10.4 OpenCode（anomalyco/opencode）

**画像**：MIT；bun monorepo（effect 框架）；**核心功能 PR 需设计评审**
（CONTRIBUTING：UI/core product feature 必须先评审，"ignores guardrails 会被
close"）；插件生态成熟（`@opencode-ai/plugin`：注册工具/事件/配置，无需核心
审批）。
**两条路线对比**：

| 路线 | 内容 | 摩擦 | 工作量 | 成功率 |
|---|---|---|---|---|
| 核心 PR（加 tunnel 功能） | `share` 之外新增端口 expose | **高**——core feature 设计评审；且 opencode 定位 CLI/TUI 生态，隧道不在其 roadmap | 10-20 天（含评审往返） | 低 |
| **插件**（`opencode-expose`） | 注册 `expose`/`tunnel` 工具，shell out 到 `sts` CLI（或 service-tunnels 库），工具输出 URL | 低——插件市场天然接受 | 2-4 天 | **高** |

**插件形态细节**：`@opencode-ai/plugin` 可注册新 tool（如 `expose_localhost`
接收 port/mode/auth 参数 → 调用 `sts expose` → 返回 URL/停止句柄）；会话内 agent
就能"把这个 dev server 给我暴露出去"——与 opencode 的 agent 工作流契合。
**阻塞项**：① 公共 npm；② `sts` CLI 是全局命令，插件需引导安装或带 node 依赖
（plugin 包可依赖 `service-tunnels` npm 包本身）。
**价值**：把 service-tunnels 带入 opencode 生态（月下载 844 万），是**最大增量
曝光**；且插件不占 opencode 核心路线，无被拒绝风险。

### 10.5 OpenChamber（openchamber/openchamber，opencode 的 Web UI）

**画像**：MIT；bun monorepo（electron/vscode/web/mobile）；单维护者（Bohdan
Triapitsyn）但活跃（v1.18.1）；**已有 `openchamber tunnel`**：cloudflared/ngrok
quick/managed 模式 + QR + profiles + doctor（`packages/docs/.../tunnels.mdx`）；
安全文档覆盖"暴露前保护 UI"。
**集成形态**：升级其 tunnel 子系统——用 service-tunnels 替换/扩展其 provider
层（现只有 cloudflare/ngrok 两家的 quick 模式）→ 白赚 9+ provider、认证编排、
站点、TOTP。但注意：它的隧道语义是"**一个实例一个隧道**（保护 opencode server
本身）"，与 service-tunnels"任意服务端口 expose"不完全一致——PR 需要两者并存。
**阻塞项**：① 公共 npm；② bun 运行时同 PiClaw（Node 依赖打包）；③ 单维护者
review 节奏；④ 其隧道已满足自用，升级动机需自己论证。
**工作量**：5-8 天。**成功概率**：中低——收益（更多 provider）对它是锦上添花，
对我们是曝光；谈判点可换成"以 service-tunnels 为可选 provider 后端，默认仍用
原生 cloudflared"（低侵入）。

### 10.6 cc-connect（chenhg5/cc-connect，自家 workspace 项目）

**画像**：MIT；**Go**；agent/pi 与 agent/opencode 适配器已存在（桥接 IM ↔ agent）。
**集成形态**：非"外部 PR"，而是自家生态整合——在 bridge/API 层提供
"给 IM 用户暴露 dev server"：Go 进程 spawn `sts` CLI（子进程）+ 把 URL 回发到
IM 卡片。也可作为 service-tunnels 的**第一个 Go 语言嵌入案例**（REST/IPC 面）。
**阻塞项**：Go ↔ Node 边界（子进程 or HTTP bridge——用 daemon HTTP API 正好是
S5 的落地场景）。
**工作量**：3-5 天。**价值**：自家生态打通，且验证 daemon 远程 API（S5）。

### 10.7 不做 PR 的目标

- **ygncode/pi-web**（Go 重写、70★）：形态不同、体量小，PR 投入产出比低。
- **pi-web-chat / chainingintention**（小 fork/插件）：无维护者价值。
- **Claude Code / Codex / Cursor**：闭源或商业路线，无 PR 面；它们的"expose
  能力"已在 §9 吸收为学习点（Preview 面板、dev tunnels）。
- **PiClaw add-ons 市场**（短期不做）：等核心 PR 或 add-on 形态跑通再说。

### 10.8 PR 路线图总表（按优先级）

| 优先级 | 目标 | 形态 | 前置 | 工作量 | 预期回报 |
|---|---|---|---|---|---|
| P0 | 公共 npm 发布 | 清洗+发布 | promotion-plan 阻塞项 | 1-2 天 | 一切 PR 的前提 |
| P1 | agegr/pi-web | 集成子集 PR | 公共 npm | 2-4 天 | 最大嵌入方 + 反馈回路 |
| P1 | opencode 插件 | `opencode-expose` 插件 | 公共 npm + `sts` 引导 | 2-4 天 | 最大生态曝光（844 万下载/月） |
| P2 | cc-connect | 自家整合 + daemon API 验证 | S5 | 3-5 天 | 生态闭环 + Go 嵌入案例 |
| P3 | PiClaw | add-on 或核心 PR | 公共 npm | 3-8 天 | 自托管 AI 工作区赛道 |
| P4 | OpenChamber | 可选 provider 后端 | 公共 npm | 5-8 天 | opencode Web UI 生态 |
| P5 | jmfederico | 插件/服务 | 公共 npm | 5-10 天 | 品牌竞争顾虑，慎入 |

**决策建议**：先 P0 发布公共 npm → P1 双线（agegr PR + opencode 插件）验证
"嵌入方 × 生态曝光"两条路径 → 用 cc-connect（P2）自证 daemon API → P3/P4 看
反馈再投入。所有 PR 的代码都应先在我们的 CI/单测中站稳（AGENTS.md 发布约定），
再对外。

---

## 附录更新：新增证据

- agegr/pi-web 合并 PR 实证：`api.github.com/search/issues?q=repo:agegr/pi-web+is:pr+merged`（#352 windli2018 @mention 等，2026-07~08）。
- jmfederico/pi-web 结构：`src/server/sessiond.ts`、`src/nativeServices`、`plugin-api/`、Vite+tsx（非 Next.js）。
- PiClaw 贡献文化：AGENTS.md（一律 PR、make ci-fast、两阶段 tag 发布）；`docs/addon-runtime-api.md`（`globalThis.__piclaw_runtime` 版本化插件面）；`docs/web-pane-extensions.md`。
- OpenCode 贡献规则：CONTRIBUTING.md（core feature 需设计评审、guardrail 外 PR 会被 close）；插件机制 `plugin/loader.ts` + `@opencode-ai/plugin`（注册工具无需核心审批）。
- OpenChamber：`packages/docs/content/docs/tunnels.mdx`（openchamber tunnel：cloudflare/ngrok、quick/managed、QR、profiles、doctor、每实例单隧道）；SECURITY.md（暴露前保护 UI）。
- cc-connect：`agent/pi/` 与 `agent/opencode/` 适配器存在；bridge 协议文档；max-webhook 已用 ssh 反隧道。
- zrok：openziti/zrok（public/private/tcp/udp/file、`zrok enable <token>`、自建 server）。
- devtunnel：microsoft/dev-tunnels（`devtunnel host -p <p> [--allow-anonymous|--allow-org]`、devtunnels.ms URL）。
- tailscale：serve（tailnet 内）/ funnel（公网）`--bg` 命令、`tailscale status --json`。
- pinggy：`ssh -p 443 -R0:localhost:<p> free.pinggy.io`、`tcp@/tls@` 用户名前缀、免费 60 分钟、X-Pinggy-Url 头、持久子域迁 pinggy.online。

---

# 第三部分：PR × 插件双路线并行评估

> 前提：**公共 npm 发布是最终目标、非当前动作**（发布阻塞项见 §10.0，仍按
> promotion-plan 执行）；本部分在"将来公开"的前提下，对每个生态逐项评估
> **PR 路线**与**插件路线**两条并行选项，给出推荐。评估维度：
> 机制摩擦（进核心 vs 走插件面）、能力上限（能做到什么）、工作量、风险、
> 生态回馈（曝光/反馈回路）。

---

## 11.1 通用插件面（先于任何项目决策）

### 11.1.1 MCP server：最低公分母，一次开发处处可用

**机制**：MCP（Model Context Protocol）是 2026 年 agent 生态的通用工具协议。
本机 opencode 配置（`~/.config/opencode/opencode.json`）已在用 remote MCP
（web-search-prime / zai-mcp-server）——证明这是主流接入方式。service-tunnels
若发布一个 `service-tunnels-mcp`（stdio server，包 `service-tunnels` 的薄封装，
暴露 `expose_port` / `stop_expose` / `list_exposes` / `list_ports` 工具），则
**任何 MCP 客户端**（Claude Desktop/Code、Cursor、Cline、Roo、Codex、opencode、
Gemini CLI、cc-connect 的 ACP/MCP 层）都能直接获得端口暴露能力，**与具体项目
的 PR/插件机制完全解耦**。

**能力上限**：工具级（agent 通过对话/工具调用触发），无自定义 UI、无菜单/面板；
认证管理（用户/TOTP）走 MCP 资源/工具可部分覆盖。
**工作量**：2-4 天（server + 工具 schema + 鉴权走 daemon API/token + 单测）。
**风险**：低——纯附加面，不侵入任何项目；需注意 MCP 工具要带 permission
确认（避免 agent 未经同意暴露端口——对齐 opencode `permission.ask` 语义）。
**结论**：**先做**。它是所有"插件路线"的共同底座，也是未来 PR 谈判的演示品。

### 11.1.2 pi 扩展（pi-native）：一次开发覆盖全部 pi 生态

**机制**（pi `docs/extensions.md` 实测）：`~/.pi/agent/extensions/` 或
`.pi/extensions/` 自动发现、`/reload` 热重载；`pi.registerTool()` 注册 LLM 可调
工具、`pi.on()` 拦截事件、`pi.registerCommand()` 加斜杠命令、`ctx.ui` 交互、
`pi.appendEntry()` 持久化。**这套扩展在 pi CLI、agegr/pi-web（会话运行时）、
jmfederico/pi-web（sessiond）、pi-web-chat（本身就是 pi 扩展）、ygncode（pi
worker）全部生效**——是覆盖 pi 生态最广的单一接入面。
**形态**：`st-expose` 扩展注册 `expose` 工具（调 `sts` CLI 或库），agent 在会话
里就能"把这个端口暴露出去，给我 URL"；停止/列表同理。
**能力上限**：工具 + 事件 + 命令 + TUI 交互；浏览器 UI 需配合各 fork 自己的
前端（agegr=PR 集成、jmfederico=PI WEB 插件）。
**工作量**：1-2 天（扩展本体，`examples/extensions/` 有模板）。
**结论**：**先做**。与 MCP 互补：MCP 覆盖"非 pi"生态，pi 扩展覆盖"pi 全家桶"。

---

## 11.2 OpenCode：核心 PR vs 插件

| 维度 | 核心 PR（加端口 expose 功能） | 插件 `opencode-expose` |
|---|---|---|
| 机制摩擦 | **高**：CONTRIBUTING 明确 UI/core feature 须设计评审，guardrail 外 PR 会被 close；隧道不在其 roadmap | **低**：插件是官方一等公民；`.opencode/plugin(s)/*.ts` 自动发现或 config `plugin` 数组（npm specifier） |
| 能力上限 | 全功能（但评审周期不可控） | `tool()` 注册工具（zod args + execute）；`PluginInput.$` = **BunShell**（可直接 spawn `sts`）；`serverUrl` 可连 daemon HTTP API；还能用 `auth` hook 注册自定义 provider、`permission.ask` 加暴露确认、`tool.execute.after` 渲染 URL |
| 工作量 | 10-20 天 + 评审往返 | 2-4 天（一个插件包：3 个工具 + 文档） |
| 风险 | 大概率被拒（scope 外） | 极低；插件不占核心路线 |
| 生态回馈 | 进入核心代码库 | 上 opencode 插件市场（生态 844 万下载/月） |

**推荐**：插件路线。关键细节：插件内 `sts` 引导安装（`npx service-tunnels` 提示/
自动装 CLI），工具执行时 `$` 或 `child_process` spawn；`permission.ask` 钩子做
暴露前确认（安全默认）。公共 npm 公开后插件依赖 `service-tunnels` npm 包本体
（库模式进程内），CLI 变兜底。

---

## 11.3 PiClaw：核心 PR vs add-on

| 维度 | 核心 PR | add-on（官方一等扩展形态） |
|---|---|---|
| 机制摩擦 | **中高**：严格 PR 流程（AGENTS.md：一律 PR、`make ci-fast`、Playwright UX 两阶段 tag 发布）；bun 运行时与 Node 库边界要论证 | **低-中**：add-on 是其官方插件面；目录 `rcarmo/piclaw-addons` 收录，Settings→Add-ons 内安装（5 分钟缓存、GitHub tarball）；清单声明 `pi.runtime.entries`（startup/lazy）+ `pi.web.entries` |
| 能力上限 | 全功能（native 集成 VNC/终端同层） | runtime entry 起 `sts` 子进程/库 + web pane（`PaneRegistry`/`openEditor` 路径，VNC/terminal 同款宿主）+ settings pane（`/agent/addons/api/<addon>/<action>` 后端配置 API）+ 可贡献 skills |
| 工作量 | 5-8 天 | 3-5 天（add-on 包：runtime entry + web pane + 安装文档） |
| 风险 | bun↔node 边界、安全审查（暴露功能在其 SECURITY scope） | add-on 需要其目录收录（维护者 review）；bun 环境 spawn node 需文档 |
| 生态回馈 | 自托管 AI 工作区赛道核心 | 同上（add-on 目录曝光） |

**推荐**：add-on 路线先行（低摩擦、快验证），核心 PR 视 add-on 反馈再定。
**关键细节**：PiClaw 全 bun 运行时——add-on 内嵌 Node 库需打包（bundle），或
**spawn `sts` CLI 子进程**（更稳、与运行时隔离）；web pane 复用其
`websocket-tcp-bridge` 思路可做"服务日志/URL 面板"。

---

## 11.4 jmfederico/pi-web：三层机制，插件组合拳

**机制**（`docs/plugins.md` 实测，三层）：
1. **Pi packages**（`pi install`）：分发 Pi 扩展 / skills / 模板 / 主题 / **PI WEB
   浏览器插件**——安装入口统一。
2. **Pi extensions**：session daemon 内运行的服务器侧模块，可 `registerTool`/
   hooks/commands/provider——**服务器侧能力在这层**。
3. **PI WEB plugins**：浏览器侧 ES 模块——action-palette 命令、workspace 面板、
   状态条项、**可启动 workspace 终端命令**、托管静态资源；**无服务器侧 hook、
   非沙箱、受信**。

| 维度 | 核心 PR | 插件组合（Pi 扩展 + PI WEB 插件） |
|---|---|---|
| 机制摩擦 | 中：结构全新（Vite/tsx，非 Next），nativeServices 层要新写集成 | **低**：两层插件都是官方机制；Pi 扩展覆盖服务器侧，PI WEB 插件覆盖 UI |
| 能力上限 | 全功能 | Pi 扩展 `registerTool("expose")` 调 sts + PI WEB 插件做 workspace 面板（端口列表/暴露表单/URL 复制）——覆盖绝大部分场景 |
| 工作量 | 5-10 天 | 3-5 天（Pi 扩展 + PI WEB 插件各一） |
| 风险 | **品牌竞争者**：把资产送给对手 | 低；插件不进其核心，随时可撤 |
| 生态回馈 | — | 其 5.8k 月下载生态 + "社区插件"示范效应 |

**推荐**：插件路线（若做）。Pi 扩展部分与 §11.1.2 **完全复用**（同一份扩展
代码在其 sessiond 生效），只需额外写 PI WEB 插件 UI——边际成本低。
**战略注记**：jmfederico 是品牌竞争者（横评 §3.4），插件的"可撤性"正是选它的
原因——不进核心、不留依赖。

---

## 11.5 agegr/pi-web：仅 PR（无插件系统）

agegr 线**没有** jmfederico 式插件系统（PI WEB 插件是 jmfederico 的产品）。
windli fork 的 service-tunnels 集成**只能**以 PR 子集形式上提（§10.1）。pi 扩展
（§11.1.2）在其会话运行时仍生效（工具级），但浏览器 UI（ServicesDialog）必须
PR。
**推荐**：PR 路线（作者已有 #352 成功先例）；发布窗口 = 公共 npm 公开后。

---

## 11.6 OpenChamber：PR vs 插件

| 维度 | PR（升级其 tunnel 子系统） | 插件（无插件系统，需 MCP/外部） |
|---|---|---|
| 机制 | 其已有 `openchamber tunnel`（cloudflare/ngrok quick/managed + QR + profiles）——PR 把 provider 层换成/扩展为 service-tunnels | **无官方插件机制**——只能走 MCP（§11.1.1）或外部 CLI |
| 摩擦 | 中：单维护者 review；其"单实例单隧道"语义与我们的多端口 expose 需并存 | 低（MCP 现成） |
| 工作量 | 5-8 天 | MCP 已含 |
| 风险 | 中低；收益（9+ provider、认证编排）对它是锦上添花，谈判点=低侵入可选后端 | 无侵入 |
| 回馈 | opencode Web UI 生态曝光 | — |

**推荐**：先 MCP（零成本），PR 作为"可选 provider 后端"的低侵入提案挂起，等
公共 npm 后视维护者态度再推。

---

## 11.7 cc-connect（自家项目）：bridge 动作 vs MCP

**机制**：Go；已有 `agent/pi` 与 `agent/opencode` 适配器、`agent/acp`（ACP/MCP
层）、bridge 协议（WebSocket + REST，`docs/bridge-protocol.md`）。
| 路线 | 内容 | 工作量 |
|---|---|---|
| **bridge 动作** | 在 bridge 层加 `expose` 动作：spawn `sts` + 回传 URL 到 IM 卡片 | 3-5 天 |
| **MCP** | Go 侧通过 MCP client 调 `service-tunnels-mcp`（§11.1.1） | 1-2 天（复用 MCP 底座） |

**推荐**：MCP 先行（Go 生态的通用接法，也是 S5 daemon API 的天然验证场），
bridge 动作按需再加。自家生态打通 = 第一个"非 pi 运行时"的集成案例。

---

## 11.8 VS Code 扩展（在研，插件路线的样板）

仓库已有 `docs/vscode-extension-plan.md` / `-research.md` / `-implementation.md`
（未提交，他人工作）：扩展宿主进程内嵌库 + daemon IPC 兜底、四层端口发现器、
schema 驱动表单、状态栏/树视图。**这是"编辑器插件路线"的完整样板**，也证明了
"库为被嵌入而生"的架构正确。Cline/Roo/Cursor 同理——它们无自定义插件面可用
（Cline 用 MCP、Cursor 用 dev tunnel），MCP 是它们的接入点。

---

## 11.9 决策矩阵与推荐路线图（公共 npm 公开后执行）

| 生态 | PR 路线 | 插件路线 | 推荐 | 顺序 |
|---|---|---|---|---|
| **通用 MCP** | — | `service-tunnels-mcp`（stdio，覆盖所有 MCP 客户端） | **MCP** | **P0** |
| **pi 全家桶** | agegr PR（子集） | pi 扩展 `st-expose`（工具级，全 fork 生效） | **扩展先、PR 后** | P0 扩展 / P2 PR |
| **OpenCode** | 核心 PR（高摩擦） | `opencode-expose` 插件（tool + permission 确认） | **插件** | P1 |
| **jmfederico** | 核心 PR（品牌风险） | Pi 扩展（复用）+ PI WEB 插件（UI） | **插件** | P2 |
| **PiClaw** | 核心 PR（严格流程） | add-on（runtime entry + web pane + catalog） | **add-on** | P3 |
| **OpenChamber** | PR（可选 provider 后端） | 无插件系统 → MCP | **MCP 先行，PR 挂起** | P3 |
| **cc-connect** | —（自家项目） | MCP client / bridge 动作 | **MCP** | P1 |
| **VS Code** | — | 扩展（在研蓝图） | **扩展** | P2 |

**执行要点**：
1. **P0 双底座**（MCP + pi 扩展）相互独立、先落地——它们让"任何 agent 环境都能
   暴露端口"，是生态扩散的最小可行面。
2. **P1 opencode 插件 + cc-connect MCP**：验证"插件路线"在最大生态的可行性，
   同时用自家 Go 项目验证 MCP 通用性。
3. **P2 起**：agegr PR（依赖公共 npm + 作者窗口）、jmfederico 插件、VS Code
   扩展（接在研蓝图）。
4. **一切插件的安全默认**：暴露前 permission 确认（opencode `permission.ask` /
   MCP 确认机制 / pi `ctx.ui.confirm`）；默认 `--auth auto`；遵守 `allow-auth-none`
   开关；无认证端口只作临时演示。
5. **统一接口面**：插件/MCP 都走 **daemon JSON-RPC / HTTP API**（S5 的落地
   场景）——CLI 是兜底，公共 npm 后库模式是增强；接口先于实现冻结。

---

## 附录三：插件机制证据

- opencode：`~/.opencode/node_modules/@opencode-ai/plugin/dist/index.d.ts`（PluginInput 含 `$: BunShell`、`serverUrl`、`client`；Hooks 含 tool/event/config/auth/permission.ask/tool.execute.before|after 等）；`packages/opencode/src/config/plugin.ts`（`.opencode/plugin(s)/*.ts` 自动发现 + config `plugin` 数组 npm specifier）；`dist/tool.d.ts`（zod args + ToolContext）。
- pi 扩展：`@earendil-works/pi-coding-agent/docs/extensions.md`（位置/热重载/registerTool/事件/ctx.ui/状态）。
- PiClaw add-on：`docs/settings-and-addons.md`（Settings→Add-ons 目录 rcarmo/piclaw-addons、`pi.runtime.entries`/`pi.web.entries`、`/agent/addons/api/<addon>/<action>`）；`docs/web-pane-extensions.md`（PaneRegistry、openEditor 流程、terminal/vnc 内置 pane）；`docs/addon-runtime-api.md`（`globalThis.__piclaw_runtime` 版本化）。
- jmfederico/pi-web：`docs/plugins.md`（Pi packages/Pi extensions/PI WEB 插件三层、能力边界、信任模型、AI 生成提示词）；`plugin-api.d.ts`。
- cc-connect：`agent/acp/`（ACP/MCP 层）、`docs/bridge-protocol.md`（WebSocket + REST）。
- MCP：opencode 本机配置已用 remote MCP；`service-tunnels-mcp` 为新增薄封装（工具 + 鉴权 + 确认）。
