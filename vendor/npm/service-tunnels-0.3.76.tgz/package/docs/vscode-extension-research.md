# VS Code 插件 — 技术问题深挖与解法（调研结论）

> 承接 [`vscode-extension-plan.md`](vscode-extension-plan.md) 中列出的风险项，
> 本文对每个问题做了**代码级 + 实测级**调研，给出确定解法。全部结论截至
> 2026-08，基于 service-tunnels v0.3.31 源码与 dist 实测。

---

## 0. 结论速览

| # | 问题 | 结论 | 解法 | 验证方式 |
|---|---|---|---|---|
| F1 | ESM 扩展 / ESM 打包 | VS Code **不支持 ESM 扩展**（官方 issue 仍 Open）；esbuild 打 CJS 时 `import.meta` 变空对象，daemon.js 模块加载即崩 | **CJS 扩展 + `await import()` 动态桥接**，不打包库 | 本地实测 bridge.cjs 通过；esbuild 实测报 4 处 empty-import-meta |
| F2 | `process.execPath` 不是 node | portal/token provider spawn node 脚本会失败（扩展宿主里 execPath=VS Code 二进制） | 库加 `nodePath` 选项 + Electron 自动检测，spawn 时带 `ELECTRON_RUN_AS_NODE=1` | qwen-code/Dendron 生产已用此机制；portal 脚本是自包含 ESM（server.mjs） |
| F3 | guardian 在 Node 20 失效 | `import.meta.main` 是 Node v22.18/v24.2 API，Node 20 恒为 false → guardian 静默退出 | 改可移植 main 检测（`argv[1]` 比较）；扩展侧 `guardian:false` + deactivate 清理 | Node 官方文档确认 Added in: v24.2.0, v22.18.0 |
| F4 | 发现不到终端 dev server | **expose 门禁是 `verifyPortOwner`（同 OS 用户），不是进程树**——终端手动启动的端口可直接暴露 | 端口选择器用 Task API / 终端 shell integration 拿 rootPid；expose 无需特殊处理 | expose.ts:293/446 代码确认 |
| F5 | state.json 写冲突 | `updateState` 注释明确 "single writer assumed"，lock-free 读改写 | 扩展用**专属 configDir/cacheDir**，不与 CLI daemon 共享 | state.ts:78-86 代码确认 |
| F6 | schema 未冻结 | ParamSpec 字段已稳定且同构 | 字段只增不减 + `schemasVersion` + dist 形状断言测试 | tunnels.ts:655 确认 |
| F7 | 公共 npm 未迁移 | 发布纪律问题（AGENTS.md 硬规则），非技术 | 内部 .vsix 先行；公共发布列为 Phase 4 前置项 | — |
| F8 | Node 版本门槛 | **dist 运行时下限是 Node 18**（promotion-plan §2.2 实测）；engines 20.19 是策略非硬限 | VS Code 1.98+ 内置 Node 20.19+ 满足；activate 检测兜底 | promotion-plan 实测表 |

---

## F1. ESM 加载 —— 结论：CJS 扩展 + 动态 import 桥接（已实测）

### 事实核查

1. **VS Code 不支持 ESM 扩展**：官方 issue
   [microsoft/vscode#130367](https://github.com/microsoft/vscode/issues/130367)
   "Enable consuming of ES modules in extensions" 状态 **Open**（milestone
   Backlog，on-testplan）；2025-03 的实测博客（jan.miksovsky.com）与
   2024-10 的 devclass 报道均确认"扩展目前只能用 CommonJS"。→ 扩展主入口
   必须 CJS，`"type"` 不能设为 module。
2. **esbuild 打 CJS 不可行（默认配置）**：实测对
   `service-tunnels/dist/index.js` 执行 `build({ format: "cjs" })`——
   **打包"成功"但 4 处 `import.meta` 被替换为空对象**：
   - `daemon.js`（模块加载时执行 `fileURLToPath(import.meta.url)`）→
     **import 即 TypeError 崩溃**（`DAEMON_SERVER` 是顶层常量）；
   - `guardian-spawn.js`（惰性，仅 spawnGuardian 时）→ 路径解析错误；
   - `guardian.js` `import.meta.main` → undefined；
   - `tools.js` `createRequire(import.meta.url)`（惰性）。
   banner shim 可修，但等于给库打补丁，维护成本高。
3. **动态 import 桥接实测通过**（`bridge.cjs`）：

   ```js
   // 扩展（CJS）activate 内：
   const { createServiceTunnels } = await import("service-tunnels");
   ```
   Node 20+ 支持 CJS 里动态 import ESM；库以真实 ESM 从 node_modules
   加载，`import.meta.url` 指向真实文件路径，内部 spawn daemon/guardian/
   portal 脚本路径解析全部正确。实测 providers / sites / discovery /
   shutdown 全通。

### 采用方案

- 扩展 = TS 编译 CJS（`main: dist/extension.js`），**不打包库**；
- 依赖 `service-tunnels` + `justget` 进 node_modules（纯 JS，<1MB），
  vsce 直接打包；
- activate() 异步动态 import，后续所有调用基于返回的实例；
- 若未来 VS Code 开放 ESM 扩展，可无缝切 `"type":"module"`。

---

## F2. spawn Node 子进程 —— 结论：需库侧小改（nodePath + ELECTRON_RUN_AS_NODE）

### 问题定位

库内 **4 处** 用 `process.execPath` spawn node 脚本：

| 位置 | 用途 | 库模式是否触达 |
|---|---|---|
| `src/daemon.ts:89,96` | spawn `daemon-server.js`（daemon 模式） | 否（库模式不需要 daemon） |
| `src/guardian-spawn.ts:29` | spawn `guardian.js`（父进程死亡清理） | 是（默认开启） |
| `src/providers/portal.ts:223` | spawn 自包含 `server.mjs`（登录页+防爆破+TOTP） | **是（Windows 默认认证 provider！）** |
| `src/providers/token.ts:197` | spawn 自包含 `server.mjs`（Bearer token 校验） | 是 |

**VS Code 扩展宿主里 `process.execPath` = VS Code 可执行文件**（Electron），
不是 node。直接 spawn 会失败/打开 VS Code CLI 而非跑脚本。

### 验证过的解法：`ELECTRON_RUN_AS_NODE=1`

Electron 标准机制：设置该 env 后，Electron 二进制以**纯 Node 运行时**行为
运行脚本。VS Code 自身在 fork 扩展宿主时就用了它（
microsoft/vscode#151012 Dendron 崩溃报告确认 "the runtime would launch the
process with ELECTRON_RUN_AS_NODE env variable set"）；生产扩展
（qwen-code #7101 等）也用它来 spawn 自己的 JS CLI。

- portal/token 的 server 脚本是 **自包含 ESM**（`server.mjs`，只 import
  node 内置 `http/fs/crypto`）→ 在 ELECTRON_RUN_AS_NODE 下完美运行，
  无外部依赖问题。
- 已实测：`spawnSync(execPath, [server.mjs], { env: {...process.env,
  ELECTRON_RUN_AS_NODE: "1"} })` 正常输出。

### 库侧改动（小而通用）

1. `ServiceTunnelsOptions` 增加 `nodePath?: string`；
2. 新增 helper `spawnNode(script, args, env)`：

   ```ts
   const isElectronHost = !!(process.versions as { electron?: string }).electron;
   const nodePath = opts.nodePath ?? process.execPath;
   const env = isElectronHost ? { ...process.env, ELECTRON_RUN_AS_NODE: "1" } : process.env;
   ```
3. daemon / guardian-spawn / portal / token 4 处改走 `spawnNode()`；
4. 扩展侧传 `nodePath: process.execPath`（宿主即 VS Code 二进制）。

> 备注：Web 扩展（vscode.dev）不支持桌面能力，本插件声明
> `"extensionKind": ["workspace"]` + 桌面 only 即可，无需兼容 web host。

---

## F3. guardian 与 `import.meta.main` —— Node 20 静默失效（顺手修）

### 事实

- `import.meta.main`：Node 官方文档 **Added in: v24.2.0, v22.18.0**
  （Stability 1.0 - Early development）。Node 20 上为 `undefined`。
- `src/guardian.ts:229`：`if (import.meta.main) { void main(); }` —— guardian
  被 `node guardian.js <args>` 作为主模块 spawn，Node 20 上恒 false →
  **guardian 进程立即退出，不做父进程死亡清理**（静默降级：下次启动时
  按 state.json + role marker 仍会清理孤儿，只是不及时）。
- ⚠️ 这是 promotion-plan §2.2 "dist 支持 Node 20 实测通过"的**盲点**
  （其 grep 清单未含 `import.meta.main`）。

### 修复

```ts
// 可移植 main 检测（Node 12+ 兼容）：
const isMain =
  process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) { void main(); }
```

扩展侧双保险：`createServiceTunnels({ guardian: false })` + deactivate 里
`st.shutdown()`；VS Code 崩溃时由 F2 修复后的 guardian 兜底（若启用）。

---

## F4. 端口发现与暴露门禁 —— 重大修正：门禁是同用户，不是进程树

### 代码事实

- `src/expose.ts:293`（proxy 模式）与 `:446`（tunnel 模式）的端口校验是
  `verifyPortOwner()`：扫描**全系统**监听该端口的进程，任一监听者与
  **当前 OS 用户**（UID/username）相同即通过（`--force` 可绕过）。
- 因此：**集成终端里手动 `npm run dev` 的端口，只要和 VS Code 同用户，
  暴露时端口归属校验直接通过**——原计划 §3.3 的"发现不到终端进程"担忧
  对 expose 流程不成立。进程树 discovery 只影响：
  1. **端口选择器 UX**（列出候选端口）；
  2. 低层 standalone proxy（`st.proxy.create` 无 binding 时的白名单）。

### 端口选择器（UX 层，四层获取）

| 层 | 手段 | 覆盖 |
|---|---|---|
| 1 | `discovery.getPorts({ rootPid: 扩展宿主 pid })` | debug 会话启动的服务 |
| 2 | `tasks.onDidStartTaskProcess` → 拿 task 进程 pid → 以其为 root 再 discovery | Task（Ctrl+Shift+B）启动的服务 |
| 3 | `window.onDidChangeTerminalShellIntegration` + `terminal.processId` → rootPid=终端 pid | 终端手动启动的服务（shell integration，VS Code 1.93+） |
| 4 | 常见端口探测（5173/4173/3000/8000…，仅 127.0.0.1 且非框架端口）+ 手动输入 | 一切边缘情况 |

- Windows 上 discovery 用 PowerShell `Get-CimInstance` 全进程表 + netstat
  构建进程树，可靠性 OK（单次扫描 ~1s，TTL 5s 缓存兜底）。
- expose 前仍建议扩展自己做一次 `verifyPortOwner` 语义提示（同用户校验
  失败时引导 `--force` 或换用户），把库的错误信息直接展示。

---

## F5. state.json 写冲突 —— 确认单写入者，用独立目录解决

- `src/state.ts:78`：`updateState` 注释明确 **"lock-free read-modify-write
  (single writer assumed)"**——并发写入者必互相覆盖（隧道 pid/url 快照）。
- 解法：**扩展使用专属目录**：
  `configDir: ~/.config/service-tunnels-vscode`，
  `cacheDir: ~/.cache/service-tunnels-vscode`（0600 由库 hardenDir 保证）。
  - 与 CLI daemon（`~/.cache/service-tunnels`）零交集 → 无冲突；
  - discovery 缓存按 `pid:marker` 隔离（`discovery.ts cacheKey()`），
    扩展用独立 marker 同样不共享；
  - 若用户显式想复用 CLI daemon（兜底路径），需接受"扩展为唯一写入者"
    约定并在文档中说明。

---

## F6. schema 冻结 —— 字段只增不减 + 版本号 + 形状断言

- `ParamSpec`（tunnels.ts:655）：`key/label/type/description/link/default/
  placeholder/required/options/fixed/value` + i18n key（`labelKey` 等）；
  `TUNNEL_PARAM_SCHEMAS`、`authProviderSchemas`、daemon `schemas` RPC 同构。
- 冻结承诺（对外部客户端与 VS Code 表单渲染器）：
  1. 字段**只增不减**；新增字段必须有默认值语义（缺省不影响旧客户端）；
  2. 导出 `schemasVersion`（tunnel=1 / auth=1），客户端可断言兼容；
  3. test 目录加 **schema 形状快照断言**（防止重构误删字段）；
  4. 破坏性变更走 deprecation 期（如 `fixed` 字段的 value 语义变化），
     与 promotion-plan 的 API 冻结（Phase 2）合并执行。

---

## F7. 公共 npm 迁移 —— 流程阻塞项（非技术，按 AGENTS.md）

- 无需技术调研；按 `AGENTS.md` / `docs/promotion-plan.md` 执行：
  `.npmrc` 凭据移除 + 内部域名/端口/路径清洗 + `npm publish --dry-run`
  核对 files + 干净构建。
- 插件发布顺序：内部 .vsix（`file:` 依赖）→ 公共 npm 上架 → 插件切
  公共依赖 → Marketplace 发布。

---

## F8. Node 版本门槛 —— 实际下限 Node 18（dist），engines 20.19 是策略

- promotion-plan §2.2 **实测**：消费者 dist 路径 Node 18/20/22+ 全通；
  22.19 只是 dev/test 直跑 `src/*.ts`（类型剥离）的要求。
- VS Code 扩展宿主内置 Node：1.98 起 20.19+（满足策略下限），近期版本
  22+。即便更旧的 1.9x（20.14/20.18），dist 也兼容——**门槛实际很低**。
- 扩展侧处理：
  - `engines.vscode` 建议声明 `^1.85.0`（保守）或 `^1.98.0`（对齐
    engines.node 20.19 策略）；具体值 Phase 0 用 VS Code 仓库
    product.json / 扩展宿主实测核对；
  - activate 检测 `process.versions.node`，<20.19 时提示升级或自动切
    daemon 兜底（F2 的 spawnNode 修复后 daemon 也能跑）。

---

## 9. 库侧改动清单（总量很小，~60 行）

1. **`spawnNode()` helper**（新文件或 util）：`nodePath` 选项 +
   Electron 自动检测 + `ELECTRON_RUN_AS_NODE=1`；接入 daemon.ts /
   guardian-spawn.ts / portal.ts / token.ts 4 处。
2. **guardian.ts main 检测**：`import.meta.main` → 可移植 `argv[1]` 比较
   （顺带修复 Node 20 静默失效）。
3. **schema 版本化**：导出 `schemasVersion` + 形状断言测试（可并入
   Phase 3 API 冻结）。
4. （可选）`docs/embedding.md`：写明"非 Node 宿主（VS Code 等）内嵌指南"。

## 10. 扩展侧待办清单

1. CJS + 动态 import 桥接（F1）；
2. activate 检测 Node 版本 / Electron 宿主，传 `nodePath`（F2/F8）；
3. `guardian: false` + deactivate `shutdown()`（F3，spawnNode 修复后可开）；
4. 专属 config/cache 目录（F5）；
5. 端口选择器四层获取（F4）；
6. 暴露默认 `auth auto`、`allowAuthNone` 联动、公开状态显著提示（安全）。

## 11. 已实施补丁（2026-08-07，随本调研落地）

### P1：spawnNode() — Electron 宿主 node 运行时适配（F2 落地）

- **新增 `src/spawn-node.ts`**：
  - `isElectronRuntime()`：`process.versions.electron` 存在（扩展宿主直接）**或**
    `env.ELECTRON_RUN_AS_NODE==="1"`（daemon/guardian 子进程，env 天然继承——
    daemon 路径自动覆盖，无需额外传参）；
  - `spawnNode(nodePath, args, opts)`：`opts.env` 原样保留（PORT/SECRET 等），
    Electron 模式下强制 `ELECTRON_RUN_AS_NODE=1`；`nodePath` 覆盖默认 `execPath`。
- **4 处 `spawn(process.execPath, ...)` → `spawnNode(...)`**：
  - `src/daemon.ts`（foreground + detached 两处）；
  - `src/guardian-spawn.ts`（opts 增加 `nodePath`）；
  - `src/providers/portal.ts` / `src/providers/token.ts`（经 `ctx.nodePath`）。
- **选项接线**：`ServiceTunnelsOptions.nodePath?: string`；
  `ProviderContext.nodePath?: string`；createServiceTunnels → spawnGuardian /
  startDaemon 包装 / AuthRegistry ctx 三处透传。
- **新增 `test/spawn-node.test.mjs`**（3 个测试）：env 透传、nodePath 覆盖、
  env 继承检测。

### P2：guardian 可移植 main 检测（F3 落地）

- `src/guardian.ts`：`import.meta.main`（Node ≥22.18/24.2 才存在）→
  `argv[1]` 与 `fileURLToPath(import.meta.url)` 比较。Node 20 上 guardian 从
  "spawn 后静默退出"恢复为正常工作（父进程死亡清理）。

### 验证记录

- `npm run typecheck` ✓；`npm run build` ✓（dist/spawn-node.js 产出）；
- 新测试 3/3 ✓；全量 `npm test`：**161 pass / 1 fail / 1 skip**——唯一失败
  `test/ssh-expose.test.mjs` 为工作区既有 WIP e2e（SSH 网关新特性，`ssh.key.generate`
  RPC 返回 null / echo 超时，两次运行错误不同），与本次改动无关（spawnNode 在
  纯 Node 下与原 spawn 行为逐位相同）。

> 扩展侧对接：`createServiceTunnels({ nodePath: process.execPath })` 即可；
> portal/token/daemon/guardian 全部自动适配，无需再传 `ELECTRON_RUN_AS_NODE`。

---

## 附：开放问题状态更新

- ❌ VS Code 各版本 → 内置 Node 精确映射：待 Phase 0 真机核对（engines.vscode 精确值）。
- ❌ `ELECTRON_RUN_AS_NODE` 在 VS Code 官方二进制上的行为：P1 已提供机制，仍待
  Extension Development Host 真机冒烟（portal expose）。
- ✅ CJS 动态 import 在扩展宿主 loader 下的解析：本地模拟已通过，真机待验证。
- ❌ Windows discovery 高频延迟：待真机计时。

