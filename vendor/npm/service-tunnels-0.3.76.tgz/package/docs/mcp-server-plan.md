# service-tunnels 作为 MCP Server 发布计划

> 目标：把 service-tunnels 发布为 **MCP（Model Context Protocol）Server**，
> 让 AI 助手（Claude Desktop / Cursor / Windsurf / 各类 coding agent）通过
> 标准 MCP 工具直接执行"暴露本地端口 / 管理隧道 / 发放访问凭证"，把
> "AI 写了代码 → AI 一键把 dev server 发给你验收"变成一条自然的工作流。
> 本文是计划文档：架构选型、协议层实现、工具映射、安全设计（LLM 即操作员）、
> 打包发布、里程碑与风险。
>
> 姊妹篇：[`vscode-extension-plan.md`](vscode-extension-plan.md)（宿主内嵌库）、
> [`idea-plugin-plan.md`](idea-plugin-plan.md)（Java 移植内嵌）。本方案与其共享
> 同一套架构原则（认证统一在本地端口侧、D4 零转发、schema 驱动、默认即安全、
> daemon RPC 冻结契约），差异在**接入形态**：MCP Server 是独立 Node 进程，天然
> 适合复用现有 **daemon JSON-RPC 契约（L3 层）**，做一层极薄的协议适配器。

---

## 0. 结论摘要

1. **推荐架构 = MCP Server 进程内嵌库 + daemon 托管（自动拉起、RPC 透传）**。
   MCP Server 本身就是 Node ≥20.19 进程，库模式内嵌可行；但**隧道必须挂在
   daemon 下**而非 MCP 会话进程下——Claude Desktop 等客户端会话结束会杀掉
   MCP 子进程，会话级进程内的隧道随之中断；daemon 是唯一 state 持有者
   （CLI / `sts ui` / MCP 共享同一份 state.json，单一写者，无写冲突）。
2. **MCP Server 是"薄协议适配器"**：不移植、不重写任何核心逻辑。所有工具
   参数直接进现有 daemon RPC 边界（fail-closed 校验、dangerous 门禁、
   auth-none 禁令、autheliaReloadCmd 阻断全在 daemon 层已有），MCP 层只做
   参数→RPC 的映射与**面向 LLM 的额外安全门**（§6）。
3. **schema 驱动是最大卖点**：启动时拉取 `schemas` RPC（隧道参数 + provider
   参数 + authNone 开关），动态注入工具描述与 inputSchema——新增隧道类型 /
   新增 provider / env 自定义隧道，MCP 层**零代码升级自动可见**。
4. **LLM 即操作员，安全默认值比 CLI 更严**：`auth: none` 默认拒绝（env
   显式放行）、`type: command` 隧道默认拒绝（env 显式放行 + `dangerous:
   true`）、破坏性操作（stop-all / 删用户 / 吊销 token / 删 site）要求显式
   `confirm: true` 参数——MCP 没有人类确认对话框，门禁要落到协议参数上。
5. **发布受 AGENTS.md 约束**：内部阶段仅内网镜像分发；上公共 npm / MCP
   注册表（Smithery / mcp.so / Glama / 官方 registry PR）前必须完成清洗
   （promotion-plan.md），且依赖 service-tunnels 公共 npm 迁移先行。

---

## 1. 定位与用户故事

**一句话**：给任何 MCP 客户端装上 `service-tunnels-mcp`，AI 就能替用户把本地
dev server 暴露出去（tunnel / proxy / both，默认带认证）、管理隧道生命周期、
发放 Bearer token 供机器访问——全程一条自然语言指令。

**核心用户故事**：

| 用户 | 场景 |
|---|---|
| 前端开发者 + AI | AI 起好 Vite dev server → 用户说"把这个 5173 暴露给客户看" → MCP 工具自动发现端口、拿带认证公网 URL |
| 全栈联调 + AI | AI 改后端 → 用户说"重新暴露 3000" → 停旧暴露、起新暴露、URL 更新 |
| 回调调试 + AI | AI 说"我需要一个公网 HTTPS 回调地址" → `sts_port_detect` 判断协议 → 起 natapp/ngrok 隧道 → URL 直接填进配置 |
| CI/机器访问 | AI 生成 `sts_auth_token_create` → 把 Bearer token 写进工作流脚本，机器客户端免登录页 |
| 团队分享 | AI 执行 `sts_auth_user_add` 建团队账号（portal/basic + 2FA），把登录 URL 发给同事 |
| 演示/教学 | AI 临时暴露演示站 → 结束后 `sts_stop_exposure` 一键收回，无残留进程 |

**非目标（v1 前）**：不做远程 MCP（SSE/HTTP 暴露控制面）——远程控制隧道 =
巨大安全暴露面，v1 只做 stdio；不做托管账号体系；不接管用户已有
nginx/Authelia 部署。

---

## 2. 为什么是 service-tunnels（而不是 AI 直接调 ngrok CLI）

| 维度 | AI 直调 ngrok CLI | service-tunnels MCP |
|---|---|---|
| 隧道多样性 | 只 ngrok（要账号） | 9 种：cloudflared（零账号）/ bore（自建零账号）/ natapp（CN）/ ssh / serveo / frpc / localtunnel / ngrok / command |
| 认证 | 无（或 Edge OIDC 要钱） | portal（零二进制）/ basic / authelia / oauth2-proxy + 2FA + Bearer token，**默认 auto 开箱即安全** |
| 中国网络 | 差 | natapp + 下载镜像（ghproxy/npmmirror）优先 |
| 进程发现 | 无 | `sts_discover` 列出用户 dev server 端口（进程树 + 常见端口探测） |
| 清理 | 手动、易漏 | guardian + state.json：MCP 会话退出/崩溃，隧道仍由 daemon 持有，随时可查可停 |
| 校验 | 手写 shell，易注入 | daemon RPC 边界全量 fail-closed（ssh 选项注入 / frpc INI 注入 / 端口归属 / 路径穿越） |
| 参数自描述 | 靠 man page | `schemas` RPC → 工具描述自动带参数字段，LLM 不会瞎猜参数名 |
| 状态一致性 | 无 | CLI / UI / MCP 共享 daemon 单一 state.json，无写冲突 |

---

## 3. 架构选型

### 3.1 三种接入方式对比

| 方式 | 形态 | 优点 | 缺点 |
|---|---|---|---|
| **A. MCP 进程内嵌库（会话级）** | MCP Server 进程内 `createServiceTunnels()`，隧道挂在 MCP 进程下 | 无 daemon 依赖；实现最直接 | **会话结束（客户端杀 MCP 子进程）隧道即断**；与用户自己跑的 CLI daemon 状态不互通；多客户端并存时 state.json 写冲突风险 |
| **B. 每次调用 spawn CLI** | MCP 工具 = 拼 `sts ...` 命令执行 | 最薄 | 每操作一个子进程；输出解析脆弱（`--json` 要逐命令对齐）；LLM 参数→CLI 参数映射容易错 |
| **C. daemon RPC 透传（推荐）** | MCP Server 启动时保证 daemon 在跑（库内 `daemon.start` 自动拉起，或 `sts daemon start`），全部工具走现有 newline JSON-RPC | 复用冻结契约（vscode 方案 L3 层）零重写；**隧道生命周期独立于 MCP 会话**；CLI/UI/MCP 状态一致；MCP 层 ≤300 行 | 需要 MCP 进程能 spawn daemon（Node 自带，无问题）；依赖 daemon RPC 契约冻结 |

### 3.2 推荐：C 为主（daemon 托管），A 为兜底

```
┌────────────── MCP 客户端（Claude Desktop / Cursor / …） ──────────────┐
│  stdio JSON-RPC 2.0（newline 分隔，与 daemon 帧格式同构）              │
└──────────────────────────────┬───────────────────────────────────────┘
                               ▼
┌────────────── service-tunnels-mcp（独立 Node ≥20.19 进程） ────────────┐
│  MCP 协议适配器（≤300 行）：initialize → tools/list → tools/call        │
│   │  工具注册表 = daemon 方法面 + LLM 安全门（§6）+ schema 注入（§5）   │
│   │  spawn/attach：daemon 不在 → 库内拉起（复用 spawn-node/daemon.ts） │
│   ▼                                                                  │
│  requestDaemon()（库自带客户端，unix socket / Windows TCP+secret）    │
└──────────────────────────────┬───────────────────────────────────────┘
                               ▼
┌────────────────── daemon（state 唯一持有者） ──────────────────────────┐
│  tunnel.* / expose / auth.* / proxy.* / site.* / schemas / ssh.domain.*│
│  与 CLI、`sts ui` 共享 configDir/state.json（单一写者，无冲突）        │
└───────────────────────────────────────────────────────────────────────┘
```

- **为什么隧道必须挂 daemon**：MCP stdio 子进程的生命周期 = 客户端会话。
  Claude Desktop 关掉对话、Cursor 重启，MCP 进程被 kill——若隧道在 MCP 进程
  内，用户拿到的 URL 悄悄失效。daemon 托管后：MCP 退出不影响隧道；重新连上
  的 MCP 会话（或 CLI）随时 `sts_status` 查、`sts_stop_exposure` 停。
- **兜底 A**：daemon 拉起失败（极端环境）时，MCP Server 降级为进程内库模式，
  工具面不变（同一套参数），仅 URL 生命周期变为会话级——日志里显著警告。
- **两种形态暴露相同的最小接口集**（§4.4），工具参数签名一致，上层 LLM
  不感知差异。

### 3.3 进程模型与端口发现（MCP 上下文的关键约束）

- `sts_discover` 默认以 MCP Server 进程 pid 为根扫后代：
  - ⚠️ 用户 dev server 通常跑在**终端**里，不在 MCP 客户端进程树（更不在
    MCP Server 进程树）下 → discovery 直接扫不到是常态。
- **但 expose 的门禁不是进程树，是 `verifyPortOwner`（同 OS 用户）**：
  用户手动 `npm run dev` 的服务，只要与 MCP Server 同用户，暴露时端口归属
  校验直接通过——AI 只要拿到端口号就能暴露，不依赖进程树（vscode 方案
  research F4 同一结论）。
- **端口选择器（工具侧三层）**：
  1. `sts_discover`（MCP Server rootPid）—— 覆盖客户端/调试器后代场景；
  2. 常见开发端口探测兜底（5173/4173/3000/8080/4200/9000…，仅 127.0.0.1）；
  3. `sts_port_detect <port>`——用户/AI 直接给端口，探测协议（http/https/tcp）
     并返回可用隧道类型，再决定 `--tunnel` 与 `--mode`。
- 暴露对象 = 端口号，与语言/框架无关——AI 对任何 dev server 都成立。

---

## 4. MCP 协议层实现

### 4.1 传输与 SDK 选型

| 方案 | 优点 | 缺点 |
|---|---|---|
| **手写极简 stdio JSON-RPC 适配器（推荐 v1）** | 零新依赖（维持 justget-only）；**帧格式与 daemon 同构**（newline 分隔 JSON-RPC 2.0），协议代码可直接借鉴 daemon-server.ts 的 `readLine` 循环 | MCP 规范新特性（annotations / structured content / sampling）要自己补 |
| 官方 `@modelcontextprotocol/sdk`（Node TS） | 规范演进跟得上；工具/资源/采样一等公民 | 破坏"零/极低依赖"；与仓库 justget-only 精神冲突；SDK 版本漂移 |

**建议**：v1 用手写适配器（initialize / tools/list / tools/call / ping +
`notifications/initialized` 握手，共 ~250 行），对齐零依赖精神；工具输出用
`content: [{ type: "text", text: <JSON> }]` 单一文本块（LLM 最稳的形态）；
v2 若需要 resources（隧道日志流）或 sampling 再评估官方 SDK。决策记录进
Phase 0 spike。

### 4.2 与 daemon 的帧复用

daemon 已是 **newline 分隔 JSON-RPC 2.0**（`daemon-server.ts` `readLine` +
`JSON.parse`），MCP 是同一帧格式。因此：

- 入站（客户端 → MCP）：解析 `{ id, method: "tools/call", params: { name, arguments } }`；
- 出站（MCP → daemon）：`requestDaemon()`（库自带客户端）已是同构调用，
  方法名 + 参数**原样透传**（§4.4 工具名→daemon 方法名 1:1 映射）；
- 唯一差异：MCP 方法名是 `tools/list` / `tools/call`，daemon 方法是
  `tunnel.list` / `expose` 等——MCP 层维护一张 1:1 工具表即可，无协议翻译。

### 4.3 长耗时操作与超时

- `tunnel.start` / `expose` 可能耗秒级（二进制下载、ngrok 启动、认证拉起）：
  默认 MCP 客户端工具超时（如 60s）内通常能返回；超时场景靠**幂等重查**——
  `sts_status` / `sts_tunnel_list` 幂等，LLM 重试即可。
- v2 可选：向客户端发 `notifications/progress`（需先协商 `progressToken`），
  或把 `expose` 拆成"提交 + `sts_expose_status` 轮询"两步工具。

### 4.4 最小工具集（v1，工具名 ↔ daemon 方法 1:1）

| MCP 工具 | daemon 方法 | 说明 |
|---|---|---|
| `sts_discover` | `discover` | 发现进程树端口（force 刷新） |
| `sts_port_detect` | `port.detect` | 端口协议探测 + 可用隧道类型（暴露前决策用） |
| `sts_expose` | `expose` | 核心：`port` + `mode`/`tunnel`/`auth`/`site`/`tunnelParams`/`providerParams` |
| `sts_stop_exposure` | `tunnel.stop("expose-<port>")` | 暴露创建 `expose-<port>` 隧道（TCP 为 `expose-<port>-tcp`）；按 port 解析名字后停掉并清理（需 `confirm: true`） |
| `sts_status` | `internal.list` + `tunnel.list` | 当前暴露/隧道/URL 汇总（**幂等，可反复查**） |
| `sts_tunnel_list` / `sts_tunnel_add` / `sts_tunnel_start` / `sts_tunnel_stop` / `sts_tunnel_remove` | `tunnel.list/add/start/stop/remove` | 隧道生命周期（`stopAll` 走 confirm 门） |
| `sts_proxy_status` / `sts_proxy_bindings` | `proxy.status` / `proxy.bindings` | proxy 模式（本地虚拟主机） |
| `sts_auth_user_list` / `sts_auth_user_add` / `sts_auth_user_set_password` / `sts_auth_user_remove` | `auth.user.*` | 站点用户管理 |
| `sts_auth_token_create` / `sts_auth_token_list` / `sts_auth_token_revoke` | `auth.token.*` | Bearer token（**create 只回显一次**，MCP 层不落日志） |
| `sts_schemas` | `schemas` | 拉取当前隧道/provider 参数 schema（LLM 自查询用，配合 §5 注入） |
| `sts_site_list` / `sts_site_add` / `sts_site_remove` | `site.*` | 认证域管理 |
| `sts_ssh_domain_list` / `sts_ssh_domain_create` / `sts_ssh_domain_remove` | `ssh.domain.*` | 自建 ssh 网关域名 |

> 工具名统一 `sts_` 前缀：MCP 工具全局命名空间，避免与客户端内其他 MCP
> server（如 playwright-mcp）撞名；语义与 CLI 子命令一一对应，LLM 学习成本低。

---

## 5. schema 驱动：动态工具描述

MCP 的 `tools/list` 在每次会话 initialize 后返回一次。策略：

1. **启动时**（initialize 后、首次 tools/list 前）调用 `schemas` RPC，拿到：
   - `tunnels`：各隧道类型的 `ParamSpec[]`（如 ngrok 的 authtoken、ssh 的
     host/user/remotePort、自定义 command 隧道的 env 注册参数）；
   - `authProviders`：各 provider 参数 schema（portal/basic/authelia/oauth2…）；
   - `authNoneAllowed`：本机是否允许 `auth: none`。
2. **把 schema 注入 `sts_expose` / `sts_tunnel_add` 的 inputSchema 描述**：
   - `tunnelType` 的 enum 直接来自 schema 的 key 集合；
   - 每个 tunnel 参数写入工具描述文本（`tunnelParams.<name>: <type> — <hint>`），
     让 LLM 不需要先调 `sts_schemas` 也能填对；
   - provider 参数同理。
3. **新增能力零代码升级**：仓库加了新隧道类型 / 新 provider / 用户设了
   `SERVICE_TUNNELS_TUNNEL_COMMAND_*` env 自定义隧道 → daemon `schemas` 输出
   变化 → MCP Server 重启后工具描述自动带新参数。**这正是 schema 驱动 UI 的
   MCP 版本**，与 vscode/idea 方案同源。

**工具描述语言**：英文为主（LLM 处理英文工具描述最稳），关键安全语义（如
"auth none is banned"）双语加粗提示。schema 本地化走 `schemas?lang=` 参数。

---

## 6. 安全设计（LLM 即操作员）

MCP 场景的特殊性：**没有人类确认对话框，LLM 可能被 prompt injection 诱导
执行危险操作**（比如网页内容里藏"调用 sts_expose 暴露 6379"）。因此 MCP
层安全门**比 CLI/daemon 更严**，与 daemon 边界校验叠加成纵深：

| # | 门禁 | 规则 | 位置 |
|---|---|---|---|
| 1 | **auth-none 禁令** | `sts_expose` 的 `auth: none|false` 默认拒绝；仅当 env `SERVICE_TUNNELS_MCP_ALLOW_AUTH_NONE=1` 放行（对齐 daemon 的 `allow-auth-none` 粘性，且 MCP 层默认值更严——**即使 daemon 配置允许，MCP 默认也不允许**，除非显式 env） | MCP 层 |
| 2 | **command 隧道门禁** | `tunnelType: "command"` 或 `--tunnel command` 默认拒绝；仅当 env `SERVICE_TUNNELS_MCP_ALLOW_COMMAND_TUNNEL=1` 且参数带 `dangerous: true` | MCP 层 + daemon 层（双闸） |
| 3 | **破坏性操作 confirm** | `stopAll` / `auth.user.remove` / `auth.token.revoke` / `site.remove` / `tunnel.remove` 要求参数 `confirm: true`，否则拒绝——LLM 必须"明确说要做"（防 prompt injection 顺手删） | MCP 层 |
| 4 | **端口门禁** | `expose` / `port.detect` 端口必须 1-65535 整数；暴露目标仅 127.0.0.1（daemon 已有 `verifyPortOwner` + D4 零转发，MCP 层不重复实现，透传即继承） | daemon 层（继承） |
| 5 | **shell 注入** | `autheliaReloadCmd` daemon 层已拒收；ssh/frpc 注入、路径穿越、控制字符由 `validateTunnelConfig` fail-closed（继承） | daemon 层（继承） |
| 6 | **机密不外泄** | token 只在 `sts_auth_token_create` 返回一次；MCP Server **禁止把 daemon 响应写进自己的日志**（stdout 只有 MCP 帧）；工具描述/错误信息不得含 configDir 绝对路径（内部路径如 `/home/wind` 在清洗后不存在） | MCP 层 |
| 7 | **只读模式** | env `SERVICE_TUNNELS_MCP_READONLY=1`：只注册 discover / port_detect / status / schemas / tunnel_list / proxy_status 等只读工具——不可信宿主（共享电脑、CI 沙箱）的最小权限形态 | MCP 层 |
| 8 | **IPC 认证** | MCP → daemon 复用现有 unix socket / TCP+secret（`x-service-tunnels-auth`），不新增通道 | daemon 层（继承） |
| 9 | **无遥测** | MCP Server 不上报任何数据；错误输出只回给调用它的 LLM 会话 | MCP 层 |

**工具参数即门禁的语法**：所有危险操作把确认做成**显式参数**而非"LLM 判断"，
例如 `sts_stop_exposure(port: 5173, confirm: true)`——prompt injection 只给
LLM 文本，伪造不了 LLM 自己打出的 `confirm: true`（LLM 需在上下文中明确表达
意图才输出它），这是 MCP 场景下"人在环"的合理替代。

---

## 7. 打包与发布

### 7.1 仓库形态

- **同仓独立包**：`mcp/` 目录（或 `extensions/mcp/`），独立 `package.json`
  （name `service-tunnels-mcp`），依赖 `service-tunnels`（file: 或内网镜像
  link）；不并入主包 files 清单（主包保持"库 + CLI"，MCP 是独立分发面）。
- bin：`service-tunnels-mcp` → `dist/server.js`。
- 客户端配置示例写入 README：
  - Claude Desktop `claude_desktop_config.json`：
    `"service-tunnels": { "command": "npx", "args": ["-y", "service-tunnels-mcp"] }`
  - Cursor `mcp.json` / Windsurf 同理。
- 环境变量注入（§6 门禁开关）写在 README 显眼处：`SERVICE_TUNNELS_MCP_READONLY`、
  `SERVICE_TUNNELS_MCP_ALLOW_AUTH_NONE`、`SERVICE_TUNNELS_MCP_ALLOW_COMMAND_TUNNEL`。

### 7.2 内部 → 公共（AGENTS.md 硬约束）

| 阶段 | 依赖 | 分发 |
|---|---|---|
| 内部 | service-tunnels 内网镜像（npm.alot.pw）；MCP 包 `file:` 引用主包 | 内部宿主（embedder）用；不走公共 registry |
| 公共（阻塞项） | ① service-tunnels 公共 npm 迁移清洗（promotion-plan.md，含 API 冻结）→ ② MCP 包自身清洗 | 公共 npm + MCP 注册表 |

MCP 包自身的**清洗 checklist**（与主包同规，AGENTS.md §发布策略）：
- 无 `alot.pw` / `pi.alot.pw`、无内部端口（30141/30142/57442）、无 `/home/wind`
  路径、无内部应用名（pi-web → 泛化 "embedder / 宿主应用"）；
- 工具描述/README 示例不得出现内部域名与宿主名；
- 依赖主包的 `>=x.y.z`（公共版本）而非 file: 引用；`npm publish --dry-run`
  核对 files 清单。

### 7.3 MCP 生态注册（公共阶段）

- 提交官方 registry：`modelcontextprotocol/servers`（README 列表 + PR）；
- 第三方聚合站：Smithery / mcp.so / Glama / PulseMCP（README + 截图 +
  使用示例）；
- 与主包文档互链：主包 README 加 "AI 助手接入（MCP）" 一节。

---

## 8. 里程碑与工作量（单人）

| Phase | 内容 | 工时 | 产出 |
|---|---|---|---|
| **0** | spike：MCP stdio 帧与 daemon 帧复用验证、`requestDaemon` 从 MCP 进程连通性、schemas 注入工具描述可行性、Claude Desktop + Cursor 两个客户端的握手/超时行为 | 1 天 | 技术结论 + SDK 选型决策 |
| **1** | MCP Server MVP：手写适配器 + daemon 自动拉起 + §4.4 核心工具（discover/expose/stop/status/tunnel 生命周期/token）+ §6 全部安全门 + README（安装/客户端配置/门禁 env） | 2-3 天 | 可用的 `service-tunnels-mcp`，内部宿主实测 |
| **2** | schema 驱动动态工具 + 只读模式 + 双语描述 + 长操作幂等重查优化（§4.3） | 1-2 天 | 参数自描述的完整工具面 |
| **3** | 发布：主包公共 npm 迁移（前置阻塞项）→ MCP 包清洗上公共 npm → MCP 注册表提交（§7.3） | 2 天（不含迁移） | 公共 `service-tunnels-mcp` v1.0 |
| **4** | v2 前瞻：progress 通知、SSE/HTTP 远程模式（挂认证，评估）、resources 隧道日志流 | 待定 | 后续迭代 |

**合计：spike + MVP ≈ 1 周，schema 驱动 + 发布另计 1 周（不含公共 npm 迁移阻塞项）。**

---

## 9. 风险与开放问题

| # | 风险 | 影响 | 对策 |
|---|---|---|---|
| 1 | MCP 规范演进（tools annotations / structured content / sampling 变动） | 手写适配器跟不上 → 客户端报 schema 错误 | 冻结 v1 最小实现；升级 SDK 前做双客户端回归（Claude Desktop + Cursor）；规范大版本变更时评估切官方 SDK |
| 2 | LLM 参数幻觉（拼错 tunnelType、参数名） | 暴露失败/误操作 | fail-closed 校验（继承）；schema 注入工具描述（§5）；工具描述里给 enum 与示例值 |
| 3 | prompt injection 诱导危险操作（网页内容让 LLM 暴露端口/删用户） | 数据暴露/破坏 | §6 门禁全部落成**显式参数**（confirm:true / env 放行）；只读模式兜底；auth-none 默认禁 |
| 4 | MCP 会话退出导致 URL 失效 | 用户拿到的链接悄悄断 | daemon 托管（§3.2 C 为主）；README 明示"隧道生命周期 = daemon 而非 MCP 会话"；断连可 `sts tunnel list` 续查 |
| 5 | 多个 MCP 客户端（Claude + Cursor 同时）共享 daemon | 状态互踩 | daemon 单一写者天然串行；工具幂等（status/list 可反复查）；不做并发 mutex（daemon 层已够） |
| 6 | 发现覆盖度低（dev server 在终端，不在 MCP 进程树） | AI 找不到端口 | `verifyPortOwner` 门禁不依赖进程树（§3.3）；port_detect + 手动端口三层兜底 |
| 7 | 公共 npm 迁移未完成（AGENTS.md 硬阻塞） | 无法公共分发 | 内部镜像先行；公共发布列入 Phase 3 前置项，勿跳步 |
| 8 | token 在 LLM 上下文里可见 | 会话日志泄露凭证 | create 只回显一次；工具描述提示"token 仅此一次，复制后勿再查询"；`sts_auth_token_revoke` 可随时吊销 |
| 9 | 客户端工具超时（暴露耗时 > 客户端 timeout） | LLM 误判失败重试 | 幂等工具 + README 建议配置长 timeout（Claude Desktop `--timeout` 或客户端 timeout 设置）；v2 progress 通知 |

**开放问题（需 spike 确认）**：
- Claude Desktop / Cursor 对 stdio 工具超时的默认值与可配置性（决定是否必须
  拆 `expose` 为提交+轮询两段）；
- 手写适配器对新规范特性的兼容窗口（哪个版本客户端开始强制 annotations /
  structured content，需不需要提前支持）；
- MCP Server 与 CLI daemon 并存时，daemon 已由用户 `sts daemon start` 启动的
  场景（attach 已有 daemon 而非再 spawn——`requestDaemon` 现有逻辑是否已
  支持 attach，还是要补 ping-失败才 spawn 的策略）；
- 是否在 Phase 3 顺带把 MCP Server 也做成 **`sts mcp` 子命令**内嵌进 CLI
  （`service-tunnels mcp` 直接当 MCP server 跑，用户少装一个包）——这需要
  主包依赖面扩大（加入 MCP 适配器代码），与"主包保持库+CLI"的边界权衡。

---

## 10. 参考

- [`docs/design.md`](design.md) — 架构 / 模块 / 认证 provider 模型（权威依据）
- [`docs/sites-design.md`](sites-design.md) — 站点（认证域）隔离 + proxy 暴露模式
- [`docs/vscode-extension-plan.md`](vscode-extension-plan.md) — 姊妹方案（L3 daemon IPC 协议、最小接口集、schema 冻结、research F2/F4 结论）
- [`docs/idea-plugin-plan.md`](idea-plugin-plan.md) — 姊妹方案（桥接→内嵌过渡模式）
- [`docs/token-auth-design.md`](token-auth-design.md) — Bearer token 认证方案
- [`docs/promotion-plan.md`](promotion-plan.md) — 公共发布前置（AGENTS.md 阻塞项、API 冻结）
- [`src/daemon-server.ts`](../src/daemon-server.ts) — daemon JSON-RPC 方法面（MCP 工具的直接映射源，newline 帧格式）
- [`src/index.ts`](../src/index.ts) — `createServiceTunnels` / `requestDaemon` 库入口
- MCP 规范：https://modelcontextprotocol.io/specification（stdio transport / tools / notifications）
