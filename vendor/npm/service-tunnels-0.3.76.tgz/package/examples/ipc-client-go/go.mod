module github.com/example/service-tunnels-examples/ipc-client-go

go 1.21
