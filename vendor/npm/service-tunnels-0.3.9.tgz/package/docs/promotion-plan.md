# service-tunnels 评审结论与推广计划（2026-08-06）

> 本文件是 2026-08-06 对 service-tunnels（v0.2.42）的独立评审产出：
> 实现/设计评价、发布阻塞项与具体建议（含可执行证据）、竞品、推广计划、
> 收益路径与风险清单。事实部分均已在本仓库与公共 npm 实测核验。

---

## 0. 结论摘要

1. **实现与设计质量高**：认证/隧道解耦、D4 零转发、发现缓存即白名单、
   schema 驱动 UI、CN 镜像适配——均属同量级开源项目 top 级水准。
2. **值得推广**，但先修 4 个发布阻塞项：包名/别名、Node engines、
   SECURITY.md、英文 README（详见 §2）。
3. **直接竞品无对位者**（隧道编排 × 认证编排 × 进程发现 × 可嵌入 × CN 友好
   的组合是空位），但"组合面宽"同时是维护成本风险。
4. **收益要等 6-18 个月**：嵌入式商业授权（路径 A）比托管 SaaS（路径 B）
   更现实。
5. 最大风险不是技术，是**过早公开化**：API 未冻结 + 无安全审计就上公共 npm，
   破坏性升级与信任问题会抵消全部技术优势。

---

## 1. 实现与设计评价

### 1.1 项目事实

| 维度 | 事实 |
|---|---|
| 版本 | 0.2.42（62 个版本），当前发布在私有 registry |
| 代码量 | ~11K 行 TS（27 源文件）+ 1,675 行中文设计文档 |
| 运行时依赖 | 仅 `justget`（下载竞速，engines >=18） |
| 测试 | 99 个测试 98 通过（e2e 真实隧道多被 skip） |
| 开发周期 | 3 天（08-04 → 08-06），46 commit，单人主力 |
| 嵌入方 | 内部宿主应用（`package.json` 依赖 `file:` 本地包，import 走 dist） |

### 1.2 设计亮点

- **"认证统一在本地端口侧，隧道是纯透传通道"**：全项目最正确的抽象，
  9 隧道 × 4 provider × 3 模式的正交组合复杂度被这一原则压住。
- **安全默认值是代码实现而非口号**：D4 零转发（未 enroll → 403）、
  代理目标写死 127.0.0.1、SSRF 防护（URL 拼接绕过 authority 注入）、
  prototype-pollution 防护、端口归属校验（`verifyPortOwner`）、
  fail-closed 认证判定、配置写前 validate + 回滚。
- **schema 驱动 UI**（`ParamSpec`/`TUNNEL_PARAM_SCHEMAS`）：新增隧道/provider
  无需客户端改代码——面向"被嵌入"场景的正确投资。
- **CN 适配深度**：Gitee/ghproxy/npmmirror 镜像、natapp 国内隧道、
  cloudflared SRV 探测失败 pin edge。
- **进程模型完整**：库模式进程内单例 vs CLI daemon IPC；guardian + pid-registry
  防孤儿进程。
- **文档质量 top 5%**：设计决策（D1-D4）、资源预算（实测 110MB）、
  误报风险声明齐全。

### 1.3 问题与风险

| # | 问题 | 影响 | 处置 |
|---|---|---|---|
| 1 | Node >= 22.19.0 硬门槛 | 砍掉 20/18 LTS 用户 | **可降级**，证据见 §2.2 |
| 2 | 测试面 99 个，远小于 324 组合矩阵 | 未覆盖组合的回归风险 | e2e CI 矩阵（Phase 3） |
| 3 | 二进制依赖重（nginx+authelia+redis ≈ 110MB 常驻） | 轻量用户劝退 | 文档明示 basic/portal 路径仅需 nginx 20MB |
| 4 | 包名/别名风险 | 公共 npm 抢注、`st` 冲突（月下载 130 万） | §2.1 |
| 5 | 3 天 62 版本，API 变动中 | 过早推广积累破坏性升级差评 | 冻结 API（Phase 2） |
| 6 | 无独立安全审计 / SECURITY.md / CVE 流程 | 信任型工具的最大短板 | §2.4 |
| 7 | 文档以中文为主 | 全球推广受限 | §2.5 |
| 8 | Windows 能力差异 | 预期管理问题 | §2.3（已修正） |

---

## 2. 发布阻塞项与建议

### 2.1 包名与 `st` 别名（优先级：最高，立即处理）

**实测（2026-08-06 公共 npm registry）：**

```
service-tunnels → HTTP 404（可用，无人占用）
service-tunnel   → HTTP 200（已被占用）
st               → HTTP 200（已被占用）
tunnels-st       → HTTP 404（可用）
```

**建议：**

1. **立即抢注公共 npm 的 `service-tunnels` 名称**（当前 404 可用）。
   上公共 npm 前先做一次 `npm publish --dry-run` 核对 files 清单
   （当前 `files` 含 dist/src/docs/examples，dist 需重新 build 确保与 src 同步）。
   同时把 GitHub/Gitee 仓库从 `service-tunnels-internal` 更名为
   `service-tunnels`（公开前先处理仓库内敏感信息：`.npmrc` 含 publish 凭据
   ——**必须移除并加入 .gitignore**，改用环境变量注入；`docs/` 若含内部
   路径/账号信息需清理）。
2. **`st` 别名处理（实测：`st` 必须弃用，改用 `sts`）：**

   **2026-08-06 公共 npm 实测——注意区分两个维度：**

   - **包名占用**（registry 唯一性）：只决定“能否用该名称发布包”，与本包
     `service-tunnels` 无关，不影响命令别名；
   - **bin 冲突**（真正决定别名可用性）：只发生在“用户恰好全局安装了另一个
     也提供同名命令的包”时（npm 后装覆盖 + 警告）——评估依据是**同名 bin
     的全局安装量**：

   ```
   候选 bin   对应 npm 包的 bin    该包下载/月        bin 冲突风险
   st        st (bin/server.js)  1,296,663（活跃）   极高——弃用
   sts       sts (bin/sts.js)    788（2022 废弃）     ≈ 0——选用
   stl       无 bin（纯库）       2,134（2022 废弃）  零——但记忆关联弱
   ```

   `st` 的冲突是双重的：npm 上 `st` 是**月下载 130 万的活跃静态服务器包**
   （全局安装者众多，`npm i -g` 会静默覆盖用户已有的 `st`），系统层还有
   suckless st 终端模拟器占用 `/usr/local/bin/st`。**结论：`st` 别名不可发布，
   改用 `sts`**（`sts` 包的 bin 虽同名，但下载量 788/月、2022 年废弃，
   全局安装者趋零，实际冲突概率趋零）：
   - 与 `st` 仅差一个字符（service-tunnels → `st` + `s`），记忆迁移成本最低；
   - AWS `sts`（Security Token Service）是 `aws sts` 子命令、不占独立 bin，
     无直接冲突，认知混淆影响很小；
   - **保留运行时守卫**：CLI 入口首行 `fs.realpathSync(process.argv[1])`
     解析后若不指向本包 `dist/cli.js`（PATH 中先命中别的 `sts`），打印
     提示并退出，防止静默抢占；
   - README 新增“别名冲突”说明：npm 全局 bin 是“后装覆盖”语义，用户环境
     已有同名命令时用全名 `service-tunnels`。

   > 已落地：`package.json` bin 为 `service-tunnels` + `sts`（不发布 `st`）。

   > 已落地：`package.json` bin 为 `service-tunnels` + `sts`（不发布 `st`）。
3. **npm description / keywords 保持英文**（已满足），便于搜索。

### 2.2 Node engines 降级（结论：可以，实测上限 18，推荐 20）

**证据链（已核验 + 实测）：**

1. **dist 编译产物无 Node 22 专属 API**：全量 grep 确认无
   `import.meta.dirname` / `Promise.withResolvers` / `Array.prototype.at` /
   `node:sqlite` / import attributes 等；3 处 `import.meta.url` 用法
   （daemon/tools/guardian-spawn）均为 Node 12+ 就支持的基础能力。
2. **依赖链不构成门槛**：`justget` engines `>=18.0.0`。
3. **生产消费路径走 dist**：内部宿主应用通过 `"service-tunnels"` 包根导入
   （exports `"."` → `dist/index.js`），不经 src。
4. **22.19 的真实来源是仓库自身 dev/test**：源码用 `.ts` 相对导入
   （`./discovery.ts` 等），直接运行需要 Node 22.18+ 的**默认类型剥离**；
   `npm test`（`node --test` 直跑 `src/*.ts`）同样依赖它。这是开发要求，
   不是消费者要求。
5. **实测（2026-08-06，下载 Node 18.20.8 / 20.19.4 二进制冒烟）：**

   | 路径 | Node 18 | Node 20 | Node 22.18+ |
   |---|---|---|---|
   | 消费者 dist（导入 / CLI / `fetch` 下载） | ✅ 实测通过 | ✅ 实测通过 | ✅ |
   | dev/test 直跑 `src/*.ts`（类型剥离） | ❌ 不支持 | ❌ `ERR_UNKNOWN_FILE_EXTENSION` | ✅ 默认开启 |
   | `npm test`（`--test-force-exit`） | ❌ `bad option` | ✅ | ✅ |

   → 技术上限是 **Node 18**（消费者路径全通）。

**建议：**

- **推荐 `engines` = `>=20.19.0`（已落地）**：Node 18 已于 2025-04-30
  EOL（2026-08 已过期 16 个月）、20 于 2026-04-30 刚 EOL——支持 EOL
  版本 = CI 矩阵成本 + 安全责任；20.19 覆盖刚 EOL 的 20 存量 + 22/24。
- **若坚持 18**：engines 可写 `>=18.20.0`（实测消费者路径可用），但必须
  补 `scripts/dev.mjs`（tsx 包装）供低版本开发，CI 矩阵加 18，且文档声明
  Node 18 已 EOL。
- CI 矩阵：Node 20/22/24；tests（直跑 src）只跑 22/24，smoke test
  （install dist + `sts status`）跑全矩阵。
- README 标注：**"直接 import `service-tunnels/src/*.ts`（开发模式）需要
  Node 22.18+（类型剥离）或 `tsx`；生产包（dist）支持 Node >=20"**。

### 2.3 Windows 支持矩阵（修正说明）

**修正我此前评审中的一处不准确表述**："redis 需 WSL2" 的说法只在
"Windows 上强制 authelia" 时成立，而该路径**被代码直接拒绝**：

- `authelia` 工具 `platforms: ["linux", "darwin"]`（无官方 Windows 包），
  Windows 上 `defaultProvider()` 直接返回 `portal`，不会选择 authelia；
- `needsSessionStore: true` 只有 authelia；portal/basic/oauth2-proxy 均为
  `false` → **Windows 下 redis 永不拉起，无 WSL2 依赖**；
- Windows 实际依赖链 = **nginx（官方 zip）+ portal（纯 Node）**；
  nginx 在 Windows 功能受限（按 design.md 平台矩阵），需在文档中明确
  具体限制（建议实测列出：reload 是否可用、SSE/WS 是否正常）。

**建议**：docs/design.md 平台矩阵补充一行"Windows 认证路径 = nginx + portal，
无需 WSL2/Docker"；README 增加"支持矩阵"小节的链接入口。

### 2.4 SECURITY.md + 已知风险声明

**新建 `SECURITY.md`（仓库根），内容大纲：**

1. **威胁模型**：三类边界——本地代理（局域网可达）、隧道暴露（公网可达）、
   认证门户（凭据处理）。每类写明攻击面与缓解。
2. **安全默认值清单**（对照代码逐一列出，作为信任背书）：
   - D4 零转发（未 enroll → 403）
   - 代理目标仅 127.0.0.1；后缀正则即主机白名单（防 DNS rebinding）
   - 发现缓存即白名单（防跳板访问 Redis/MySQL 等）
   - 端口归属校验（`verifyPortOwner`，他人端口需 `--force`）
   - fail-closed 认证判定（provider 超时/错误 → deny）
   - 配置写前 `nginx -t` / `authelia config validate` + 回滚
   - 凭据只落 0600 config 目录；state.json 不含 secret
   - 登录防爆破（portal：按 IP 滑动窗口限流 + 指数封禁）
   - scrypt 口令哈希 / HMAC 签名会话 cookie（timingSafeEqual）
3. **已知风险声明**（必须诚实列出的）：
   - **frpc 被 Kaspersky/360 等报 HackTool/RiskWare**：frp 项目自身被
     恶意软件滥用的结果，与本包无关；`expose` 前打印风险提示（代码已有），
     文档给加白名单指引；
   - 任何"公网暴露 + 反向隧道"行为可能被 Defender 网络保护 / 企业
     EDR / 网关反隧道策略拦截——属用户显式行为的预期成本；
   - Windows SmartScreen 对未签名 exe（frpc 等）的"未知发布者"提示；
   - **二进制供应链**：工具从官方源/Gitee 镜像下载，建议增加
     `checksums.sha256` 校验的落实情况说明（design.md §8.1 已声明，
     SECURITY.md 需写明现状与待办）；
   - 自托管隧道（bore/ssh/frpc）的安全性取决于服务器配置，本包不托管任何
     公共端点；
   - **本包尚未经独立安全审计**——如实声明，并给出审计计划（Phase 3）。
4. **漏洞报告流程**：GitHub Private Security Advisory + 联系邮箱 +
   PGP 公钥（可选）；承诺响应时限（如 72h 确认、14 天修复窗口）。
5. **审计计划**：公开后 1-2 个月内安排一次社区/商业审计，报告作为
   "值得信任" 的转化材料发布。

### 2.5 英文 README（双语方案）

**建议方案（A+B 组合）：**

- **A：根 README 保持中文**（当前用户群与生态是中文优先），新建
  `README.en.md`（英文），README 顶部放语言切换徽章
  （`[English](README.en.md) | [中文](README.md)`）。GitHub 只自动渲染
  根 README，语言切换用链接即可。
- **B：npm 包元信息全英文**（已满足：description/keywords 英文），
  并在 README.en.md 覆盖：快速开始（5 分钟内可跑通）、支持矩阵、
  安全模型、库模式示例（内部宿主应用案例脱敏改写）。
- **C：docs/ 五份设计文档**按优先级英文化：`design.md`（架构）>
  `sites-design.md`（认证域）> `api.md`（API 参考，可先只英文化 JSDoc 摘要）。
  每篇文档头部加 3-5 行英文 Abstract，正文保留中文——低成本高覆盖。
- 评估指标：README.en.md 上线后，GitHub 海外 star 比例与 npm 海外下载占比。

---

## 3. 竞品

### 3.1 直接竞品（npm 生态）

| 竞品 | 定位 | 与本包差距 |
|---|---|---|
| `localtunnel`（百万级周下载） | 一行公网 URL | 无认证、无发现、公共服务器稳定性差 |
| `ngrok`（agent + SaaS） | 商业隧道 | 要账号、固定域名收费、无本地认证编排 |
| `cloudflared` quick tunnel | 免费随机 URL | 无认证（free 版）、无 SSE |
| `expose.sh`（beyondcodegocom） | 单文件 tunnel | 无发现、无 site 隔离、Laravel 绑定 |
| `bore` | 极简自建 TCP 隧道 | 无认证、无代理 |
| `zrok`（OpenZiti） | 开源 tunnel + share | 有公网依赖、无进程发现 |

### 3.2 间接竞品

- ngrok + Cloudflare Access / Authelia 组合（用户自拼装，配置成本高）
- Caddy/Traefik + forward_auth（自托管运维路线）
- VS Code Remote Ports / Codespaces 端口转发（封闭生态）
- Tailscale Funnel（绑定 Tailscale 账号）

### 3.3 定位结论

> 竞品要么做"隧道"（无认证编排），要么做"认证/反代"（无隧道编排）。
> **"隧道 + 认证 + 进程发现 + 可嵌入 + CN 友好"的组合目前无对位者**——
> 这是真实空位，代价是组合面宽的维护成本，需用测试矩阵与文档管理。

---

## 4. 推广计划

### Phase 0：发布准备（1 周，修阻塞项）

- [ ] 抢注公共 npm `service-tunnels`；清理仓库敏感信息（`.npmrc` 凭据）；
  GitHub/Gitee 仓库更名 `service-tunnels`
- [ ] `sts` 别名运行时守卫（§2.1）+ 冲突文档（§2.1）
- [ ] engines 降级 `>=20.19.0`；CI 矩阵 20/22/24（§2.2）
- [ ] `SECURITY.md` + 支持矩阵修正（§2.3/2.4）
- [ ] `README.en.md` + 双语切换（§2.5）
- [ ] 冻结公开 API：此后仅 additive 变更，`CHANGELOG.md` 标注 breaking

### Phase 1：种子用户（第 1 个月，2-3 个真实嵌入案例）

1. 内部宿主应用作为旗舰嵌入案例发布（脱敏；库模式 + site 隔离，
   代码已有 `examples/host-integration.ts`）
2. 样板插件 1-2 个：`vite-plugin-expose`（demo：`vite dev` 自动获得带认证
   公网 URL）、测试框架演示分享（Playwright/WebdriverIO 场景）
3. 中文社区内容：掘金/知乎深度架构文（安全默认值 + CN 适配对比素材）

### Phase 2：内容 + 社区（第 2-3 个月）

- Hacker News / dev.to / Reddit r/node 英文技术文
  （角度：zero-config tunnel + auth as an npm library）
- 对比表 landing page（vs ngrok/localtunnel/cloudflared，附实测数据）
- 示例 gallery（9 种隧道真实演示）
- GitHub Discussions / Discord；**冻结 breaking API** 是本期硬约束

### Phase 3：生态放大（第 4-6 个月）

- e2e CI 矩阵跑真实隧道（ngrok/cloudflared/natapp/bore），出平台徽章
- 独立安全审计 + 审计报告发布（§2.4-5）
- 官方 VS Code 扩展（对标 ngrok 扩展）
- 目标：npm 周下载 5k+、内部宿主以外的嵌入方 ≥3

### 关键指标

- 公共 npm 下载量、GitHub stars、嵌入方数量
- e2e 覆盖度（324 组合 → 实测 >50%）、issue 中位响应时间
- **"expose 全链路成功率"**（隧道 + 认证）——口碑生命线

---

## 5. 收益路径

**诚实结论：短期直接收益低；6-18 个月后有 2-3 条可行路径。**
隧道市场已被免费服务商品化（cloudflared/localtunnel/serveo），但本包的
架构（可嵌入 + 组合编排）提供了其他隧道工具没有的变现接口。

| 路径 | 模式 | 现实性 | 时间 |
|---|---|---|---|
| A 嵌入商业授权 | MIT 核心 + 商业嵌入方付费支持/定制/优先维护；闭源嵌入方商业许可 | **最现实**（对标 sidekiq/sentry 模式；测试平台、AI Agent 框架、协作工具是目标客户，$500-5k/年 × 10-20 家） | 6-18 个月 |
| B 托管增值服务 | 自建 bore/frp relay + 固定子域名/自定义域名/SSO/团队站点；免费额度 + 付费 tier | 中期可行，需 abuse 治理（反向隧道是滥用重灾区）与带宽成本 | 18 个月+ |
| C 企业版 | 审计日志（accessLog 已有基础）、SLA、合规报告、私有化部署支持；金融/政务内网穿透合规需求（natapp 已验证中国付费意愿） | 与 B 并行 | 18 个月+ |
| D 长期生态 | GitHub Sponsors / 咨询定制（内部宿主应用背书） | 随出圈自然产生 | 持续 |

**不建议**：复刻 ngrok 完整 SaaS（资本密集、合规重、与单人团队形态不匹配）；
广告/数据变现（信任型工具碰数据即死）。

**预估**：前 6 个月 ~0（投入期）；6-18 个月 A 起步 $20-80k/年；
18 个月后 A+B/C $100-300k/年（需 2 人以上团队）。

---

## 6. 风险清单

| 风险 | 等级 | 缓解 |
|---|---|---|
| 过早公开化（API 未冻结 + 无审计） | 高 | Phase 0 冻结 API；Phase 3 审计 |
| npm 名称被抢注 / `st` 冲突 | 高（时间敏感） | 立即抢注（当前 404 可用）；`st` 弃用改用 `sts`；§2.1 |
| 仓库敏感信息泄露（.npmrc 凭据） | 高 | 公开前清理 + .gitignore |
| 隧道工具被滥用波及声誉（frpc 误报等） | 中 | SECURITY.md 诚实声明 + 风险提示已实现 |
| 二进制供应链（镜像投毒） | 中 | checksums 校验落实 + 现状声明 |
| Windows 能力预期落差 | 中 | 支持矩阵明示（§2.3） |
| 维护面过宽（324 组合） | 中 | e2e 矩阵 + 明确"受支持组合"边界 |
| 与 ngrok 等生态位重叠的竞争反应 | 低 | 差异化定位（嵌入 + CN + 认证默认） |
| 单人维护瓶颈 | 中 | 社区治理（CONTRIBUTING、维护者分工、Phase 3 招募） |

---

## 附：评审依据

- 源码：`src/` 27 文件（proxy/discovery/tunnels/tools/expose/index/gateway/
  authelia/daemon/portal 等），全文阅读 + 关键安全点核验
- 测试：`npm test` 实测 99 个，98 通过（1 skip）
- 文档：`docs/design.md`（479 行）、`docs/sites-design.md`（469 行）等 5 份
- 发布状态：私有 registry；公共 npm 名称可用性实测
- 嵌入方：内部宿主应用实际依赖方式核验（走 dist）
- Node 兼容性：dist 产物全量 API 扫描 + 依赖 engines 核验
