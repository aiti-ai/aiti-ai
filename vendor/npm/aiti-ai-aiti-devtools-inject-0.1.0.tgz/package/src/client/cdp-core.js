/**
 * cdp-core —— 纯 DOM 的 CDP 命令执行核心（提取公用）
 *
 * 来源：packages/aiti-devtools-inject/src/client/index.js 的 CDP 命令表 + 纯工具函数
 *       （resolveEl/serialize/treeSummary/cleanTextOf/xpathOf/isDbgEl/CSS_WHITELIST/topUrl/stripAitiText/fileLocation）
 * 用途：AI 主窗口 self-exec（M1，xxx/ai）加载本模块，无 launcher/state 依赖即可执行 DOM/CSS/Input/Page/Runtime/Storage/Performance 命令。
 * 约定：注入 client（index.js）保持原 IIFE 不动（21 项自检红线）——此处是同源实现；
 *       若未来注入 client 也切换到此模块，则消除重复（届时 index.js 删除闭包内 CDP 表 + 引用本模块）。
 *
 * 用法：<script src=".../cdp-core.js"></script> → window.__AitiCdpCore.exec(cmd, args) → { ok, result }
 * 状态：无（选区相关命令 clearSelection 降级 no-op；无 eval 开关——默认放行，受调用方边界控制）
 */
(function (global) {
  'use strict';

  // ---------- 纯工具（提取自 index.js，无闭包依赖） ----------
  function topUrl() {
    var isTop = false;
    try { isTop = (window.self === window.top); } catch (e) {}
    if (isTop) { try { return (window.location && window.location.href) || ''; } catch (e) {} }
    try { if (window.top && window.top !== window && window.top.location && window.top.location.href) return window.top.location.href; } catch (e) {}
    try { if (window.parent && window.parent !== window && window.parent.location && window.parent.location.href) return window.parent.location.href; } catch (e) {}
    try { var r = document.referrer || ''; if (r) return r; } catch (e) {}
    try { return (window.location && window.location.href) || ''; } catch (e) {}
    return '';
  }

  function xpathOf(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '//*[@id="' + String(el.id).replace(/"/g, '\\"') + '"]';
    var parts = [];
    var node = el;
    while (node && node.nodeType === 1) {
      var idx = 1;
      for (var sib = node.previousElementSibling; sib; sib = sib.previousElementSibling) {
        if (sib.tagName === node.tagName) idx++;
      }
      parts.unshift(node.tagName.toLowerCase() + '[' + idx + ']');
      node = node.parentElement;
    }
    return '/' + parts.join('/');
  }

  var CSS_WHITELIST = [
    'display', 'position', 'top', 'left', 'width', 'height',
    'padding', 'margin', 'border', 'borderRadius', 'zIndex',
    'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'color', 'textAlign',
    'backgroundColor', 'backgroundImage', 'boxShadow', 'opacity', 'overflow',
    'flexDirection', 'alignItems', 'justifyContent', 'gap',
    'gridTemplateColumns', 'gridTemplateRows',
  ];
  var SKIP_DEFAULTS = { initial: 1, inherit: 1, normal: 1, auto: 1, none: 1, '0px': 1 };

  function isDbgEl(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      if (el.closest && el.closest('#__dbg_launcher')) return true;
      if (el.id === '__dbg_launcher_css') return true;
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return true;
      var st = el.style;
      if (st && st.position === 'fixed' && String(st.zIndex) === '2147483646') return true;
    } catch (e) {}
    return false;
  }

  function cleanTextOf(el, max) {
    if (isDbgEl(el)) return '';
    var full = '';
    try { full = (el.innerText || el.textContent || '').trim(); } catch (e) {}
    try {
      if (full) {
        var lr = document.getElementById('__dbg_launcher');
        if (lr && lr !== el && (el === document.body || el === document.documentElement || el.contains(lr))) {
          var lt = (lr.innerText || lr.textContent || '').trim();
          if (lt && full.indexOf(lt) >= 0) {
            full = full.split(lt).join(' ').replace(/\s{2,}/g, ' ').trim();
          }
        }
      }
    } catch (e) {}
    return full.slice(0, max || 512);
  }

  function stripAitiText(s) {
    if (!s || typeof s !== 'string') return s;
    try {
      var lr = document.getElementById('__dbg_launcher');
      if (lr) {
        var lt = (lr.innerText || lr.textContent || '').trim();
        if (lt && s.indexOf(lt) >= 0) s = s.split(lt).join(' ').replace(/\s{2,}/g, ' ').trim();
      }
    } catch (e) {}
    return s;
  }

  function findFiber(el) {
    if (!el) return null;
    var keys = Object.getOwnPropertyNames(el);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (k.indexOf('__reactFiber$') === 0 || k.indexOf('__reactInternalInstance$') === 0) return el[k] || null;
    }
    return null;
  }

  function fileLocation(el) {
    if (!el) return null;
    var loc = null;
    var fiber = findFiber(el);
    if (!fiber) {
      var p = el.parentElement, depth = 0;
      while (p && depth < 5 && !fiber) { fiber = findFiber(p); p = p.parentElement; depth++; }
    }
    if (fiber) {
      var node = fiber;
      var prodComp = null;
      for (var i = 0; node && i < 30; i++) {
        var t = node.elementType || node.type || null;
        if (typeof t === 'string') { prodComp = t; break; }
        if (node._debugSource && node._debugSource.fileName) {
          var fn = node._debugSource.fileName;
          loc = { file: fn.split('/').slice(-2).join('/'), line: node._debugSource.lineNumber, col: node._debugSource.columnNumber };
          break;
        }
        node = node.return;
      }
      if (!loc && prodComp) loc = { component: prodComp };
    }
    return loc;
  }

  function serialize(el, opts) {
    opts = opts || {};
    var out = { tag: el.tagName.toLowerCase() };
    var r = el.getBoundingClientRect();
    var _sx = window.scrollX || document.documentElement.scrollLeft || document.body.scrollLeft || 0;
    var _sy = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
    out.rect = { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
    out.docRect = { x: Math.round(r.x + _sx), y: Math.round(r.y + _sy), w: out.rect.w, h: out.rect.h };
    out.scroll = { x: _sx, y: _sy };
    if (opts.attrs) {
      out.attributes = {};
      var attrs = el.attributes;
      for (var i = 0; i < attrs.length && i < 30; i++) out.attributes[attrs[i].name] = String(attrs[i].value).slice(0, 200);
    }
    if (opts.xpath) out.xpath = xpathOf(el);
    if (opts.text) out.text = cleanTextOf(el, 512);
    if (opts.computed) {
      out.computed = {};
      var cs = getComputedStyle(el);
      CSS_WHITELIST.forEach(function (k) { var v = cs[k]; if (v && !SKIP_DEFAULTS[v]) out.computed[k] = String(v).slice(0, 300); });
    }
    if (opts.framework) out.framework = fileLocation(el);
    out.frame = { src: topUrl(), url: topUrl().slice(0, 200) };
    return out;
  }

  function treeSummary(node, depth) {
    if (!node || depth <= 0) return null;
    if (isDbgEl(node)) return null;
    var out = {
      tag: node.tagName ? node.tagName.toLowerCase() : '#' + node.nodeName,
      id: node.id || undefined,
      cls: (node.className && typeof node.className === 'string') ? node.className.slice(0, 60) : undefined,
    };
    if (node.children && node.children.length) {
      out.children = [];
      for (var i = 0; i < node.children.length && i < 15; i++) {
        var c = treeSummary(node.children[i], depth - 1);
        if (c) out.children.push(c);
      }
      if (node.children.length > 15) out.children.push({ tag: '…+' + (node.children.length - 15) });
    }
    return out;
  }

  // resolveEl：无 state 依赖（self-exec 无选区），仅 selector/xpath
  function resolveEl(args) {
    var el = null;
    if (args && args.selector) { try { el = document.querySelector(args.selector); } catch (e) {} }
    if (!el && args && args.xpath) {
      try {
        var r = document.evaluate(args.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        el = r.singleNodeValue;
      } catch (e) {}
    }
    return (el && isDbgEl(el)) ? null : el;
  }

  var EXCLUDED_PROPS = {
    constructor: 1, '__proto__': 1, 'prototype': 1, 'innerHTML': 1, 'outerHTML': 1,
    'hasOwnProperty': 1, 'isPrototypeOf': 1, 'propertyIsEnumerable': 1, 'toString': 1,
    'valueOf': 1, 'toLocaleString': 1, 'onclick': 1, 'onmouseover': 1, 'onload': 1,
  };

  // ---------- 写入可编辑元素：React 兼容“真实键入”（等价 CDP Input.insertText） ----------
  // contenteditable（富文本/<p> 可编辑块）→ focus + 光标定位 + document.execCommand('insertText')
  // input/textarea → 原生原型 value setter（React 受控 value tracker 同步）+ input/change；select → 设值 + change
  // replace=true 清空现有内容再写入（setValue/type 语义），false 仅光标处插入（insertText 语义）
  function writeEditable(el, text, replace) {
    if (!el) return { ok: false, error: 'no element', tag: null };
    var value = String(text == null ? '' : text);
    var isCE = el.isContentEditable || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA' && el.tagName !== 'SELECT' && el.hasAttribute && el.hasAttribute('contenteditable'));
    if (isCE) {
      try { el.focus(); } catch (e) {}
      try {
        var sel = window.getSelection();
        if (sel) {
          var range = document.createRange();
          range.selectNodeContents(el);
          if (!replace) range.collapse(false);
          sel.removeAllRanges();
          sel.addRange(range);
        }
      } catch (e) {}
      var done = false;
      try { done = document.execCommand('insertText', false, value); } catch (e) {}
      if (!done) {
        try { el.textContent = value; } catch (e) {}
        try { el.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, inputType: 'insertText' })); }
        catch (e) { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e2) {} }
      }
      return { ok: true, editable: true, value: (el.innerText != null ? el.innerText : el.textContent || '') };
    }
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      try { el.focus(); } catch (e) {}
      var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      try { if (desc && desc.set) desc.set.call(el, value); else el.value = value; } catch (e) { try { el.value = value; } catch (e2) {} }
      try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
      try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
      return { ok: true, editable: false, value: el.value };
    }
    if (el.tagName === 'SELECT') {
      try { el.value = value; } catch (e) {}
      try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
      return { ok: true, editable: false, value: el.value };
    }
    return { ok: false, error: 'not an editable element（目标非 input/textarea/select/contenteditable）', tag: el.tagName || null };
  }

  // ---------- CDP 命令表（提取自 index.js，选区/手势相关降级） ----------
  var CDP = {
    DOM: {
      querySelector: function (args) {
        var el = resolveEl(args);
        return el ? serialize(el, { attrs: 1, xpath: 1, text: 1, computed: 1, framework: 1 }) : null;
      },
      querySelectorAll: function (args) {
        if (!args || !args.selector) return [];
        var els = document.querySelectorAll(args.selector);
        var out = [];
        for (var i = 0; i < els.length && out.length < 20; i++) {
          if (isDbgEl(els[i])) continue;
          out.push({ tag: els[i].tagName.toLowerCase(), id: els[i].id, cls: els[i].className && String(els[i].className).slice(0, 60), text: cleanTextOf(els[i], 80), xpath: xpathOf(els[i]) });
        }
        return out;
      },
      getBoxModel: function (args) {
        var el = resolveEl(args);
        if (!el) return null;
        var r = el.getBoundingClientRect();
        var cs = getComputedStyle(el);
        return { content: [r.x, r.y, r.width, r.height], right: r.right, bottom: r.bottom, padding: cs.padding, margin: cs.margin, borderWidth: cs.borderWidth, scroll: { x: el.scrollLeft, y: el.scrollTop } };
      },
      getOuterHTML: function (args) { var el = resolveEl(args); return el ? el.outerHTML.slice(0, 8000) : null; },
      getInnerText: function (args) { var el = resolveEl(args); return el ? cleanTextOf(el, 2000) : null; },
      removeNode: function (args) { var el = resolveEl(args); if (!el || !el.parentNode) return false; el.remove(); return true; },
      setAttribute: function (args) { var el = resolveEl(args); if (!el) return false; el.setAttribute(args.name, String(args.value)); return true; },
      removeAttribute: function (args) { var el = resolveEl(args); if (!el) return false; el.removeAttribute(args.name); return true; },
      clearSelection: function () { return true; }, // 无选区状态（self-exec），no-op
      getDocument: function (args) { return treeSummary(document.body, (args && args.depth) || 3); },
    },
    CSS: {
      getComputedStyle: function (args) {
        var el = resolveEl(args);
        if (!el) return null;
        var cs = getComputedStyle(el);
        var out = {};
        var props = (args && args.properties) ? String(args.properties).split(',') : CSS_WHITELIST;
        props.forEach(function (k) { if (cs[k] !== undefined) out[k] = String(cs[k]).slice(0, 300); });
        return out;
      },
      getMatchedRules: function (args) {
        var el = resolveEl(args);
        if (!el) return [];
        var out = [];
        for (var i = 0; i < document.styleSheets.length; i++) {
          var ss = document.styleSheets[i];
          var rules;
          try { rules = ss.cssRules || ss.rules; } catch (e) { continue; }
          if (!rules) continue;
          for (var j = 0; j < rules.length; j++) {
            var rule = rules[j];
            if (rule.selectorText && el.matches) {
              var matched = false;
              try { matched = el.matches(rule.selectorText); } catch (e) {}
              if (matched) out.push({ selector: rule.selectorText, cssText: rule.style ? rule.style.cssText.slice(0, 500) : '', source: (ss.href || 'inline').split('/').pop() });
            }
          }
        }
        return out.slice(0, 20);
      },
      setStyle: function (args) {
        var el = resolveEl(args);
        if (!el) return false;
        var styles = (args && args.styles) || {};
        Object.keys(styles).forEach(function (k) { el.style[k] = String(styles[k]); });
        return serialize(el, { computed: 1 }).computed;
      },
      listStyleSheets: function () {
        var out = [];
        for (var i = 0; i < document.styleSheets.length; i++) {
          var ss = document.styleSheets[i];
          var count = -1;
          try { count = ss.cssRules ? ss.cssRules.length : 0; } catch (e) {}
          out.push({ index: i, href: ss.href || '(inline)', rules: count });
        }
        return out;
      },
      getStyleSheetText: function (args) {
        try {
          var ss = document.styleSheets[args.index];
          if (!ss || !ss.cssRules) return null;
          var parts = [];
          for (var i = 0; i < ss.cssRules.length; i++) parts.push(ss.cssRules[i].cssText);
          return parts.join('\n').slice(0, 8000);
        } catch (e) { return null; }
      },
    },
    Input: {
      click: function (args) { var el = resolveEl(args); if (!el) return false; el.click(); return true; },
      hover: function (args) {
        var el = resolveEl(args); if (!el) return false;
        el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false }));
        return true;
      },
      focus: function (args) { var el = resolveEl(args); if (!el) return false; el.focus(); return true; },
      blur: function (args) { var el = resolveEl(args); if (!el) return false; el.blur(); return true; },
      setValue: function (args) {
        var el = resolveEl(args); if (!el) return { ok: false, error: '元素未定位' };
        var r = writeEditable(el, (args && args.value !== undefined) ? args.value : '', true);
        return { ok: r.ok, editable: !!r.editable, value: r.value, error: r.error };
      },
      type: function (args) {
        var el = resolveEl(args); if (!el) return { ok: false, error: '元素未定位' };
        var text = (args && args.text !== undefined) ? String(args.text) : '';
        var r = writeEditable(el, text, true);
        return { ok: r.ok, editable: !!r.editable, value: r.value, len: text.length, error: r.error };
      },
      // 对齐 CDP Input.insertText：在光标处插入文本（不替换已有内容）——React 受控/富文本通用
      insertText: function (args) {
        var el = resolveEl(args) || document.activeElement;
        var text = (args && args.text !== undefined) ? String(args.text) : '';
        var r = writeEditable(el, text, false);
        return { ok: r.ok, editable: !!r.editable, value: r.value, error: r.error };
      },
      keyPress: function (args) {
        var el = resolveEl(args) || document.activeElement;
        if (!el) return false;
        var opts = { key: args.key || 'Enter', code: args.code || '', bubbles: true, cancelable: true };
        el.dispatchEvent(new KeyboardEvent('keydown', opts));
        el.dispatchEvent(new KeyboardEvent('keyup', opts));
        return true;
      },
    },
    Page: {
      getMeta: function () {
        return { url: topUrl().slice(0, 2000), title: document.title, readyState: document.readyState, referrer: document.referrer.slice(0, 500), ua: navigator.userAgent.slice(0, 200) };
      },
      scrollTo: function (args) {
        window.scrollTo({ top: (args && args.top) || 0, left: (args && args.left) || 0, behavior: (args && args.behavior) || 'auto' });
        return { top: window.scrollY, left: window.scrollX };
      },
      scrollIntoView: function (args) {
        var el = resolveEl(args); if (!el) return false;
        el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: (args && args.smooth) ? 'smooth' : 'auto' });
        return true;
      },
      reload: function () { location.reload(); return true; },
      navigate: function (args) { if (args && args.url) location.href = args.url; return true; },
      captureScreenshot: function () {
        // 旧 getDisplayMedia 直连截屏已下线（无手势必被浏览器拒，且与 launcher 截屏卡重复）——
        // Page.captureScreenshot 统一由 launcher 截屏卡流程接管（意图说明→可先调整页面→预览确认）
        return Promise.resolve({ error: 'Page.captureScreenshot 已由 launcher 截屏卡接管（意图说明→调整页面→预览确认），此直连路径已停用' });
      },
      getFrameTree: function () {
        function walk(win, path) {
          var doc = null, frames = [];
          try { doc = win.document; } catch (e) {}
          if (doc) {
            var ifr = doc.querySelectorAll('iframe, frame');
            for (var i = 0; i < ifr.length; i++) {
              var f = ifr[i];
              var info = { id: path + '/' + i, name: f.name || '', src: f.src || f.getAttribute('src') || '', title: f.title || '' };
              try {
                info.sameOrigin = true;
                info.url = f.contentWindow.location.href.slice(0, 500);
                try { info.title = f.contentDocument.title; } catch (e2) {}
                try { info.readyState = f.contentDocument.readyState; } catch (e2) {}
                var sub = walk(f.contentWindow, info.id);
                if (sub && sub.length) info.childFrames = sub;
              } catch (e2) { info.sameOrigin = false; }
              frames.push(info);
            }
          }
          return frames;
        }
        return { frameTree: { id: 'frame', url: topUrl().slice(0, 500), title: document.title, readyState: document.readyState, sameOrigin: true, childFrames: walk(window, 'frame') } };
      },
    },
    Runtime: {
      evaluate: function (args) {
        // contextId：进 iframe 上下文执行（同域）
        var targetWin = null;
        if (args && args.contextId) {
          var _ifrs = document.querySelectorAll('iframe, frame');
          var _idx = Number(args.contextId) - 1;
          if (_idx < 0 || _idx >= _ifrs.length) return { error: 'contextId ' + args.contextId + ' 越界' };
          targetWin = _ifrs[_idx].contentWindow;
        }
        try {
          var val = targetWin ? targetWin.eval(String(args.expression)) : eval(String(args.expression));
          if (args && args.awaitPromise && val && typeof val.then === 'function') {
            return val.then(function (v) {
              var out = { type: typeof v, value: (typeof v === 'string' ? stripAitiText(v).slice(0, 2000) : v), awaited: true };
              return out;
            }).catch(function (e) { return { error: String((e && e.message) || e) }; });
          }
          if (val && typeof val.then === 'function') {
            return { type: 'promise', isPromise: true, value: 'Promise（如需最终结果传 awaitPromise: true）' };
          }
          return { type: typeof val, value: (typeof val === 'string' ? stripAitiText(val).slice(0, 2000) : val) };
        } catch (e) { return { error: String((e && e.message) || e) }; }
      },
      fetch: function (args) {
        if (!args || !args.url) return { error: '需要 url' };
        var url = args.url, init = args.init || {};
        return window.fetch(url, init).then(function (res) {
          return res.text().then(function (text) {
            return { status: res.status, ok: res.ok, url: String(res.url || url).slice(0, 300), text: text.slice(0, 2000) };
          });
        }).catch(function (e) { return { error: String((e && e.message) || e) }; });
      },
      getProperties: function (args) {
        var el = resolveEl(args);
        if (!el) return null;
        var out = {};
        var names = Object.getOwnPropertyNames(el);
        for (var i = 0; i < names.length && i < 30; i++) {
          var n = names[i];
          if (EXCLUDED_PROPS[n]) continue;
          try {
            var v = el[n];
            out[n] = (typeof v === 'function') ? '[function]' : ((typeof v === 'object' && v !== null) ? '[object]' : String(v).slice(0, 100));
          } catch (e) { out[n] = '[unreadable]'; }
        }
        return out;
      },
    },
    Storage: {
      localStorageGet: function (args) { try { return { key: args.key, value: localStorage.getItem(args.key) }; } catch (e) { return { error: String(e.message) }; } },
      localStorageSet: function (args) { try { localStorage.setItem(args.key, String(args.value)); return true; } catch (e) { return { error: String(e.message) }; } },
      localStorageClear: function () { try { localStorage.clear(); return true; } catch (e) { return { error: String(e.message) }; } },
      sessionStorageGet: function (args) { try { return { key: args.key, value: sessionStorage.getItem(args.key) }; } catch (e) { return { error: String(e.message) }; } },
      cookies: function () { try { return document.cookie.slice(0, 2000); } catch (e) { return ''; } },
    },
    Performance: {
      getEntries: function (args) {
        var n = (args && args.count) ? args.count : 10;
        try {
          return performance.getEntriesByType('resource').slice(-n).map(function (e) {
            return { name: e.name.slice(0, 200), type: e.initiatorType, duration: Math.round(e.duration), size: e.transferSize || e.encodedBodySize || 0 };
          });
        } catch (err) { return []; }
      },
    },
    // 浏览器受限操作：self-exec 直连大多被浏览器拦截（需用户手势）——报错文本引导重试
    Browser: {
      copy: function (args) {
        return navigator.clipboard.writeText(String(args.text || '')).then(
          function () { return { copied: true }; },
          function (e) { return { error: '剪贴板被浏览器拦截（需要用户手势）：' + String((e && e.message) || e) }; }
        );
      },
      download: function (args) {
        var a = document.createElement('a');
        a.href = args.dataUrl || ('data:text/plain,' + encodeURIComponent(String(args.text || '')));
        a.download = args.name || 'dbg-download.txt';
        document.body.appendChild(a);
        a.click();
        a.remove();
        return { downloaded: a.download };
      },
      openWindow: function (args) {
        var w = window.open(args.url || 'about:blank', '_blank');
        return w ? { opened: true } : { error: '弹窗被浏览器拦截（需要用户手势）' };
      },
      paste: function () {
        if (!(navigator.clipboard && navigator.clipboard.readText)) return Promise.resolve({ error: '当前浏览器不支持剪贴板读取' });
        return navigator.clipboard.readText().then(
          function (t) { return { text: String(t || '').slice(0, 100000) }; },
          function (e) { return { error: '剪贴板读取被拒（无用户手势/未授权）' }; }
        );
      },
      pickFile: function () { return Promise.resolve({ error: '文件选择器需用户手势（直连路径不可用）' }); },
      share: function () {
        if (!navigator.share) return Promise.resolve({ error: '当前浏览器不支持 Web Share' });
        return Promise.resolve({ error: '分享需用户手势（直连路径不可用）' });
      },
      fullscreen: function (args) {
        var el = resolveEl(args) || document.documentElement;
        var p = el.requestFullscreen && el.requestFullscreen();
        if (!p) return { error: '不支持全屏' };
        return p.then(function () { return { fullscreen: true }; }, function (e) { return { error: '全屏被浏览器拦截：' + String((e && e.message) || e) }; });
      },
      play: function (args) {
        var el = resolveEl(args);
        if (!el || !el.play) return { error: '未找到可播放元素' };
        return el.play().then(
          function () { return { playing: true }; },
          function (e) { return { error: '自动播放被浏览器拦截（需要用户手势）：' + String((e && e.message) || e) }; }
        );
      },
    },
  };

  var CMD_ALIASES = {
    getInfo: 'DOM.querySelector',
    highlight: 'DOM.querySelector',
    scrollIntoView: 'Page.scrollIntoView',
  };

  /** 执行一条 CDP 命令：cmd 如 'Runtime.evaluate'；返回 { ok, result }（result 可能为 Promise，调用方 await） */
  function exec(cmd, args) {
    var c = CMD_ALIASES[cmd] || cmd;
    var dot = String(c).indexOf('.');
    var domain = dot > 0 ? c.slice(0, dot) : '';
    var method = dot > 0 ? c.slice(dot + 1) : '';
    var handler = CDP[domain] && CDP[domain][method];
    if (!handler) return { ok: false, result: { error: 'unknown command: ' + cmd + '（可用域：DOM/CSS/Input/Page/Runtime/Storage/Performance/Browser）' } };
    try {
      return { ok: true, result: handler(args || {}) };
    } catch (err) {
      return { ok: false, result: { error: String((err && err.message) || err) } };
    }
  }

  global.__AitiCdpCore = { exec: exec, CDP: CDP, version: '0.1.0' };
})(typeof window !== 'undefined' ? window : globalThis);